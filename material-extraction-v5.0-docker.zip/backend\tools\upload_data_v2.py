from __future__ import annotations

import os
import re
from typing import Optional, Dict, Any, List

try:
    import psycopg
    from psycopg import sql as pg_sql
    from psycopg.rows import dict_row
    HAS_POSTGRES = True
except ImportError:
    HAS_POSTGRES = False

from backend.tools.get_data_v2 import TABLE_SCHEMAS


class PostgresUploaderV2:
    """
    多表结构PostgreSQL上传器 v2.0
    
    功能：
    - 从多表字典数据或Excel文件批量导入到多张PostgreSQL表
    - 基于主键自动去重
    - 支持强制模式（更新已有记录）
    - 完整的错误记录和统计
    
    使用示例：
        uploader = PostgresUploaderV2(
            host="localhost", port=5432,
            user="postgres", password="postgres",
            database="material_db"
        )
        result = uploader.upload_from_dict(multi_table_data)
        print(result)
    """

    description = "耦合版多表PostgreSQL上传器v3.0 - material_data为主表"

    LEGACY_FIELD_MAPPING = {
        "authors": "authors_bib",
        "issue": "number",
    }

    TABLE_ORDER = [
        "fiber_type_dict", "result_property_dict",
        "material_data", "mix_proportions", "fibers",
        "specimens_group", "specimens",
        "heating_protocols", "test_methods",
        "test_result_group", "test_results",
    ]

    PRIMARY_KEYS = {
        "material_data": "paper_code",
        "mix_proportions": "mix_code",
        "fibers": "fiber_code",
        "specimens_group": "specimen_group_code",
        "specimens": "specimen_code",
        "heating_protocols": "heating_protocol_id",
        "test_methods": "method_code",
        "test_result_group": "result_group_code",
        "test_results": "result_code",
        "fiber_type_dict": "fiber_type_code",
        "result_property_dict": "property_code",
    }

    def __init__(
        self,
        host: str = "localhost",
        port: int = 5432,
        user: str = "postgres",
        password: str = "",
        database: str = "material_db",
        force_mode: bool = False
    ):
        if not HAS_POSTGRES:
            raise ImportError("请安装PostgreSQL驱动: pip install 'psycopg[binary]'")

        self.host = host
        self.port = port
        self.user = user
        self.password = password
        self.database = database
        self.force_mode = force_mode
        
        self.connection: Optional[psycopg.Connection] = None
        self.cursor: Optional[psycopg.Cursor] = None
        self.error_records: List[Dict[str, Any]] = []
        self._db_columns_cache: Dict[str, set] = {}

    def _get_db_columns(self, table_name: str) -> set:
        """获取数据库表中实际存在的列名"""
        if table_name in self._db_columns_cache:
            return self._db_columns_cache[table_name]
        
        try:
            self.cursor.execute("""
                SELECT column_name FROM information_schema.columns
                WHERE table_name = %s AND table_schema = 'public'
            """, (table_name,))
            columns = {row['column_name'] for row in self.cursor.fetchall()}
            self._db_columns_cache[table_name] = columns
            return columns
        except Exception:
            return set()

    def connect(self) -> bool:
        conn_str = f"host={self.host} port={self.port} user={self.user}"
        if self.password:
            conn_str += f" password={self.password}"
        conn_str += f" dbname={self.database}"

        try:
            self.connection = psycopg.connect(conn_str)
            self.cursor = self.connection.cursor(row_factory=dict_row)
            
            existing_tables = self._list_existing_tables()
            print(f"[PG v2] 已连接: {self.host}:{self.port}/{self.database}")
            print(f"[PG v2] 已有表: {', '.join(existing_tables) or '(空)'}")
            return True
        except Exception as e:
            print(f"[PG v2] 连接失败: {e}")
            raise

    def _list_existing_tables(self) -> List[str]:
        self.cursor.execute("""
            SELECT table_name FROM information_schema.tables 
            WHERE table_schema='public' AND table_type='BASE TABLE'
            ORDER BY table_name
        """)
        return [row['table_name'] for row in self.cursor.fetchall()]

    def disconnect(self):
        if self.cursor:
            self.cursor.close()
        if self.connection:
            self.connection.close()
        self.connection = None
        self.cursor = None

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.disconnect()

    def _get_next_paper_offset(self) -> int:
        try:
            self.cursor.execute(
                "SELECT MAX(SUBSTRING(paper_code FROM 'P_(\\d+)')::int) "
                "FROM material_data WHERE paper_code LIKE 'P_%'"
            )
            row = self.cursor.fetchone()
            if row and row[0] is not None:
                return int(row[0])
        except Exception as e:
            print(f"[PG v2] 查询最大paper_code失败: {e}")
        return 0

    @staticmethod
    def _renumber_data(data: Dict[str, List[Dict]], offset: int) -> Dict[str, List[Dict]]:
        if offset <= 0:
            return data

        import re

        def renumber_code(code: str) -> str:
            if not code or not isinstance(code, str):
                return code
            m = re.match(r'P_(\d+)(.*)', code)
            if m:
                old_num = int(m.group(1))
                new_num = old_num + offset
                suffix = m.group(2)
                return f"P_{new_num:03d}{suffix}"
            return code

        result = {}
        for table_name, rows in data.items():
            new_rows = []
            for row in rows:
                new_row = {}
                for k, v in row.items():
                    if isinstance(v, str) and ('P_' in v):
                        new_row[k] = renumber_code(v)
                    else:
                        new_row[k] = v
                new_rows.append(new_row)
            result[table_name] = new_rows

        return result

    def upload_from_dict(self, data: Dict[str, List[Dict]]) -> Dict[str, Any]:
        """
        从Python字典数据批量导入所有表

        Args:
            data: {table_name: [row_dicts...]} 格式的数据

        Returns:
            dict: 包含每张表的导入统计信息
        """
        if not self.connection:
            self.connect()

        db_max = self._get_next_paper_offset()
        
        llm_papers = data.get("material_data", [])
        if llm_papers:
            first_code = llm_papers[0].get("paper_code", "")
            m = re.match(r'P_(\d+)', str(first_code))
            data_start = int(m.group(1)) if m else 1
            
            if data_start <= db_max:
                offset = db_max
                data = self._renumber_data(data, offset)
                print(f"[PG v2] 自动编号修正: DB已有P_001~P_{db_max:03d}, "
                      f"数据从P_{data_start:03d}开始 → 偏移+{offset} → P_{offset+1:03d}开始")
            else:
                print(f"[PG v2] 编号无需修正: DB最大P_{db_max:03d}, 数据从P_{data_start:03d}开始 (数据已由Excel重映射)")

        total_result = {
            "total_success": 0,
            "total_failed": 0,
            "total_skipped": 0,
            "total_updated": 0,
            "tables": {},
            "errors": [],
            "database": self.database,
        }

        for table_name in self.TABLE_ORDER:
            rows = data.get(table_name, [])
            if not rows:
                continue
            
            try:
                result = self._upload_single_table(table_name, rows)
                total_result["tables"][table_name] = result
                total_result["total_success"] += result.get("success", 0)
                total_result["total_failed"] += result.get("failed", 0)
                total_result["total_skipped"] += result.get("skipped_duplicates", 0)
                total_result["total_updated"] += result.get("updated_count", 0)
            except Exception as e:
                error_msg = f"{table_name}: {str(e)}"
                total_result["errors"].append(error_msg)
                total_result["tables"][table_name] = {"status": "error", "error": str(e)}
                print(f"[PG v2] FAIL {table_name}: {e}")

        mode_str = "force(update)" if self.force_mode else "normal(skip dup)"
        print(f"[PG v2] All done [{mode_str}]")
        print(f"   success: {total_result['total_success']}, "
              f"updated: {total_result['total_updated']}, "
              f"skipped: {total_result['total_skipped']}, "
              f"failed: {total_result['total_failed']}")

        return total_result

    NUMERIC_FIELDS = {
        'water_binder_ratio', 'cement_kg_m3', 'silica_fume_kg_m3',
        'limestone_filler_kg_m3', 'fly_ash_kg_m3', 'slag_kg_m3',
        'metakaolin_kg_m3', 'water_kg_m3', 'fine_aggregate_kg_m3',
        'coarse_aggregate_kg_m3', 'silica_sand_kg_m3',
        'lightweight_aggregate_kg_m3', 'superplasticizer_kg_m3',
        'steel_fiber_volume_fraction', 'pp_fiber_volume_fraction',
        'pe_fiber_volume_fraction', 'pva_fiber_volume_fraction',
        'pom_fiber_volume_fraction', 'glass_fiber_volume_fraction',
        'carbon_fiber_volume_fraction', 'other_fiber_volume_fraction',
        'volume_fraction_pct', 'length_mm', 'diameter_min_mm',
        'diameter_max_mm', 'aspect_ratio', 'mass_kg_m3',
        'elastic_modulus_gpa', 'tensile_strength_mpa', 'melting_temp_c',
        'density_g_cm3', 'target_temperature', 'heating_rate_degree_min',
        'holding_time_min', 'cooling_time_min', 'load_level_pct',
        'loading_rate', 'compressive_strength', 'direct_tensile_strength',
        'splitting_tensile_strength', 'flexural_strength',
        'elastic_modulus', 'peak_strain', 'mass_loss_ratio_percent',
        'residual_strength_ratio', 'value_numeric', 'value_min',
        'value_max', 'value_mean', 'value_std_dev',
        'length_mm', 'width_mm', 'height_mm', 'diameter_mm',
        'thickness_mm', 'gauge_length_mm', 'gauge_width_mm',
        'curing_temp_c', 'curing_rh_pct',
    }

    INT_FIELDS = {
        'fiber_enhanced', 'cycle', 'age_at_test_day', 'sample_size',
    }

    NULL_STRINGS = {'null', 'none', 'n/a', 'na', '-', '', 'undefined'}

    @classmethod
    def _coerce_value(cls, key: str, value):
        if value is None:
            return None
        if isinstance(value, str):
            stripped = value.strip()
            if stripped.lower() in cls.NULL_STRINGS:
                return None
            if key in cls.NUMERIC_FIELDS:
                try:
                    cleaned = stripped.replace(',', '').replace('±', '').split()[0]
                    return float(cleaned)
                except (ValueError, IndexError):
                    return None
            if key in cls.INT_FIELDS:
                try:
                    return int(float(stripped))
                except (ValueError, TypeError):
                    return None
        return value

    def _upload_single_table(self, table_name: str, rows: List[Dict]) -> Dict[str, Any]:
        db_table_name = table_name
        
        # 获取数据库中实际存在的列
        db_columns = self._get_db_columns(db_table_name)
        
        if not db_columns:
            print(f"[PG v2]   {table_name}: 跳过（数据库表 {db_table_name} 不存在）")
            return {"success": 0, "failed": 0, "skipped_duplicates": 0, "total": len(rows), "table_name": table_name}
        
        schema = TABLE_SCHEMAS.get(table_name)
        
        if not schema:
            code_field_names = list(rows[0].keys()) if rows else []
        else:
            code_field_names = [f[0] for f in schema["fields"]]
        
        pk_field = self.PRIMARY_KEYS.get(table_name)
        
        # 只保留数据库中实际存在的字段（排除自动管理的字段）
        auto_fields = {'id', 'specimen_id', 'result_id', 'created_at', 'updated_at'}
        all_keys = [k for k in code_field_names if k in db_columns and k not in auto_fields]
        
        if not all_keys:
            # 如果schema定义的字段都不在数据库中，尝试从数据本身取字段
            if rows:
                data_keys = [k for k in rows[0].keys() if k in db_columns and k not in auto_fields]
                if data_keys:
                    all_keys = data_keys
                else:
                    print(f"[PG v2]   {table_name}: 跳过（没有匹配的数据库列）")
                    return {"success": 0, "failed": len(rows), "skipped_duplicates": 0, "total": len(rows), "table_name": table_name}
            else:
                return {"success": 0, "failed": 0, "skipped_duplicates": 0, "total": 0, "table_name": table_name}

        has_pk = pk_field and pk_field in all_keys
        
        if self.force_mode:
            existing_keys = set()
        elif has_pk:
            existing_keys = self._get_existing_pks(db_table_name, pk_field)
        else:
            existing_keys = set()

        success = 0
        failed = 0
        skipped = 0
        updated = 0

        for idx, record in enumerate(rows):
            if has_pk and not self.force_mode:
                pk_val = str(record.get(pk_field, '')).strip()
                if pk_val and pk_val in existing_keys:
                    skipped += 1
                    continue

            try:
                self.connection.execute("SAVEPOINT sp_row")
            except Exception:
                pass

            try:
                normalized_record = {}
                for k, v in record.items():
                    new_key = self.LEGACY_FIELD_MAPPING.get(k, k)
                    if new_key != k and new_key in all_keys and new_key not in record:
                        normalized_record[new_key] = v
                    else:
                        normalized_record[k] = v

                columns = [pg_sql.Identifier(k) for k in all_keys]
                values = [self._coerce_value(key, normalized_record.get(key)) for key in all_keys]

                if self.force_mode and has_pk:
                    insert_query = pg_sql.SQL(
                        "INSERT INTO {} ({}) VALUES ({}) "
                        "ON CONFLICT ({}) DO UPDATE SET {}"
                    ).format(
                        pg_sql.Identifier(db_table_name),
                        pg_sql.SQL(', ').join(columns),
                        pg_sql.SQL(', ').join(pg_sql.Placeholder() * len(all_keys)),
                        pg_sql.Identifier(pk_field),
                        pg_sql.SQL(', ').join([
                            pg_sql.SQL("{} = EXCLUDED.{}").format(
                                pg_sql.Identifier(k), pg_sql.Identifier(k)
                            ) for k in all_keys if k != pk_field
                        ])
                    )
                    
                    pk_val = str(record.get(pk_field, '')).strip()
                    if pk_val and self._pk_exists(db_table_name, pk_field, pk_val):
                        updated += 1
                else:
                    if has_pk:
                        insert_query = pg_sql.SQL(
                            "INSERT INTO {} ({}) VALUES ({}) "
                            "ON CONFLICT ({}) DO NOTHING"
                        ).format(
                            pg_sql.Identifier(db_table_name),
                            pg_sql.SQL(', ').join(columns),
                            pg_sql.SQL(', ').join(pg_sql.Placeholder() * len(all_keys)),
                            pg_sql.Identifier(pk_field)
                        )
                    else:
                        insert_query = pg_sql.SQL(
                            "INSERT INTO {} ({}) VALUES ({}) "
                            "ON CONFLICT DO NOTHING"
                        ).format(
                            pg_sql.Identifier(db_table_name),
                            pg_sql.SQL(', ').join(columns),
                            pg_sql.SQL(', ').join(pg_sql.Placeholder() * len(all_keys))
                        )

                self.cursor.execute(insert_query, values)
                
                if self.cursor.rowcount > 0 or (not has_pk):
                    success += 1
                
                if has_pk:
                    new_pk = str(record.get(pk_field, '')).strip()
                    if new_pk:
                        existing_keys.add(new_pk)

                try:
                    self.connection.execute("RELEASE SAVEPOINT sp_row")
                except Exception:
                    pass

            except Exception as e:
                failed += 1
                try:
                    self.connection.execute("ROLLBACK TO SAVEPOINT sp_row")
                except Exception:
                    pass
                error_info = {
                    "table": table_name,
                    "row_index": idx + 1,
                    "error": str(e)[:200],
                    "data_preview": {k: str(v)[:40] for k, v in list(record.items())[:5]},
                }
                self.error_records.append(error_info)
                if failed <= 3:
                    err_msg = str(e)[:100].encode("ascii", errors="replace").decode("ascii")
                    print(f"[PG v2]     row {idx+1} failed: {err_msg}")

        self.connection.commit()

        result = {
            "success": success,
            "failed": failed,
            "skipped_duplicates": skipped,
            "updated_count": updated,
            "total": len(rows),
            "table_name": table_name,
        }
        
        if self.force_mode:
            print(f"[PG v2]   {table_name}: +{success} (更新{updated}), 失败{failed}")
        elif skipped > 0 or success > 0:
            print(f"[PG v2]   {table_name}: +{success}, 跳过{skipped}, 失败{failed}")

        return result

    def _get_existing_pks(self, table_name: str, pk_field: str) -> set:
        keys = set()
        try:
            query = pg_sql.SQL("SELECT DISTINCT {} FROM {}").format(
                pg_sql.Identifier(pk_field),
                pg_sql.Identifier(table_name)
            )
            self.cursor.execute(query)
            for row in self.cursor.fetchall():
                val = row.get(pk_field)
                if val is not None:
                    keys.add(str(val).strip())
        except Exception:
            pass
        return keys

    def _pk_exists(self, table_name: str, pk_field: str, pk_value: str) -> bool:
        try:
            query = pg_sql.SQL("SELECT 1 FROM {} WHERE {} = %s LIMIT 1").format(
                pg_sql.Identifier(table_name),
                pg_sql.Identifier(pk_field)
            )
            self.cursor.execute(query, (pk_value,))
            return self.cursor.fetchone() is not None
        except Exception:
            return False

    def upload_from_file(self, filepath: str) -> Dict[str, Any]:
        """从多sheet Excel文件导入"""
        from openpyxl import load_workbook

        if not os.path.exists(filepath):
            raise FileNotFoundError(f"文件不存在: {filepath}")

        if not self.connection:
            self.connect()

        wb = load_workbook(filepath, read_only=True)
        all_data = {}

        for sheet_name in wb.sheetnames:
            if sheet_name.startswith("_"):
                continue
            
            sheet = wb[sheet_name]
            headers = []
            rows = []
            
            for row_idx, row in enumerate(sheet.iter_rows(values_only=True), 1):
                if row_idx == 1:
                    headers = [str(c).strip() if c else "" for c in row if c is not None]
                    continue
                
                if not any(cell is not None for cell in row):
                    continue
                    
                record = {}
                for col_idx, cell_value in enumerate(row):
                    if col_idx < len(headers) and headers[col_idx]:
                        key = headers[col_idx]
                        value = cell_value
                        if value is not None and isinstance(value, str) and value.strip() == '':
                            value = None
                        record[key] = value
                
                if any(v is not None for v in record.values()):
                    rows.append(record)

            if rows:
                all_data[sheet_name] = rows
                print(f"[PG v2] 从Sheet '{sheet_name}' 读取 {len(rows)} 条记录")

        wb.close()

        if not all_data:
            return {
                "total_success": 0, "total_failed": 0,
                "message": "Excel文件中没有有效数据"
            }

        return self.upload_from_dict(all_data)

    def get_database_status(self) -> Dict[str, Any]:
        """获取数据库中各表的统计状态"""
        if not self.connection:
            self.connect()

        status = {"database": self.database, "tables": {}}
        
        for table_name in self.TABLE_ORDER:
            try:
                query = pg_sql.SQL("SELECT COUNT(*) as cnt FROM {}").format(
                    pg_sql.Identifier(table_name)
                )
                self.cursor.execute(query)
                count = self.cursor.fetchone()['cnt']
                status["tables"][table_name] = {"rows": count}
            except Exception:
                status["tables"][table_name] = {"rows": 0, "error": "table not found"}

        return status
