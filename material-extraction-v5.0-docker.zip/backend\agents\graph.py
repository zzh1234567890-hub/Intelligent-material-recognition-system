"""
LangGraph 工作流图定义

定义智能识别爬取系统的完整 Agent 工作流
"""

from typing import Dict, Any
from langgraph.graph import StateGraph, END
from backend.agents.state import AgentState, create_initial_state
from backend.agents.nodes import (
    intent_analysis_node,
    task_planning_node,
    tools_execution_node,
    result_summary_node
)


def create_agent_graph() -> StateGraph:
    """
    创建完整的 Agent 工作流图
    
    工作流结构：
    
    ┌─────────────┐     ┌─────────────┐     ┌──────────────┐     ┌─────────────┐
    │ 意图分析     │ ──▶ │ 任务规划     │ ──▶ │ 工具执行      │ ──▶ │ 结果汇总     │
    │ (LLM)       │     │ (规则+LLM)  │     │ (4个工具)    │     │ (LLM)       │
    └─────────────┘     └─────────────┘     └──────────────┘     └─────────────┘
          ▲                                                             │
          │                    （可选：用户反馈循环）                      │
          └─────────────────────────────────────────────────────────────┘
    
    特性：
    - 线性流程：4个节点顺序执行
    - 状态传递：每个节点更新共享的 AgentState
    - 错误处理：任一节点失败可终止或继续（取决于错误类型）
    - 可扩展：易于添加新节点或修改流程
    
    Returns:
        StateGraph: 编译后的工作流图，可直接调用
        
    使用示例：
        graph = create_agent_graph()
        app = graph.compile()
        
        # 执行工作流
        state = create_initial_state(
            user_input="提取文档中的材料数据",
            uploaded_files=[{"name": "test.pdf", "type": "pdf", "path": "/tmp/test.pdf"}]
        )
        
        result = app.invoke(state)
        print(result["final_response"])
    """
    
    # 创建状态图实例
    graph = StateGraph(AgentState)
    
    # ==================== 注册节点 ====================
    
    graph.add_node("intent_analysis", intent_analysis_node)
    graph.add_node("task_planning", task_planning_node)
    graph.add_node("tools_execution", tools_execution_node)
    graph.add_node("result_summary", result_summary_node)
    
    # ==================== 定义边（流程）====================
    
    # 主流程：线性执行
    graph.add_edge("intent_analysis", "task_planning")
    graph.add_edge("task_planning", "tools_execution")
    graph.add_edge("tools_execution", "result_summary")
    
    # 终止点
    graph.add_edge(result_summary, END)
    
    # 设置入口点
    graph.set_entry_point("intent_analysis")
    
    return graph


class IntelligentCrawlerAgent:
    """
    智能识别爬取系统 Agent 封装类
    
    提供高级接口来使用 LangGraph 工作流，
    隐藏底层图的复杂性。
    
    功能：
    - 一键式处理文档并上传到数据库
    - 支持会话管理和状态追踪
    - 提供详细的处理日志和统计信息
    - 支持同步和异步调用模式
    
    使用示例：
        agent = IntelligentCrawlerAgent()
        
        # 方式1：完整流程
        result = agent.process(
            user_input="提取所有材料数据",
            files=["document.pdf"]
        )
        print(result["final_response"])
        
        # 方式2：分步执行（更多控制）
        session_id = agent.create_session(
            user_input="提取数据",
            files=["doc.pdf"]
        )
        
        intent = agent.analyze_intent(session_id)
        plan = agent.plan_tasks(session_id)
        results = agent.execute_tools(session_id)
        summary = agent.summarize_results(session_id)
    """
    
    def __init__(self):
        self._graph = None
        self._app = None
        self._sessions: Dict[str, AgentState] = {}
    
    @property
    def graph(self) -> StateGraph:
        """获取工作流图（延迟初始化）"""
        if self._graph is None:
            self._graph = create_agent_graph()
            self._app = self._graph.compile()
        return self._app
    
    def process(
        self,
        user_input: str,
        files: list = None,
        **kwargs
    ) -> Dict[str, Any]:
        """
        一键式处理入口（推荐）
        
        完整执行整个工作流：
        用户输入 → 意图分析 → 任务规划 → 工具执行 → 结果汇总
        
        Args:
            user_input: 用户自然语言输入
            files: 文件路径列表或文件信息字典列表
                   示例: ["/path/to/file.pdf"] 或
                         [{"name": "file.pdf", "path": "/path/to/file.pdf"}]
            **kwargs: 其他可选参数
                
        Returns:
            dict: 包含 final_response 和所有中间状态的字典
            
        Raises:
            Exception: 处理过程中发生严重错误时抛出异常
        """
        print("\n" + "="*70)
        print("🚀 智能识别爬取系统 - 启动处理")
        print("="*70)
        
        # 准备文件信息
        file_list = self._prepare_file_list(files)
        
        # 创建初始状态
        initial_state = create_initial_state(
            user_input=user_input,
            uploaded_files=file_list
        )
        
        # 执行工作流
        result_state = self.graph.invoke(initial_state)
        
        # 存储会话
        session_id = result_state.get("session_id")
        if session_id:
            self._sessions[session_id] = result_state
        
        return dict(result_state)
    
    def create_session(
        self,
        user_input: str,
        files: list = None
    ) -> str:
        """创建新的处理会话"""
        file_list = self._prepare_file_list(files)
        state = create_initial_state(
            user_input=user_input,
            uploaded_files=file_list
        )
        
        session_id = state["session_id"]
        self._sessions[session_id] = state
        
        print(f"✅ 会话已创建: {session_id}")
        return session_id
    
    def analyze_intent(self, session_id: str) -> Dict[str, Any]:
        """单独执行意图分析步骤"""
        state = self._get_session(session_id)
        updated = intent_analysis_node(state.copy())
        self._sessions[session_id] = updated
        return updated
    
    def plan_tasks(self, session_id: str) -> Dict[str, Any]:
        """单独执行任务规划步骤"""
        state = self._get_session(session_id)
        updated = task_planning_node(state.copy())
        self._sessions[session_id] = updated
        return updated
    
    def execute_tools(self, session_id: str) -> Dict[str, Any]:
        """单独执行工具调用步骤"""
        state = self._get_session(session_id)
        updated = tools_execution_node(state.copy())
        self._sessions[session_id] = updated
        return updated
    
    def summarize_results(self, session_id: str) -> Dict[str, Any]:
        """单独执行结果汇总步骤"""
        state = self._get_session(session_id)
        updated = result_summary_node(state.copy())
        self._sessions[session_id] = updated
        return updated
    
    def get_session_status(self, session_id: str) -> Dict[str, Any]:
        """获取会话当前状态摘要"""
        from backend.agents.state import get_state_summary
        
        state = self._get_session(session_id)
        return get_state_summary(state)
    
    def get_session_result(self, session_id: str) -> Dict[str, Any]:
        """获取会话完整结果"""
        return self._get_session(session_id)
    
    def _prepare_file_list(self, files: list) -> list:
        """准备文件信息列表"""
        if not files:
            return []
        
        prepared = []
        for f in files:
            if isinstance(f, str):
                import os
                ext = os.path.splitext(f)[1].lower()
                prepared.append({
                    "name": os.path.basename(f),
                    "path": f,
                    "type": self._detect_type(ext),
                    "size": os.path.getsize(f) if os.path.exists(f) else 0
                })
            elif isinstance(f, dict):
                prepared.append(f)
        
        return prepared
    
    @staticmethod
    def _detect_type(ext: str) -> str:
        type_map = {
            ".pdf": "pdf",
            ".docx": "docx",
            ".doc": "docx",
            ".md": "markdown",
            ".markdown": "markdown"
        }
        return type_map.get(ext, "unknown")
    
    def _get_session(self, session_id: str) -> AgentState:
        """获取会话状态"""
        if session_id not in self._sessions:
            raise ValueError(f"会话不存在: {session_id}")
        return self._sessions[session_id]


# ==================== 便捷函数 ====================

def run_intelligent_crawler(
    user_input: str,
    files: list = None,
    **kwargs
) -> Dict[str, Any]:
    """
    便捷函数：运行智能爬取系统
    
    最简单的使用方式，一行代码完成所有操作。
    
    Args:
        user_input: 用户输入文本
        files: 文件列表
        **kwargs: 其他参数
        
    Returns:
        dict: 处理结果
        
    Example:
        >>> result = run_intelligent_crawler(
        ...     user_input="提取这个PDF中的所有材料数据",
        ...     files=["./documents/paper.pdf"]
        ... )
        >>> print(result['final_response'])
    """
    agent = IntelligentCrawlerAgent()
    return agent.process(user_input=user_input, files=files, **kwargs)


if __name__ == "__main__":
    # 测试代码
    print("="*60)
    print("测试 LangGraph Agent 工作流")
    print("="*60)
    
    try:
        agent = IntelligentCrawlerAgent()
        
        test_result = agent.process(
            user_input="请帮我提取文档中的材料数据并上传到数据库",
            files=[]
        )
        
        print("\n最终响应:")
        print(test_result.get("final_response", "无响应"))
        
    except Exception as e:
        print(f"\n❌ 测试失败: {e}")
        import traceback
        traceback.print_exc()
