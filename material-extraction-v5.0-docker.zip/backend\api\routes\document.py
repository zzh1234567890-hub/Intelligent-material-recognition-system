from __future__ import annotations

import time as _time
import os as _os
from fastapi import APIRouter, UploadFile, File, HTTPException, Query
import uuid
import json

from backend.models.schemas import (
    DocumentUploadResponse,
    DataPreviewResponse,
    ConfirmWriteResponse,
    UploadToMySQLResponse,
    FigureExtractionResponse,
    ErrorResponse
)
from backend.config import get_settings
from backend.utils.session_manager import get_session_manager

router = APIRouter(prefix="/api/document", tags=["文档处理"])

settings = get_settings()

session_manager = get_session_manager()


@router.post("/upload", response_model=DocumentUploadResponse)
async def upload_document(file: UploadFile = File(...)):
    """
    上传文档并解析内容

    - **file**: 支持的格式：PDF (.pdf), Word (.docx), Markdown (.md)

    注意：Session 会持久化到文件，7天内有效，可随时继续操作。
    """
    from backend.tools.everything_read import everything_read

    try:
        if not file.filename:
            raise HTTPException(status_code=400, detail="文件名不能为空")

        _t0 = _time.monotonic()
        session_id = session_manager.create({
            "file_name": file.filename,
            "status": "uploading"
        })

        raw_content = await file.read()

        import os as _os
        import tempfile as _tf
        _pdf_temp_dir = _os.path.join(_os.path.abspath(settings.OUTPUT_DIR), "_temp", "_uploads")
        _os.makedirs(_pdf_temp_dir, exist_ok=True)
        _safe_name = _os.path.basename(file.filename)
        _pdf_temp_path = _os.path.join(_pdf_temp_dir, _safe_name)
        with open(_pdf_temp_path, "wb") as _pf:
            _pf.write(raw_content)

        class FileWrapper:
            def __init__(self, filename, content):
                self.filename = filename
                self.name = filename
                self._content = content

            def read(self):
                return self._content

        wrapped_file = FileWrapper(file.filename, raw_content)

        reader = everything_read()
        _t1 = _time.monotonic()
        content = reader.read(wrapped_file)
        _t2 = _time.monotonic()
        print(f"[API ⏱] Upload + PDF parse: ({_t2 - _t0:.1f}s) = upload({_t1 - _t0:.1f}s) + parse({_t2 - _t1:.1f}s)")

        session_manager.update(session_id, {
            "status": "uploaded",
            "content": content,
            "file_type": reader.get_file_type(),
            "content_length": len(content),
            "pdf_temp_path": _pdf_temp_path,
        })

        return DocumentUploadResponse(
            status="success",
            message="文档上传并解析成功",
            file_name=file.filename,
            file_type=reader.get_file_type(),
            content_length=len(content),
            session_id=session_id
        )

    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"文档处理失败: {str(e)}")


@router.post("/extract", response_model=DataPreviewResponse)
async def extract_data(
    session_id: str = Query(..., description="会话ID（从上传接口获取，7天内有效）")
):
    """
    使用 LLM 从已上传的文档中提取多表结构数据（v2多表模式）

    - **session_id**: 上传文档时返回的会话ID

    输出：material_data(主表) + mix_proportions + fibers + heating_protocols + test_result_group 等
    """
    from backend.tools.get_data_v2 import get_data_v2

    session = session_manager.get(session_id)

    if not session:
        raise HTTPException(status_code=404, detail="会话不存在或已过期")

    allowed_statuses = ["uploaded", "extracted", "extract_failed"]
    if session.get("status") not in allowed_statuses:
        raise HTTPException(status_code=400, detail="当前状态不允许此操作，当前状态：" + session.get("status") + "（需要先上传文档）")

    try:
        _t0 = _time.monotonic()
        llm_client = _get_llm_client()
        extractor = get_data_v2(llm_client=llm_client)

        data = extractor.extract(session["content"])

        llm_raw_response = getattr(extractor, '_last_llm_response', None)

        preview_info = extractor.preview()

        # --- 自动提取图表 ---
        figures_info = []
        pdf_temp_path = session.get("pdf_temp_path")
        paper_code_from_data = None

        if data and isinstance(data, dict):
            md_rows = data.get("material_data", [])
            if isinstance(md_rows, list) and len(md_rows) > 0:
                paper_code_from_data = md_rows[0].get("paper_code")

        if pdf_temp_path and _os.path.exists(pdf_temp_path):
            try:
                from backend.tools.figure_extractor import PDFFiguresExtractor
                fig_extractor = PDFFiguresExtractor()
                if fig_extractor.is_available():
                    _tf0 = _time.monotonic()
                    figures_info = fig_extractor.extract_pdf(
                        pdf_temp_path,
                        paper_code=paper_code_from_data,
                    )
                    _tf1 = _time.monotonic()
                    test_data_count = sum(1 for f in figures_info if f.get("is_test_data"))
                    print(f"[API] Figure extraction: {len(figures_info)} figures ({test_data_count} test-data) in {_tf1 - _tf0:.1f}s")
            except Exception as fig_err:
                print(f"[API] Figure extraction skipped: {fig_err}")

        session_manager.update(session_id, {
            "status": "extracted",
            "data": data,
            "preview_info": preview_info,
            "llm_raw_response": llm_raw_response,
            "figures": figures_info,
        })

        total_records = preview_info.get("total_records", 0)
        tables_with_data = preview_info.get("tables_with_data", 0)
        
        print(f"\n[DEBUG] 数据提取完成:")
        print(f"  - 总记录数: {total_records}")
        print(f"  - 有数据的表: {tables_with_data}")
        print(f"  - 原始数据表数: {len([k for k in data.keys() if k != '_meta'])}")

        preview_items = []
        tables_summary = preview_info.get("tables", {})
        
        for tname, tinfo in tables_summary.items():
            rows = data.get(tname, [])
            row_count = len(rows) if isinstance(rows, list) else 0
            print(f"  - 表 {tname}: {row_count} 条")
            
            if isinstance(rows, list) and len(rows) > 0:
                for row in rows[:10]:
                    flat_row = {"_table": tname, "_desc": tinfo.get("description", "")}
                    for k, v in list(row.items())[:8]:
                        if v is not None:
                            flat_row[k] = str(v)[:80]
                    preview_items.append(flat_row)
                if len(rows) > 10:
                    preview_items.append({"_table": tname, "_more": f"... 还有 {len(rows)-10} 条"})
        
        print(f"  - 预览项总数: {len(preview_items)}")
        
        # 如果没有预览数据，生成一个提示
        if len(preview_items) == 0 and total_records > 0:
            print("  [WARN] 有数据但预览项为空，尝试从原始数据生成...")
            for tname, rows in data.items():
                if tname == "_meta":
                    continue
                if isinstance(rows, list) and len(rows) > 0:
                    for row in rows[:5]:
                        flat_row = {"_table": tname}
                        for k, v in list(row.items())[:6]:
                            if v is not None:
                                flat_row[k] = str(v)[:80]
                        preview_items.append(flat_row)
                    print(f"    从 {tname} 生成了 {min(len(rows), 5)} 条预览")

        summary_data = {
            "总记录数": total_records,
            "正常记录": total_records,
            "异常记录": len(preview_info.get("errors", [])),
            "数据表数": tables_with_data,
            "is_multi_table": True,
        }
        for tname, tinfo in tables_summary.items():
            cnt = tinfo.get("total_rows", 0)
            if cnt > 0:
                summary_data[f"表_{tname}"] = cnt

        print(f"[DEBUG] 准备返回响应:")
        print(f"  - preview_items: {len(preview_items)} 条")
        print(f"  - summary: {json.dumps(summary_data, ensure_ascii=False)}")

        _t_done = _time.monotonic()
        print(f"[API ⏱] Extract total: ({_t_done - _t0:.1f}s)")

        return DataPreviewResponse(
            status="success",
            total=total_records,
            preview_items=preview_items,
            summary=summary_data,
            session_id=session_id,
            tables_with_data=tables_with_data,
            is_multi_table=True,
            figures=figures_info
        )

    except Exception as e:
        session_manager.update(session_id, {
            "status": "extract_failed",
            "error": str(e)
        })
        raise HTTPException(status_code=500, detail=f"数据提取失败: {str(e)}")


@router.get("/debug/{session_id}")
async def debug_session(session_id: str):
    """调试接口：查看会话的详细信息"""
    session = session_manager.get(session_id)

    if not session:
        raise HTTPException(status_code=404, detail="会话不存在或已过期")

    llm_raw_response = session.get("llm_raw_response")

    content_preview = session.get("content", "")
    if len(content_preview) > 500:
        content_preview = content_preview[:500] + f"... (共 {len(session.get('content', ''))} 字符)"

    data = session.get("data", {})
    table_counts = {}
    if isinstance(data, dict):
        for tname, rows in data.items():
            if tname != "_meta" and isinstance(rows, list):
                table_counts[tname] = len(rows)

    return {
        "session_id": session_id,
        "status": session.get("status"),
        "file_name": session.get("file_name"),
        "file_type": session.get("file_type"),
        "content_length": session.get("content_length", 0),
        "content_preview": content_preview,
        "table_counts": table_counts,
        "llm_raw_response": (llm_raw_response[:1000] + "...") if llm_raw_response and len(llm_raw_response) > 1000 else llm_raw_response,
        "created_at": session.get("created_at"),
        "updated_at": session.get("updated_at"),
        "expires_at": session.get("expires_at"),
        "error": session.get("error")
    }


@router.post("/confirm-write", response_model=ConfirmWriteResponse)
async def confirm_and_write(
    session_id: str = Query(..., description="会话ID")
):
    """
    确认预览数据并将多表数据写入 Excel 文件（v2多Sheet模式）

    - **session_id**: 提取数据时的会话ID
    """
    from backend.tools.format_data_v2 import format_data_v2
    from backend.tools.get_data_v2 import get_data_v2
    import os

    output_dir = os.path.abspath(settings.OUTPUT_DIR)
    os.makedirs(output_dir, exist_ok=True)

    session = session_manager.get(session_id)

    if not session:
        raise HTTPException(status_code=404, detail="会话不存在或已过期")

    allowed_statuses = ["extracted", "write_failed", "confirmed"]
    if session.get("status") not in allowed_statuses:
        raise HTTPException(status_code=400, detail="请先提取数据（当前状态：" + session.get("status", "unknown") + "）")

    try:
        data = session.get("data", {})

        if not data or (isinstance(data, dict) and all(
            isinstance(v, list) and len(v) == 0 for k, v in data.items() if k != "_meta"
        )):
            raise ValueError("提取数据为空，无法生成Excel")

        excel = format_data_v2(output_dir)
        excel.create_or_open()

        try:
            result = excel.write_all(data)
        except Exception as write_err:
            raise RuntimeError(f"Excel写入失败: {str(write_err)}")

        # 获取重映射后的数据（ID已递增）
        remapped_data = result.get("remapped_data", data)

        filepath = None
        try:
            filepath = excel.save()
        except Exception as save_err:
            raise RuntimeError(f"Excel保存失败: {str(save_err)}")
        finally:
            try:
                excel.close()
            except:
                pass

        summary = result.get("_summary", {})
        added = summary.get('total_added', 0)
        skipped = summary.get('total_skipped', 0)
        new_paper_codes = summary.get('new_paper_codes', [])
        sheets_written = sum(1 for k, v in result.items() if k not in ("_summary", "remapped_data") and isinstance(v, tuple) and v[0] > 0)

        sample_data = []
        for tname, tresult in result.items():
            if tname in ("_summary", "remapped_data"):
                continue
            if isinstance(tresult, tuple):
                added_cnt = tresult[0]
            elif isinstance(tresult, dict):
                added_cnt = tresult.get("success", 0)
            else:
                continue
            if isinstance(remapped_data.get(tname), list) and remapped_data[tname]:
                sample_data.append({"table": tname, "count": added_cnt, "sample": remapped_data[tname][0]})

        # 用重映射后的数据更新session（用于后续PostgreSQL上传）
        session_manager.update(session_id, {
            "status": "confirmed",
            "excel_path": filepath,
            "written_count": added,
            "skipped_duplicates": skipped,
            "sheets_written": sheets_written,
            "data": remapped_data,
            "new_paper_codes": new_paper_codes,
        })

        return ConfirmWriteResponse(
            status="success",
            message=f"多表数据已写入 Excel（{sheets_written} 个Sheet，新增 {added} 条，跳过重复 {skipped} 条，新编号: {', '.join(new_paper_codes)}）",
            written_count=added,
            excel_path=filepath,
            data_sample=sample_data[:5],
            skipped_duplicates=skipped,
            sheets_written=sheets_written
        )

    except Exception as e:
        session_manager.update(session_id, {
            "status": "write_failed",
            "error": str(e)
        })
        raise HTTPException(status_code=500, detail=f"写入 Excel 失败: {str(e)}")


@router.post("/upload-mysql", response_model=UploadToMySQLResponse)
async def upload_to_mysql(
    session_id: str = Query(..., description="会话ID"),
    force: bool = Query(False, description="强制导入模式")
):
    """
    将多表数据上传到 PostgreSQL 数据库（v2多表模式）

    - **session_id**: 确认写入时的会话ID
    - **force**: 强制导入模式
    """
    from backend.tools.upload_data_v2 import PostgresUploaderV2

    session = session_manager.get(session_id)

    if not session:
        raise HTTPException(status_code=404, detail="会话不存在或已过期")

    allowed_statuses = ["confirmed", "upload_failed", "completed"]
    if session.get("status") not in allowed_statuses:
        raise HTTPException(status_code=400, detail="请先确认写入 Excel（当前状态：" + session.get("status", "unknown") + "）")

    try:
        data = session.get("data", {})

        uploader = PostgresUploaderV2(
            host=settings.POSTGRES_HOST,
            port=settings.POSTGRES_PORT,
            user=settings.POSTGRES_USER,
            password=settings.POSTGRES_PASSWORD,
            database=settings.POSTGRES_DATABASE,
            force_mode=force
        )

        with uploader:
            result = uploader.upload_from_dict(data)

        tables_uploaded = sum(1 for t, r in result.get("tables", {}).items() if isinstance(r, dict) and r.get("success", 0) > 0)

        session_manager.update(session_id, {
            "status": "completed",
            "pg_result": result
        })

        message = (
            f"✅ 多表导入完成！成功 {result['total_success']} 条 "
            f"(更新 {result.get('total_updated', 0)} 条)，"
            f"跳过 {result['total_skipped']} 条，"
            f"{tables_uploaded} 张表有数据"
        ) if force else (
            f"数据已成功上传到 PostgreSQL ({tables_uploaded} 张表)，"
            f"新增 {result['total_success']} 条，"
            f"跳过重复 {result['total_skipped']} 条"
        )

        return UploadToMySQLResponse(
            status="success",
            message=message,
            success_count=result["total_success"],
            failed_count=result["total_failed"],
            total_count=result["total_success"] + result["total_skipped"] + result["total_failed"],
            skipped_duplicates=result["total_skipped"],
            table_name="material_data (+ 子表)",
            errors=result.get("errors", []),
            tables_uploaded=tables_uploaded
        )

    except Exception as e:
        session_manager.update(session_id, {
            "status": "upload_failed",
            "error": str(e)
        })
        raise HTTPException(status_code=500, detail=f"PostgreSQL 上传失败: {str(e)}")


# ==================== 图表提取接口 ====================

@router.post("/extract-figures", response_model=FigureExtractionResponse)
async def extract_figures(file: UploadFile = File(...)):
    """
    使用 PDFFigures 2.0 从 PDF 中提取与 test_result 参数相关的图表

    - **file**: PDF 文件

    返回提取到的图表列表及元数据，图片保存到 output/figures/ 目录
    """
    from backend.tools.figure_extractor import PDFFiguresExtractor

    try:
        if not file.filename:
            raise HTTPException(status_code=400, detail="文件名不能为空")
        if not file.filename.lower().endswith(".pdf"):
            raise HTTPException(status_code=400, detail="仅支持 PDF 文件")

        extractor = PDFFiguresExtractor()
        if not extractor.is_available():
            raise HTTPException(
                status_code=503,
                detail="PDFFigures 2.0 不可用，请检查 Java 和 pdffigures2.jar 是否已安装"
            )

        raw_content = await file.read()
        _t0 = _time.monotonic()
        figures = extractor.extract_from_bytes(raw_content, file.filename)
        _t1 = _time.monotonic()

        test_data_count = sum(1 for f in figures if f.get("is_test_data"))

        return FigureExtractionResponse(
            status="success",
            message=f"提取完成：{len(figures)} 张图表，其中 {test_data_count} 张与试验数据相关",
            total_figures=len(figures),
            test_data_figures=test_data_count,
            figures=figures,
            extraction_time_seconds=round(_t1 - _t0, 1)
        )

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"图表提取失败: {str(e)}")


@router.post("/extract-figures-batch", response_model=FigureExtractionResponse)
async def extract_figures_batch(
    directory: str = Query(..., description="PDF 文件所在目录的绝对路径"),
    recursive: bool = Query(True, description="是否递归子目录"),
):
    """
    批量提取目录下所有 PDF 中与 test_result 参数相关的图表

    - **directory**: PDF 文件所在目录
    - **recursive**: 是否递归子目录

    返回提取到的图表列表及元数据，图片保存到 output/figures/ 目录
    """
    from backend.tools.figure_extractor import PDFFiguresExtractor

    try:
        extractor = PDFFiguresExtractor()
        if not extractor.is_available():
            raise HTTPException(
                status_code=503,
                detail="PDFFigures 2.0 不可用，请检查 Java 和 pdffigures2.jar 是否已安装"
            )

        _t0 = _time.monotonic()
        figures = extractor.extract_directory(directory, recursive=recursive)
        _t1 = _time.monotonic()

        test_data_count = sum(1 for f in figures if f.get("is_test_data"))

        return FigureExtractionResponse(
            status="success",
            message=f"批量提取完成：{len(figures)} 张图表，其中 {test_data_count} 张与试验数据相关",
            total_figures=len(figures),
            test_data_figures=test_data_count,
            figures=figures,
            extraction_time_seconds=round(_t1 - _t0, 1)
        )

    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"批量图表提取失败: {str(e)}")


# ==================== Session 管理接口 ====================

@router.get("/sessions")
async def list_sessions():
    """列出所有活跃的 Session"""
    sessions = session_manager.list_all()
    return {"sessions": sessions, "total": len(sessions)}


@router.delete("/sessions/{session_id}")
async def delete_session(session_id: str):
    """删除指定 Session"""
    success = session_manager.delete(session_id)
    if success:
        return {"status": "success", "message": f"Session {session_id} 已删除"}
    else:
        raise HTTPException(status_code=404, detail="Session 不存在")


# ==================== 工具函数 ====================

def _get_llm_client():
    """获取 LLM 客户端实例（带缓存）"""
    if not hasattr(_get_llm_client, "_client"):
        from backend.utils.llm_client import create_deepseek_client
        _get_llm_client._client = create_deepseek_client()
    return _get_llm_client._client
