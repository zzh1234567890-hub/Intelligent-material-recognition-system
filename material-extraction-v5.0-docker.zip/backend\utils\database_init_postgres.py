from __future__ import annotations

import os
from typing import Optional, Dict, Any
from datetime import datetime

try:
    import psycopg
    from psycopg import sql as pg_sql
    HAS_POSTGRES = True
except ImportError:
    HAS_POSTGRES = False

from backend.config import get_settings


class PostgresDatabaseInitializer:
    """
    PostgreSQL 数据库初始化工具
    
    功能：
    1. 创建数据库（如果不存在）
    2. 创建材料数据表结构
    3. 验证表结构
    4. 初始化基础数据
    
    使用示例：
        initializer = PostgresDatabaseInitializer()
        initializer.initialize_all()
    """

    def __init__(self):
        if not HAS_POSTGRES:
            raise ImportError("请安装 PostgreSQL 驱动: pip install 'psycopg[binary]'")

        settings = get_settings()

        self.host = settings.POSTGRES_HOST
        self.port = settings.POSTGRES_PORT
        self.user = settings.POSTGRES_USER
        self.password = settings.POSTGRES_PASSWORD
        self.database = settings.POSTGRES_DATABASE

    def _get_connection(self, db_name: Optional[str] = None):
        """获取数据库连接"""
        conn_str = f"host={self.host} port={self.port} user={self.user}"
        if self.password:
            conn_str += f" password={self.password}"
        if db_name:
            conn_str += f" dbname={db_name}"

        return psycopg.connect(conn_str)

    def initialize_all(self) -> dict:
        """一键初始化所有数据库组件"""
        results = []
        errors = []

        steps = [
            ("create_database", "创建数据库", self.create_database),
            ("create_material_table", "创建材料数据表", self.create_material_table),
            ("verify_structure", "验证表结构", self.verify_tables),
        ]

        print("\n" + "=" * 60)
        print("🗄️ PostgreSQL 数据库初始化")
        print("=" * 60)

        for step_name, description, method in steps:
            try:
                print(f"\n▶️ {description}...")
                result = method()
                results.append({
                    "step": step_name,
                    "status": "success",
                    "result": result
                })
                print(f"✅ {description}完成")

            except Exception as e:
                error_msg = f"{description}失败: {str(e)}"
                errors.append(error_msg)
                print(f"❌ {error_msg}")
                results.append({
                    "step": step_name,
                    "status": "failed",
                    "error": str(e)
                })

        summary = {
            "success": len(errors) == 0,
            "total_steps": len(steps),
            "completed_steps": len(results) - len(errors),
            "failed_steps": len(errors),
            "results": results,
            "errors": errors
        }

        print("\n" + "=" * 60)
        if summary["success"]:
            print("🎉 PostgreSQL 数据库初始化全部成功！")
        else:
            print(f"⚠️ 部分步骤失败 ({summary['failed_steps']}/{summary['total_steps']})")
            for err in errors:
                print(f"   • {err}")
        print("=" * 60 + "\n")

        return summary

    def create_database(self) -> dict:
        """创建数据库（如果不存在）"""
        conn = self._get_connection(db_name=None)
        conn.autocommit = True

        with conn.cursor() as cursor:
            # 检查数据库是否存在
            cursor.execute(
                "SELECT 1 FROM pg_database WHERE datname = %s",
                (self.database,)
            )
            exists = cursor.fetchone()

            if not exists:
                cursor.execute(
                    pg_sql.SQL("CREATE DATABASE {}").format(
                        pg_sql.Identifier(self.database)
                    )
                )
                status = "created"
            else:
                status = "exists"

            return {
                "database": self.database,
                "status": status
            }

    def create_material_table(self) -> dict:
        """创建材料数据主表"""
        conn = self._get_connection(db_name=self.database)

        create_sql = """
        CREATE TABLE IF NOT EXISTS material_data (
            id SERIAL PRIMARY KEY,
            identifier VARCHAR(100) NOT NULL DEFAULT '' UNIQUE,
            type VARCHAR(50) NOT NULL DEFAULT '',
            title TEXT,
            authors TEXT,
            journal VARCHAR(200) DEFAULT '',
            volume VARCHAR(20) DEFAULT '',
            issue VARCHAR(20) DEFAULT '',
            pages VARCHAR(50) DEFAULT '',
            year CHAR(4) DEFAULT '',
            publisher VARCHAR(200) DEFAULT '',
            doi VARCHAR(200) DEFAULT '',
            abstract TEXT,

            -- 系统字段
            source_file VARCHAR(500) DEFAULT '',
            uploaded_by VARCHAR(100),
            session_id VARCHAR(100),

            -- 时间戳
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

            -- 索引
            CONSTRAINT uk_identifier UNIQUE (identifier)
        );

        -- 创建额外索引
        CREATE INDEX IF NOT EXISTS idx_type ON material_data(type);
        CREATE INDEX IF NOT EXISTS idx_year ON material_data(year);
        CREATE INDEX IF NOT EXISTS idx_journal ON material_data(journal);
        CREATE INDEX IF NOT EXISTS idx_created_at ON material_data(created_at);

        -- 添加注释
        COMMENT ON TABLE material_data IS '材料/文献数据表';
        COMMENT ON COLUMN material_data.id IS '自增主键';
        COMMENT ON COLUMN material_data.identifier IS '唯一标识符';
        COMMENT ON COLUMN material_data.type IS '文档类型';
        COMMENT ON COLUMN material_data.title IS '标题';
        COMMENT ON COLUMN material_data.authors IS '作者';
        COMMENT ON COLUMN material_data.journal IS '期刊/来源';
        COMMENT ON COLUMN material_data.volume IS '卷号';
        COMMENT ON COLUMN material_data.issue IS '期号';
        COMMENT ON COLUMN material_data.pages IS '页码';
        COMMENT ON COLUMN material_data.year IS '年份';
        COMMENT ON COLUMN material_data.publisher IS '出版社';
        COMMENT ON COLUMN material_data.doi IS 'DOI';
        COMMENT ON COLUMN material_data.abstract IS '摘要/备注';
        COMMENT ON COLUMN material_data.source_file IS '来源文件名';
        COMMENT ON COLUMN material_data.uploaded_by IS '上传用户';
        COMMENT ON COLUMN material_data.session_id IS '处理会话ID';
        COMMENT ON COLUMN material_data.created_at IS '创建时间';
        COMMENT ON COLUMN material_data.updated_at IS '更新时间';

        -- 创建更新时间戳触发器
        CREATE OR REPLACE FUNCTION update_updated_at_column()
        RETURNS TRIGGER AS $$
        BEGIN
            NEW.updated_at = CURRENT_TIMESTAMP;
            RETURN NEW;
        END;
        $$ language 'plpgsql';

        DROP TRIGGER IF EXISTS update_material_data_updated_at ON material_data;
        CREATE TRIGGER update_material_data_updated_at
            BEFORE UPDATE ON material_data
            FOR EACH ROW
            EXECUTE FUNCTION update_updated_at_column();
        """

        with conn.cursor() as cursor:
            cursor.execute(create_sql)
            conn.commit()

            return {
                "table": "material_data",
                "columns": 17,
                "indexes": 5,
                "status": "created_or_exists"
            }

    def verify_tables(self) -> dict:
        """验证所有必要的表是否存在且结构正确"""
        conn = self._get_connection(db_name=self.database)

        required_tables = ["material_data"]
        verification_results = {}

        with conn.cursor() as cursor:
            for table in required_tables:
                # 检查表是否存在
                cursor.execute("""
                    SELECT EXISTS (
                        SELECT FROM information_schema.tables 
                        WHERE table_schema = 'public' 
                        AND table_name = %s
                    );
                """, (table,))
                exists = cursor.fetchone()[0]

                if exists:
                    # 获取列数
                    cursor.execute("""
                        SELECT COUNT(*)
                        FROM information_schema.columns
                        WHERE table_schema = 'public'
                        AND table_name = %s;
                    """, (table,))
                    columns = cursor.fetchone()[0]

                    # 获取行数
                    cursor.execute(pg_sql.SQL("SELECT COUNT(*) FROM {}").format(
                        pg_sql.Identifier(table)
                    ))
                    row_count = cursor.fetchone()[0]

                    verification_results[table] = {
                        "exists": True,
                        "columns": columns,
                        "row_count": row_count,
                        "status": "ok"
                    }
                else:
                    verification_results[table] = {
                        "exists": False,
                        "status": "missing"
                    }

        return verification_results


def test_postgres_connection() -> dict:
    """
    测试 PostgreSQL 连接是否正常

    Returns:
        dict: 连接测试结果
    """
    if not HAS_POSTGRES:
        return {
            "connected": False,
            "error": "PostgreSQL 驱动未安装，请运行: pip install 'psycopg[binary]'"
        }

    from backend.config import get_settings

    settings = get_settings()

    try:
        conn_str = f"host={settings.POSTGRES_HOST} port={settings.POSTGRES_PORT} user={settings.POSTGRES_USER}"
        if settings.POSTGRES_PASSWORD:
            conn_str += f" password={settings.POSTGRES_PASSWORD}"

        conn = psycopg.connect(conn_str)

        with conn.cursor() as cursor:
            cursor.execute("SELECT version()")
            version = cursor.fetchone()[0]

            cursor.execute("SELECT current_database()")
            current_db = cursor.fetchone()[0] or "(none)"

        conn.close()

        return {
            "connected": True,
            "version": version[:50],
            "host": f"{settings.POSTGRES_HOST}:{settings.POSTGRES_PORT}",
            "user": settings.POSTGRES_USER,
            "database": current_db,
            "error": None
        }

    except Exception as e:
        return {
            "connected": False,
            "version": None,
            "host": f"{settings.POSTGRES_HOST}:{settings.POSTGRES_PORT}",
            "user": settings.POSTGRES_USER,
            "database": None,
            "error": str(e)
        }


if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("🔍 测试 PostgreSQL 连接")
    print("=" * 60)

    connection_result = test_postgres_connection()

    if connection_result["connected"]:
        print("✅ PostgreSQL 连接成功！")
        print(f"   • 版本：{connection_result['version']}")
        print(f"   • 主机：{connection_result['host']}")
        print(f"   • 用户：{connection_result['user']}")
        print(f"   • 当前库：{connection_result['database']}")

        print("\n是否要初始化数据库？(y/n): ", end="")
        choice = input().strip().lower()

        if choice == 'y':
            initializer = PostgresDatabaseInitializer()
            result = initializer.initialize_all()

            if result["success"]:
                print("\n✨ 现在可以启动系统了！")
            else:
                print("\n⚠️ 请检查错误信息后重试")
    else:
        print("❌ PostgreSQL 连接失败！")
        print(f"   错误：{connection_result['error']}")
        print("\n请检查：")
        print("   1. PostgreSQL 服务是否已启动")
        print("   2. 配置文件 .env 中的 POSTGRES_* 设置是否正确")
        print("   3. 用户名密码是否正确")
        print("   4. 是否已安装 psycopg 驱动：pip install 'psycopg[binary]'")
