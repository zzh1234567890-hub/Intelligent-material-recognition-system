from __future__ import annotations

import os
from typing import Optional, Dict, Any, List

import pymysql
from openpyxl import load_workbook


class upload_data:
    """
    MySQL 数据上传工具：读取 Excel 文件并上传到 MySQL 数据库
    
    支持两种使用方式：
    - upload_from_excel(excel_handler): 从 format_data 对象上传
    - upload_from_file(filepath): 从文件路径直接上传
    """

    description = "MySQL 数据上传工具（支持从 Excel 文件批量导入）"

    DEFAULT_TABLE_NAME = "material_data"

    MYSQL_TYPE_MAP = {
        "id": "VARCHAR(50)",
        "identifier": "VARCHAR(100)",
        "type": "VARCHAR(50)",
        "title": "TEXT",
        "authors": "TEXT",
        "journal": "VARCHAR(200)",
        "volume": "VARCHAR(20)",
        "issue": "VARCHAR(20)",
        "pages": "VARCHAR(50)",
        "year": "CHAR(4)",
        "publisher": "VARCHAR(200)",
        "doi": "VARCHAR(200)",
        "abstract": "TEXT",
    }

    def __init__(
        self,
        host: str = "localhost",
        port: int = 3306,
        user: str = "root",
        password: str = "",
        database: str = "material_db",
        charset: str = "utf8mb4"
    ):
        self.host = host
        self.port = port
        self.user = user
        self.password = password
        self.database = database
        self.charset = charset
        
        self.connection = None
        self.cursor = None
        self.table_name = None
        self.uploaded_count = 0
        self.error_records = []

    def upload_from_excel(
        self,
        excel_handler,
        table_name: Optional[str] = None,
        if_exists: str = "append"
    ) -> dict:
        """
        从 format_data 对象上传数据到 MySQL（推荐方式）
        
        Args:
            excel_handler: 已完成数据写入的 format_data 实例
            table_name: 目标表名，默认使用 DEFAULT_TABLE_NAME
            if_exists: 表已存在时的处理方式
                      - 'append': 追加数据（默认）
                      - 'replace': 删除旧表重建
                      - 'fail': 抛出异常
            
        Returns:
            dict: 上传结果统计 {
                'success': 成功条数,
                'failed': 失败条数,
                'total': 总条数,
                'table_name': 表名,
                'errors': 错误详情列表
            }
        """
        if not hasattr(excel_handler, 'filepath') or not excel_handler.filepath:
            raise ValueError("format_data 对象中没有有效的文件路径，请先确认已保存")

        if not os.path.exists(excel_handler.filepath):
            raise FileNotFoundError(f"Excel 文件不存在：{excel_handler.filepath}")

        return self._upload_file(
            filepath=excel_handler.filepath,
            table_name=table_name,
            if_exists=if_exists
        )

    def upload_from_file(
        self,
        filepath: str,
        table_name: Optional[str] = None,
        if_exists: str = "append"
    ) -> dict:
        """
        直接从 Excel 文件路径上传数据到 MySQL
        
        Args:
            filepath: Excel 文件的绝对/相对路径
            table_name: 目标表名
            if_exists: 表已存在时的处理方式
            
        Returns:
            dict: 上传结果统计
        """
        if not os.path.exists(filepath):
            raise FileNotFoundError(f"文件不存在：{filepath}")

        return self._upload_file(
            filepath=filepath,
            table_name=table_name,
            if_exists=if_exists
        )

    def _upload_file(self, filepath: str, table_name: Optional[str], if_exists: str) -> dict:
        """内部方法：执行完整的上传流程"""
        self.table_name = table_name or self.DEFAULT_TABLE_NAME

        try:
            data = self._read_excel(filepath)
            
            if not data:
                return {"success": 0, "failed": 0, "total": 0, "table_name": self.table_name, "errors": []}

            self._connect()
            self._ensure_table(data[0], if_exists)
            result = self._insert_batch(data)

            return result

        finally:
            self._disconnect()

    def _read_excel(self, filepath: str) -> list[dict]:
        """读取 Excel 文件并返回字典列表"""
        wb = load_workbook(filepath, read_only=True)
        sheet = wb.active
        
        headers = []
        for cell in sheet[1]:
            headers.append(str(cell.value) if cell.value else f"col_{cell.column}")

        data = []
        for row_idx, row in enumerate(sheet.iter_rows(min_row=2, values_only=True), start=2):
            record = {}
            for col_idx, value in enumerate(row):
                field_name = headers[col_idx] if col_idx < len(headers) else f"col_{col_idx}"
                record[field_name] = value if value is not None else ""
            
            if any(record.values()):
                data.append(record)

        wb.close()

        return data

    def _connect(self):
        """建立数据库连接"""
        try:
            self.connection = pymysql.connect(
                host=self.host,
                port=self.port,
                user=self.user,
                password=self.password,
                database=self.database,
                charset=self.charset,
                cursorclass=pymysql.cursors.DictCursor
            )
            self.cursor = self.connection.cursor()
        except Exception as e:
            raise RuntimeError(f"数据库连接失败: {e}")

    def _disconnect(self):
        """关闭数据库连接"""
        if self.cursor:
            self.cursor.close()
        if self.connection:
            self.connection.close()
            self.cursor = None
            self.connection = None

    def _ensure_table(self, sample_record: dict, if_exists: str):
        """确保目标表存在，不存在则创建"""
        self.cursor.execute(f"SHOW TABLES LIKE '{self.table_name}'")
        exists = self.cursor.fetchone() is not None

        if exists:
            if if_exists == "fail":
                raise RuntimeError(f"表 {self.table_name} 已存在")
            elif if_exists == "replace":
                self.cursor.execute(f"DROP TABLE `{self.table_name}`")
                self._create_table(sample_record)
        else:
            self._create_table(sample_record)

    def _create_table(self, sample_record: dict):
        """创建新表"""
        columns = []
        columns.append("id INT AUTO_INCREMENT PRIMARY KEY")
        
        for key in sample_record.keys():
            mysql_type = self.MYSQL_TYPE_MAP.get(key, "TEXT")
            safe_key = self._escape_column_name(key)
            columns.append(f"`{safe_key}` {mysql_type}`")

        columns.append("created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
        columns.append("updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")

        create_sql = f"""
        CREATE TABLE IF NOT EXISTS `{self.table_name}` (
            {', '.join(columns)}
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        """

        self.cursor.execute(create_sql)
        self.connection.commit()

    @staticmethod
    def _escape_column_name(name: str) -> str:
        """转义列名中的特殊字符"""
        return name.replace("`", "``").replace("'", "\\'")

    def _insert_batch(self, data: list[dict]) -> dict:
        """批量插入数据（自动去重）"""
        if not data:
            return {"success": 0, "failed": 0, "total": 0, "skipped_duplicates": 0, "table_name": self.table_name, "errors": []}

        # 获取所有列名，但排除 'id'（自增主键，由数据库自动生成）
        keys = [k for k in list(data[0].keys()) if k.lower() != 'id']
        
        if not keys:
            return {"success": 0, "failed": 0, "total": 0, "skipped_duplicates": 0, "table_name": self.table_name, "errors": ["没有可插入的列"]}
        
        # 检查 identifier 列是否存在
        has_identifier = 'identifier' in keys
        
        # 如果有 identifier 列，先获取数据库中已有的 identifier 用于去重
        existing_identifiers = set()
        if has_identifier:
            try:
                self.cursor.execute(f"SELECT DISTINCT `identifier` FROM `{self.table_name}` WHERE `identifier` IS NOT NULL AND `identifier` != ''")
                rows = self.cursor.fetchall()
                existing_identifiers = {row['identifier'] for row in rows}
                
                if existing_identifiers:
                    print(f"📊 MySQL 中已有 {len(existing_identifiers)} 条记录的 identifier")
            except Exception as e:
                print(f"⚠️ 查询已有 identifier 失败: {e}")
        
        placeholders = ", ".join(["%s"] * len(keys))
        columns = ", ".join([f"`{self._escape_column_name(k)}`" for k in keys])
        
        insert_sql = f"""
        INSERT INTO `{self.table_name}` ({columns})
        VALUES ({placeholders})
        ON DUPLICATE KEY UPDATE updated_at = CURRENT_TIMESTAMP
        """

        success_count = 0
        failed_count = 0
        skipped_duplicates = 0
        errors = []

        for idx, record in enumerate(data, 1):
            # 去重检查：如果 identifier 已存在则跳过
            if has_identifier:
                identifier = str(record.get('identifier', '')).strip()
                if identifier and identifier in existing_identifiers:
                    skipped_duplicates += 1
                    continue
            
            # 跳过 id 字段
            values = [record.get(key, "") for key in keys]
            
            try:
                self.cursor.execute(insert_sql, values)
                success_count += 1
                
                # 记录新插入的 identifier
                if has_identifier:
                    new_identifier = str(record.get('identifier', '')).strip()
                    if new_identifier:
                        existing_identifiers.add(new_identifier)
                    
            except Exception as e:
                failed_count += 1
                error_info = {
                    "row_index": idx,
                    "error": str(e),
                    "data_preview": {k: str(v)[:50] for k, v in list(record.items())[:3]}
                }
                errors.append(error_info)
                self.error_records.append(error_info)

        self.connection.commit()
        self.uploaded_count = success_count

        result = {
            "success": success_count,
            "failed": failed_count,
            "total": len(data),
            "skipped_duplicates": skipped_duplicates,
            "table_name": self.table_name,
            "errors": errors
        }
        
        if skipped_duplicates > 0:
            print(f"✅ 上传完成: 新增 {success_count} 条, 跳过重复 {skipped_duplicates} 条, 失败 {failed_count} 条")
        
        return result

    def test_connection(self) -> bool:
        """测试数据库连接是否正常"""
        try:
            self._connect()
            version = self.cursor.execute("SELECT VERSION()")
            version = self.cursor.fetchone()["VERSION()"]
            return True
        except Exception as e:
            return False
        finally:
            self._disconnect()

    def preview_table(self, limit: int = 5) -> list[dict]:
        """预览目标表中的数据"""
        if not self.table_name:
            raise ValueError("未指定表名")

        try:
            self._connect()
            self.cursor.execute(f"SELECT * FROM `{self.table_name}` LIMIT {limit}")
            rows = self.cursor.fetchall()
            
            return rows
        finally:
            self._disconnect()

    def get_upload_stats(self) -> dict:
        """获取最近一次上传的统计信息"""
        return {
            "uploaded_count": self.uploaded_count,
            "error_count": len(self.error_records),
            "table_name": self.table_name,
            "database": self.database,
            "last_errors": self.error_records[-5:] if self.error_records else []
        }

    @property
    def is_connected(self) -> bool:
        """检查是否已连接数据库"""
        return self.connection is not None and self.connection.open
