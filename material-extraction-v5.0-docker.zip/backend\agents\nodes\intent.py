"""
意图分析节点

使用 LLM 分析用户的自然语言输入，理解用户意图
"""

from typing import Dict, Any
from backend.agents.state import AgentState, update_state_timestamp


INTENT_ANALYSIS_PROMPT = """你是一个智能意图识别助手。请分析用户的输入，提取关键信息。

## 用户输入：
{user_input}

## 已上传文件信息：
{file_info}

## 分析要求：

请从用户输入中识别以下信息，以 JSON 格式返回：

1. **action** (动作): 用户想要执行的操作
   - "extract_upload": 提取数据并上传到数据库
   - "extract_only": 仅提取数据，不上传
   - "query_data": 查询已有数据
   - "preview_data": 预览文档内容
   - "other": 其他操作

2. **target** (目标): 用户关注的数据类型
   - "material_data": 材料相关数据
   - "literature_data": 文献/论文数据
   - "all_data": 所有数据
   - "specific_field": 特定字段（在 details 中说明）

3. **data_format** (数据格式): 期望的输出格式
   - "mysql": 存入 MySQL 数据库
   - "excel": 导出为 Excel 文件
   - "json": 返回 JSON 格式
   - "preview": 仅预览

4. **priority** (优先级): 
   - "high": 高优先级（需要立即处理）
   - "normal": 普通优先级
   - "low": 低优先级

5. **confidence** (置信度): 0-1 之间的数值，表示意图识别的确定性

6. **details** (详细信息): 补充说明或特殊要求

## 返回格式（严格 JSON）：
```json
{{
    "action": "extract_upload",
    "target": "material_data",
    "data_format": ["mysql", "excel"],
    "priority": "high",
    "confidence": 0.95,
    "details": "用户希望提取所有材料数据并上传到MySQL"
}}
```

请只返回 JSON，不要包含其他文字。"""


def intent_analysis_node(state: AgentState) -> AgentState:
    """
    意图分析节点
    
    功能：
    1. 接收用户输入和已上传的文件信息
    2. 调用 LLM 分析用户意图
    3. 提取结构化的意图信息
    4. 更新状态并传递给下一个节点
    
    Args:
        state: 当前 Agent 状态
        
    Returns:
        AgentState: 更新后的状态（包含 user_intent 字段）
    
    Raises:
        Exception: LLM 调用失败或解析失败时抛出异常
    """
    print("\n" + "="*60)
    print("🔍 [节点1] 意图分析")
    print("="*60)
    
    try:
        # 准备文件信息文本
        file_info = _prepare_file_info(state)
        
        # 构建提示词
        prompt = INTENT_ANALYSIS_PROMPT.format(
            user_input=state.get("user_input", ""),
            file_info=file_info
        )
        
        # 调用 LLM 进行意图分析
        llm_client = _get_llm_client()
        response = llm_client.generate(
            messages=[{"role": "user", "content": prompt}],
            temperature=0.2,
            max_tokens=500
        )
        
        # 解析响应
        intent_text = response.choices[0].message.content
        user_intent = _parse_intent_response(intent_text)
        
        # 更新状态
        state["user_intent"] = user_intent
        state["status"] = "processing"
        state = update_state_timestamp(state)
        
        # 打印结果
        _print_intent_result(user_intent)
        
        return state
        
    except Exception as e:
        error_msg = f"意图分析失败: {str(e)}"
        print(f"❌ {error_msg}")
        
        state["error_info"] = {
            "step": "intent_analysis",
            "error_type": "LLM_ERROR",
            "message": error_msg,
            "details": str(e)
        }
        state["status"] = "failed"
        state = update_state_timestamp(state)
        
        return state


def _prepare_file_info(state: AgentState) -> str:
    """准备文件信息文本"""
    files = state.get("uploaded_files", [])
    
    if not files:
        return "暂无上传的文件"
    
    file_lines = []
    for i, f in enumerate(files, 1):
        file_lines.append(
            f"{i}. {f.get('name', 'unknown')} "
            f"(类型: {f.get('type', 'unknown')}, "
            f"大小: {_format_size(f.get('size', 0))})"
        )
    
    return "\n".join(file_lines)


def _format_size(size_bytes: int) -> str:
    """格式化文件大小"""
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f} KB"
    else:
        return f"{size_bytes / (1024 * 1024):.1f} MB"


def _parse_intent_response(response_text: str) -> Dict[str, Any]:
    """解析 LLM 返回的意图 JSON"""
    import json
    import re
    
    text = response_text.strip()
    
    if text.startswith("```"):
        match = re.search(r'```(?:json)?\s*\n?(.*?)```', text, re.DOTALL)
        if match:
            text = match.group(1).strip()
    
    try:
        intent = json.loads(text)
        
        required_fields = ["action", "target", "data_format"]
        for field in required_fields:
            if field not in intent:
                intent[field] = "unknown"
                
        if "confidence" not in intent:
            intent["confidence"] = 0.5
            
        if "priority" not in intent:
            intent["priority"] = "normal"
            
        if "details" not in intent:
            intent["details"] = ""
            
        return intent
        
    except json.JSONDecodeError:
        return {
            "action": "extract_upload",
            "target": "material_data",
            "data_format": ["mysql"],
            "confidence": 0.3,
            "priority": "normal",
            "details": f"解析失败，原始响应: {response_text[:200]}"
        }


def _print_intent_result(intent: Dict[str, Any]):
    """打印意图分析结果"""
    action_map = {
        "extract_upload": "提取数据并上传",
        "extract_only": "仅提取数据",
        "query_data": "查询数据",
        "preview_data": "预览内容"
    }
    
    target_map = {
        "material_data": "材料数据",
        "literature_data": "文献数据",
        "all_data": "全部数据"
    }
    
    print(f"\n✅ 意图识别完成：")
    print(f"   • 动作: {action_map.get(intent['action'], intent['action'])}")
    print(f"   • 目标: {target_map.get(intent['target'], intent['target'])}")
    print(f"   • 格式: {intent.get('data_format', [])}")
    print(f"   • 优先级: {intent.get('priority', 'normal')}")
    print(f"   • 置信度: {intent.get('confidence', 0):.0%}")
    if intent.get('details'):
        print(f"   • 备注: {intent['details'][:100]}")


def _get_llm_client():
    """获取 LLM 客户端"""
    from backend.utils.llm_client import create_deepseek_client
    return create_deepseek_client()
