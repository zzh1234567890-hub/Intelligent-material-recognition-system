"""
智能识别爬取系统 - FastAPI 后端主程序

启动方式：
    uvicorn backend.main:app --reload --host 0.0.0.0 --port 8000

API 文档：
    http://localhost:8008/docs (Swagger UI)
    http://localhost:8008/redoc (ReDoc)
"""

import os
from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from backend.config import get_settings
from backend.api.routes import api_router
from backend.models.schemas import HealthCheckResponse


settings = get_settings()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """应用生命周期管理 - 启动时初始化资源"""
    
    print(f"\n{'='*60}")
    print(f"🚀 {settings.APP_NAME} v{settings.APP_VERSION}")
    print(f"{'='*60}")
    
    # 创建必要的目录
    os.makedirs(settings.UPLOAD_DIR, exist_ok=True)
    os.makedirs(settings.OUTPUT_DIR, exist_ok=True)
    
    # 初始化日志（可选）
    if settings.DEBUG:
        print("⚙️  调试模式已开启")
    
    print(f"✓ 上传目录：{os.path.abspath(settings.UPLOAD_DIR)}")
    print(f"✓ 输出目录：{os.path.abspath(settings.OUTPUT_DIR)}")
    print(f"{'='*60}\n")
    
    yield
    
    # 清理资源（关闭时）
    print("\n👋 应用正在关闭...")


# 创建 FastAPI 应用实例
app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description="""
## 智能识别爬取系统 API

### 核心功能

1. **文档解析** - 支持 PDF、Word、Markdown 格式
2. **LLM 数据提取** - 使用 DeepSeek 智能提取材料数据
3. **数据预览** - 提供友好的数据预览界面
4. **Excel 导出** - 自动生成格式化的 Excel 文件
5. **数据库存储** - 支持 MySQL / PostgreSQL 安全可靠的数据持久化

### 工作流程

```
上传文档 → 解析内容 → LLM 提取 → 预览确认 → 写入Excel → 上传数据库
```

### 快速开始

1. 上传文档：`POST /api/document/upload`
2. 提取数据：`POST /api/document/extract?session_id=xxx`
3. 预览并确认：`POST /api/document/confirm-write?session_id=xxx`
4. 上传数据库：`POST /api/document/upload-mysql?session_id=xxx`
5. 查询数据：`GET /api/data/query`
""",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json"
)

# 配置 CORS 中间件
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# 注册路由
app.include_router(api_router)


# ==================== 基础接口 ====================

@app.get("/", tags=["根路径"])
async def root():
    """根路径 - 返回 API 基本信息"""
    return {
        "name": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "status": "running",
        "docs": "/docs",
        "endpoints": {
            "upload": "/api/document/upload",
            "extract": "/api/document/extract",
            "confirm": "/api/document/confirm-write",
            "upload_mysql": "/api/document/upload-mysql",
            "query_data": "/api/data/query",
            "health": "/health"
        }
    }


@app.get("/health", response_model=HealthCheckResponse, tags=["系统"])
async def health_check():
    """
    健康检查接口 - 检查各组件状态
    
    返回：
    - 数据库连接状态（MySQL 或 PostgreSQL）
    - LLM 服务状态
    - 系统整体状态
    """
    db_status = "disconnected"
    llm_status = "not_configured"
    db_type = settings.DATABASE_TYPE  # 'mysql' 或 'postgresql'
    
    # 根据配置的数据库类型测试连接
    if db_type == "postgresql":
        try:
            from backend.tools.upload_data_v2 import PostgresUploaderV2
            
            uploader = PostgresUploaderV2(
                host=settings.POSTGRES_HOST,
                port=settings.POSTGRES_PORT,
                user=settings.POSTGRES_USER,
                password=settings.POSTGRES_PASSWORD,
                database=settings.POSTGRES_DATABASE
            )
            
            try:
                uploader.connect()
                db_status = "connected"
                uploader.disconnect()
            except Exception:
                db_status = "error"
                
        except Exception as e:
            db_status = f"error: {str(e)[:50]}"
    else:
        # MySQL 模式
        try:
            from backend.tools.upload_data import upload_data
            
            uploader = upload_data(
                host=settings.MYSQL_HOST,
                port=settings.MYSQL_PORT,
                user=settings.MYSQL_USER,
                password=settings.MYSQL_PASSWORD,
                database=settings.MYSQL_DATABASE
            )
            
            if uploader.test_connection():
                db_status = "connected"
            else:
                db_status = "error"
                
        except Exception as e:
            db_status = f"error: {str(e)[:50]}"
    
    # 检查 LLM 配置
    if settings.DEEPSEEK_API_KEY:
        llm_status = "configured"
    
    return HealthCheckResponse(
        status="healthy" if db_status == "connected" else "degraded",
        app_version=settings.APP_VERSION,
        mysql_status=db_status,  # 兼容旧字段名（实际含义是数据库状态）
        llm_status=llm_status,
        database_type=db_type  # 新增：返回数据库类型
    )


@app.get("/api/status", tags=["系统"])
async def system_status():
    """获取系统详细状态信息"""
    import platform
    
    return {
        "status": "running",
        "uptime": "active",
        "system_info": {
            "platform": platform.platform(),
            "python_version": platform.python_version(),
            "working_directory": os.getcwd()
        },
        "config": {
            "upload_dir": settings.UPLOAD_DIR,
            "output_dir": settings.OUTPUT_DIR,
            "max_file_size_mb": settings.MAX_FILE_SIZE // (1024 * 1024),
            "allowed_extensions": settings.ALLOWED_EXTENSIONS,
            "database_type": settings.DATABASE_TYPE,
            "database": f"{settings.POSTGRES_HOST}:{settings.POSTGRES_PORT}/{settings.POSTGRES_DATABASE}" if settings.DATABASE_TYPE == "postgresql" else f"{settings.MYSQL_HOST}:{settings.MYSQL_PORT}/{settings.MYSQL_DATABASE}",
            "llm_model": settings.DEEPSEEK_MODEL if settings.DEEPSEEK_API_KEY else "未配置"
        },
        "statistics": {
            # 可以在这里添加会话统计等
            "active_sessions": 0,  # TODO: 实现会话计数
            "total_processed": 0   # TODO: 实现处理统计
        }
    }


# ==================== 异常处理 ====================

@app.exception_handler(HTTPException)
async def http_exception_handler(request, exc):
    """HTTP 异常处理器"""
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "status": "error",
            "error_code": f"HTTP_{exc.status_code}",
            "message": exc.detail,
            "path": request.url.path
        }
    )


@app.exception_handler(Exception)
async def general_exception_handler(request, exc):
    """通用异常处理器"""
    return JSONResponse(
        status_code=500,
        content={
            "status": "error",
            "error_code": "INTERNAL_ERROR",
            "message": "服务器内部错误",
            "details": str(exc) if settings.DEBUG else None,
            "path": request.url.path
        }
    )


# ==================== 启动说明 ====================

if __name__ == "__main__":
    import uvicorn
    
    print(f"\n{'='*60}")
    print(f"  {settings.APP_NAME}")
    print(f"  版本: {settings.APP_VERSION}")
    print(f"{'='*60}\n")
    
    uvicorn.run(
        "backend.main:app",
        host=settings.HOST,
        port=settings.PORT,
        reload=settings.DEBUG,
        log_level="debug" if settings.DEBUG else "info"
    )
