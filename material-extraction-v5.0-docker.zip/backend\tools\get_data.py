from __future__ import annotations

import json
import re
from typing import Optional, List, Tuple


class get_data:
    """
    LLM 数据提取器：完整流程为「提取 → 预览 → 确认 → 写入 Excel」
    
    标准使用流程：
    1. extractor.extract(content)           → 调用 LLM 提取数据
    2. extractor.preview()                   → 展示预览给用户确认
    3. extractor.confirm_and_write(excel)    → 用户确认后写入 Excel
    
    也支持快捷方式：
    - extract_to_excel()                     → 跳过预览，直接写入
    """

    description = "LLM 材料数据提取器（支持预览确认后写入 Excel）"

    DATA_FIELDS = [
        "id", "identifier", "type", "title", "authors",
        "journal", "volume", "issue", "pages", "year",
        "publisher", "doi", "abstract",
    ]

    def __init__(self, llm_client=None):
        self.llm_client = llm_client
        self.content = None
        self.data = None
        self._confirmed = False
        self._last_llm_response = None  # 用于调试：保存 LLM 原始响应

    def extract(self, content: str, custom_prompt: Optional[str] = None) -> list[dict]:
        """
        使用 LLM 从文档内容中提取材料/文献数据
        
        Args:
            content: everything_read 解析后的文本
            custom_prompt: 自定义 Prompt
            
        Returns:
            list[dict]: 提取的材料数据列表
        """
        if not content or not content.strip():
            raise ValueError("文档内容为空")

        self.content = content
        self._confirmed = False
        
        prompt = custom_prompt or self._build_extraction_prompt()
        
        response = self._call_llm(prompt)
        self.data = self._parse_llm_response(response)

        error_count = sum(1 for d in self.data if "error" in d)
        
        return self.data

    def preview(self, max_items: int = 5, show_all_fields: bool = False) -> dict:
        """
        格式化展示提取的数据供用户预览确认
        
        Args:
            max_items: 最多展示的条目数
            show_all_fields: 是否显示所有字段（否则只显示关键字段）
            
        Returns:
            dict: 包含预览信息的字典 {
                'total': 总条数,
                'preview_items': 预览列表,
                'summary': 统计摘要
            }
        """
        if not self.data:
            return {"total": 0, "preview_items": [], "summary": {}}

        key_fields = ["id", "title", "authors", "year", "journal"]
        
        preview_items = []
        for i, item in enumerate(self.data[:max_items], 1):
            if item.get("error"):
                # 错误记录：显示错误详情
                preview_item = {
                    "error": item.get("error", "未知错误"),
                    "raw_text_preview": item.get("raw_text", "")[:200],
                    "detail": item.get("detail", "")
                }
            elif show_all_fields:
                preview_item = {k: self._truncate(str(v)) for k, v in item.items()}
            else:
                preview_item = {k: self._truncate(str(item.get(k, ""))) for k in key_fields}
            
            preview_items.append({
                "index": i,
                "data": preview_item,
                "has_error": "error" in item
            })

        summary = self._build_summary()

        return {
            "total": len(self.data),
            "preview_items": preview_items,
            "summary": summary
        }

    def _build_summary(self) -> dict:
        """构建数据统计摘要"""
        if not self.data:
            return {}

        types = {}
        years = []
        errors = 0

        for item in self.data:
            if "error" in item:
                errors += 1
                continue
            
            doc_type = item.get("type", "未知")
            types[doc_type] = types.get(doc_type, 0) + 1
            
            year = item.get("year", "")
            if year and year.isdigit():
                years.append(int(year))

        summary = {"总记录数": len(self.data)}
        
        if types:
            summary["文档类型分布"] = ", ".join([f"{k}({v})" for k, v in types.items()])
        
        if years:
            summary["年份范围"] = f"{min(years)} ~ {max(years)}"
        
        if errors > 0:
            summary["异常记录"] = f"{errors} 条"

        return summary

    @staticmethod
    def _truncate(text: str, max_len: int = 60) -> str:
        """截断过长的文本"""
        if len(text) <= max_len:
            return text
        return text[:max_len] + "..."

    def confirm_and_write(
        self,
        excel_handler,
        skip_errors: bool = True
    ) -> tuple[list[dict], str, int, int]:
        """
        用户确认后将数据写入 Excel 文件（追加模式）
        
        完整流程的最后一步：extract() → preview() → confirm_and_write()
        
        Args:
            excel_handler: 已调用 create_or_open() 的 format_data 实例
            skip_errors: 是否跳过包含 error 字段的异常记录
            
        Returns:
            tuple: (成功写入的数据列表, Excel 文件路径, 新增数量, 跳过重复数量)
        """
        if not self.data:
            raise RuntimeError("没有可写入的数据，请先调用 extract()")
        
        if not excel_handler.is_open:
            raise ValueError(
                "Excel 未初始化！请先调用 excel_handler.create_or_open()"
            )

        data_to_write = self.data
        
        if skip_errors:
            original_count = len(data_to_write)
            data_to_write = [d for d in data_to_write if "error" not in d]
            skipped_errors = original_count - len(data_to_write)
        else:
            skipped_errors = 0

        if not data_to_write:
            return [], excel_handler.filepath, 0, 0

        self._confirmed = True
        
        # 使用新的 add_rows 方法（返回新增数和跳过重复数）
        added_count, skipped_duplicates = excel_handler.add_rows(data_to_write)
        filepath = excel_handler.save()

        return data_to_write, filepath, added_count, skipped_duplicates

    def extract_to_excel(
        self,
        content: str,
        excel_handler,
        custom_prompt: Optional[str] = None
    ) -> tuple[list[dict], str]:
        """
        快捷方式：提取 + 直接写入 Excel（跳过预览步骤）
        """
        self.extract(content, custom_prompt)
        return self.confirm_and_write(excel_handler)

    def _build_extraction_prompt(self) -> str:
        fields_desc = "\n".join([f"- {f}" for f in self.DATA_FIELDS])
        
        # 截断文档内容以避免超时和 token 超限
        max_content_length = 20000  # 最大发送 20000 字符给 LLM（增大以获取更完整信息）
        content = self.content
        if len(content) > max_content_length:
            content = content[:max_content_length] + f"\n\n[注：文档已截断，原文共 {len(self.content)} 字符，此处显示前 {max_content_length} 字符]"
        
        return f"""你是一个专业的学术文献信息提取助手。请从以下文档内容中提取所有材料/文献相关信息。

## 提取要求：
1. 识别所有与材料、研究、文献相关的条目
2. 每个条目提取以下字段：{fields_desc}
3. 以 JSON 数组格式返回
4. 找不到的字段填空字符串 ""，没有数据返回空数组 []

## 字段说明：
- id: 编号（P_001, P_002...）
- identifier: 唯一标识符（如 zhang2021spalling）
- type: 类型（article/report/conference/patent/book）
- title: 完整标题
- authors: 作者（用 and 连接，如 Zhang, Dong and Liu, Yuchen）
- journal: 期刊/会议名称
- volume: 卷号
- issue: 期号
- pages: 页码/文章编号
- year: 年份（4位数字）
- publisher: 出版社
- doi: DOI 链接
- abstract: 摘要/关键描述

## 文档内容：
{content}

## 返回格式（严格 JSON 数组）：
[
  {{"id":"P_001","identifier":"...","type":"article","title":"...","authors":"...","journal":"...","volume":"","issue":"","pages":"","year":"2024","publisher":"","doi":"","abstract":"..."}}
]

请只返回 JSON，不要其他文字。"""

    def _call_llm(self, prompt: str) -> str:
        """调用 LLM 并获取响应"""
        if not self.llm_client:
            raise ValueError("未配置 LLM 客户端，请传入 llm_client 参数")
        try:
            response = self.llm_client.generate(
                messages=[{"role": "user", "content": prompt}],
                temperature=0.3,
            )
            result = response.choices[0].message.content
            # 保存原始响应用于调试
            self._last_llm_response = result
            return result
        except Exception as e:
            raise RuntimeError(f"LLM 调用失败: {e}")

    def _parse_llm_response(self, response: str) -> list[dict]:
        """解析 LLM 返回的 JSON 结果"""
        try:
            text = response.strip()
            
            if text.startswith("```"):
                match = re.search(r'```(?:json)?\s*\n?(.*?)```', text, re.DOTALL)
                if match:
                    text = match.group(1).strip()

            data = json.loads(text)
            
            if isinstance(data, dict):
                return [data]
            elif isinstance(data, list):
                return data
            else:
                return [{"raw_response": str(data)}]
                
        except json.JSONDecodeError as e:
            return [{"error": "JSON 解析失败", "raw_text": response[:500], "detail": str(e)}]

    def get_data(self) -> list[dict]:
        """获取提取的数据"""
        return self.data or []
