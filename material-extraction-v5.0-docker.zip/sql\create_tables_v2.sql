-- ============================================================
-- 智能材料数据识别系统 - PostgreSQL 完整建表脚本 (v3.0)
-- 基于 Summary 数据结构设计
--
-- 设计说明：
--   1. 11张核心表，分为4层架构：文献层 → 实验设计层 → 实验结果层 → 字典辅助层
--   2. 完整的外键约束链路：material_data → mix_proportions → specimens_group → test_result_group
--   3. 包含索引优化、触发器、注释
--   4. 支持混凝土高温性能实验数据的完整存储与查询
--   5. 表名与代码 TABLE_SCHEMAS 严格一致，不做任何映射
--
-- 执行方式：
--   psql -U postgres -f create_tables_v2.sql
-- ============================================================

SET client_encoding TO 'UTF8';

-- ============================================
-- 0. 创建数据库（如果不存在）
-- ============================================
SELECT 'CREATE DATABASE material_db'
WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'material_db')\gexec

\c material_db

-- ============================================
-- 1. 字典/枚举表（最底层，被其他表引用）
-- ============================================

-- 1.1 纤维类型字典
DROP TABLE IF EXISTS fiber_type_dict CASCADE;

CREATE TABLE fiber_type_dict (
    fiber_type_code VARCHAR(50) PRIMARY KEY,
    display_name VARCHAR(100) NOT NULL,
    notes TEXT
);

COMMENT ON TABLE fiber_type_dict IS '纤维类型字典 - 标准化纤维类型枚举';
COMMENT ON COLUMN fiber_type_dict.fiber_type_code IS '类型编码（如 steel, polypropylene, polyethylene）';
COMMENT ON COLUMN fiber_type_dict.display_name IS '显示名称（如 Steel, Polypropylene (PP)）';

INSERT INTO fiber_type_dict (fiber_type_code, display_name) VALUES
    ('steel', 'Steel'),
    ('polypropylene', 'Polypropylene (PP)'),
    ('polyethylene', 'Polyethylene (PE)'),
    ('polyvinyl_alcohol', 'Poly alcohol (PVA)'),
    ('polyoxymethylene', 'Polyoxymethylene (POM)'),
    ('glass', 'Glass'),
    ('carbon', 'Carbon'),
    ('basalt', 'Basalt'),
    ('other', 'Other');

-- 1.2 试验性质字典
DROP TABLE IF EXISTS result_property_dict CASCADE;

CREATE TABLE result_property_dict (
    property_code VARCHAR(80) PRIMARY KEY,
    display_name VARCHAR(100) NOT NULL,
    default_unit VARCHAR(20),
    notes TEXT
);

COMMENT ON TABLE result_property_dict IS '试验性质字典 - 力学性能和物理性质的标准枚举';
COMMENT ON COLUMN result_property_dict.property_code IS '性质编码（如 compressive_strength, elastic_modulus）';
COMMENT ON COLUMN result_property_dict.default_unit IS '默认单位（如 MPa, GPa, %）';

INSERT INTO result_property_dict (property_code, display_name, default_unit) VALUES
    ('compressive_strength', 'Compressive strength', 'MPa'),
    ('direct_tensile_strength', 'Direct tensile strength', 'MPa'),
    ('splitting_tensile_strength', 'Splitting tensile strength', 'MPa'),
    ('flexural_strength', 'Flexural strength', 'MPa'),
    ('elastic_modulus', 'Elastic modulus', 'GPa'),
    ('peak_strain', 'Peak strain', 'mm/mm'),
    ('mass_loss_ratio_percent', 'Mass loss ratio', '%'),
    ('residual_strength_ratio', 'Residual strength ratio', '-'),
    ('failure_mode', 'Failure mode', NULL),
    ('spalling', 'Spalling', NULL),
    ('thermal_conductivity', 'Thermal conductivity', 'W/(m·K)'),
    ('permeability', 'Permeability coefficient', 'm/s');

-- ============================================
-- 2. 文献元数据主表（根表）- 表名 material_data 与代码严格一致
-- ============================================
DROP TABLE IF EXISTS material_data CASCADE;

CREATE TABLE material_data (
    paper_code VARCHAR(30) PRIMARY KEY,
    bib_key VARCHAR(200) UNIQUE,
    entry_type VARCHAR(50) NOT NULL DEFAULT '',
    title TEXT NOT NULL,
    authors_bib TEXT,
    journal VARCHAR(300) DEFAULT '',
    volume VARCHAR(30) DEFAULT '',
    number VARCHAR(30) DEFAULT '',
    pages VARCHAR(50) DEFAULT '',
    year CHAR(4) DEFAULT '',
    publisher VARCHAR(200) DEFAULT '',
    doi VARCHAR(300) UNIQUE,
    abstract TEXT,
    notes TEXT,

    source_file VARCHAR(500) DEFAULT '',
    uploaded_by VARCHAR(100) DEFAULT '',
    session_id VARCHAR(100) DEFAULT '',

    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT chk_material_data_year CHECK (year = '' OR year ~ '^\d{4}$')
);

COMMENT ON TABLE material_data IS '文献元数据主表 - 存储学术论文的完整引用信息，是所有实验数据的根节点';
COMMENT ON COLUMN material_data.paper_code IS '全局唯一论文编号（格式 P_001, P_002...）';
COMMENT ON COLUMN material_data.bib_key IS 'BibTeX风格标识符（用于去重和引用匹配）';
COMMENT ON COLUMN material_data.entry_type IS '文档类型（article/conference/book/report/patent）';
COMMENT ON COLUMN material_data.authors_bib IS '作者列表（BibTeX格式）';
COMMENT ON COLUMN material_data.doi IS 'DOI数字对象标识符（全局唯一）';

CREATE INDEX idx_material_data_bib_key ON material_data(bib_key);
CREATE INDEX idx_material_data_year ON material_data(year);
CREATE INDEX idx_material_data_journal ON material_data(journal);
CREATE INDEX idx_material_data_entry_type ON material_data(entry_type);
CREATE INDEX idx_material_data_created_at ON material_data(created_at);

-- 更新时间戳触发器
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER trg_material_data_updated
    BEFORE UPDATE ON material_data
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- ============================================
-- 3. 配合比表（实验设计层）
-- ============================================
DROP TABLE IF EXISTS mix_proportions CASCADE;

CREATE TABLE mix_proportions (
    mix_code VARCHAR(40) PRIMARY KEY,
    paper_code VARCHAR(30) NOT NULL REFERENCES material_data(paper_code) ON DELETE CASCADE,
    mix_label VARCHAR(100) NOT NULL,
    author_defined_concrete_label VARCHAR(200) DEFAULT '',
    fiber_enhanced SMALLINT NOT NULL DEFAULT 0,
    binder_type VARCHAR(100),

    water_binder_ratio NUMERIC(5, 3),

    cement_kg_m3 NUMERIC(10, 2),
    silica_fume_kg_m3 NUMERIC(10, 2),
    limestone_filler_kg_m3 NUMERIC(10, 2),
    fly_ash_kg_m3 NUMERIC(10, 2),
    slag_kg_m3 NUMERIC(10, 2),
    metakaolin_kg_m3 NUMERIC(10, 2),

    water_kg_m3 NUMERIC(10, 2),

    fine_aggregate_kg_m3 NUMERIC(10, 2),
    coarse_aggregate_kg_m3 NUMERIC(10, 2),
    silica_sand_kg_m3 NUMERIC(10, 2),
    lightweight_aggregate_kg_m3 NUMERIC(10, 2),

    superplasticizer_kg_m3 NUMERIC(8, 3),

    steel_fiber_volume_fraction NUMERIC(5, 2),
    pp_fiber_volume_fraction NUMERIC(5, 2),
    pe_fiber_volume_fraction NUMERIC(5, 2),
    pva_fiber_volume_fraction NUMERIC(5, 2),
    pom_fiber_volume_fraction NUMERIC(5, 2),
    glass_fiber_volume_fraction NUMERIC(5, 2),
    carbon_fiber_volume_fraction NUMERIC(5, 2),
    other_fiber_volume_fraction NUMERIC(5, 2),

    notes TEXT,

    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT chk_mix_fiber_enhanced CHECK (fiber_enhanced IN (0, 1)),
    CONSTRAINT chk_mix_wb_ratio CHECK (water_binder_ratio > 0 AND water_binder_ratio <= 10)
);

COMMENT ON TABLE mix_proportions IS '配合比表 - 描述每种混凝土/水泥基材料的完整组成配方';
COMMENT ON COLUMN mix_proportions.mix_code IS '全局唯一配合比编号（格式 P_001_M_001）';
COMMENT ON COLUMN mix_proportions.paper_code IS '所属论文编号（外键→material_data）';
COMMENT ON COLUMN mix_proportions.fiber_enhanced IS '是否为纤维增强混凝土（0=否, 1=是）';
COMMENT ON COLUMN mix_proportions.water_binder_ratio IS '水胶比（无量纲）';
COMMENT ON COLUMN mix_proportions.cement_kg_m3 IS '水泥用量 (kg/m³)';
COMMENT ON COLUMN mix_proportions.silica_fume_kg_m3 IS '硅灰用量 (kg/m³)';
COMMENT ON COLUMN mix_proportions.steel_fiber_volume_fraction IS '钢纤维体积掺量 (%)';

CREATE INDEX idx_mix_paper_code ON mix_proportions(paper_code);
CREATE INDEX idx_mix_fiber_enhanced ON mix_proportions(fiber_enhanced);
CREATE INDEX idx_mix_wb_ratio ON mix_proportions(water_binder_ratio);

CREATE TRIGGER trg_mix_proportions_updated
    BEFORE UPDATE ON mix_proportions
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- ============================================
-- 4. 纤维明细表（实验设计层 - 子表）
-- ============================================
DROP TABLE IF EXISTS fibers CASCADE;

CREATE TABLE fibers (
    fiber_code VARCHAR(50) PRIMARY KEY,
    mix_code VARCHAR(40) NOT NULL REFERENCES mix_proportions(mix_code) ON DELETE CASCADE,
    fiber_type VARCHAR(50) NOT NULL,
    display_name VARCHAR(100),
    material_class VARCHAR(50),
    volume_fraction_pct NUMERIC(6, 3),
    length_mm NUMERIC(8, 3),
    diameter_min_mm NUMERIC(8, 4),
    diameter_max_mm NUMERIC(8, 4),
    aspect_ratio NUMERIC(8, 1),
    mass_kg_m3 NUMERIC(8, 3),
    shape VARCHAR(50),
    elastic_modulus_gpa NUMERIC(8, 2),
    tensile_strength_mpa NUMERIC(10, 2),
    melting_temp_c NUMERIC(6, 1),
    density_g_cm3 NUMERIC(6, 3),
    note TEXT,

    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT chk_fiber_volume CHECK (volume_fraction_pct >= 0 AND volume_fraction_pct <= 100)
);

COMMENT ON TABLE fibers IS '纤维明细表 - 记录每种配合比中添加的纤维详细物理参数';
COMMENT ON COLUMN fibers.fiber_code IS '唯一纤维编号（格式 P_001_M_001_F01）';
COMMENT ON COLUMN fibers.mix_code IS '所属配合比编号（外键→mix_proportions）';
COMMENT ON COLUMN fibers.fiber_type IS '纤维原始类型名（需与fiber_type_dict.fiber_type_code对应）';
COMMENT ON COLUMN fibers.material_class IS '材料大类（synthetic_polymer / metallic / mineral 等）';
COMMENT ON COLUMN fibers.volume_fraction_pct IS '体积掺量 (%)';
COMMENT ON COLUMN fibers.melting_temp_c IS '熔点温度 ℃（对高温性能分析关键）';

CREATE INDEX idx_fibers_mix_code ON fibers(mix_code);
CREATE INDEX idx_fibers_fiber_type ON fibers(fiber_type);
CREATE INDEX idx_fibers_material_class ON fibers(material_class);

CREATE TRIGGER trg_fibers_updated
    BEFORE UPDATE ON fibers
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- ============================================
-- 5. 试件组表（实验设计层）
-- ============================================
DROP TABLE IF EXISTS specimens_group CASCADE;

CREATE TABLE specimens_group (
    specimen_group_code VARCHAR(60) PRIMARY KEY,
    mix_code VARCHAR(40) NOT NULL REFERENCES mix_proportions(mix_code) ON DELETE CASCADE,
    specimen_label VARCHAR(100),
    specimen_shape VARCHAR(30) NOT NULL,
    intended_test_type VARCHAR(80),

    length_mm NUMERIC(8, 2),
    width_mm NUMERIC(8, 2),
    height_mm NUMERIC(8, 2),
    diameter_mm NUMERIC(8, 2),
    thickness_mm NUMERIC(6, 2),

    gauge_length_mm NUMERIC(8, 2),
    gauge_width_mm NUMERIC(6, 2),

    age_at_test_day INTEGER,
    curing_method VARCHAR(50),
    curing_temp_c NUMERIC(5, 1),
    curing_rh_pct NUMERIC(5, 1),

    note TEXT,

    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT chk_specimen_shape CHECK (specimen_shape IN (
        'cube', 'cylinder', 'prism', 'dog_bone', 'beam', 'disk', 'plate', 'other'
    )),
    CONSTRAINT chk_age_test CHECK (age_at_test_day IS NULL OR age_at_test_day > 0)
);

COMMENT ON TABLE specimens_group IS '试件组表 - 定义试件的几何形状、尺寸和试验条件（组级别）';
COMMENT ON COLUMN specimens_group.specimen_group_code IS '唯一试件组编号（格式 P_001_Compr_G_001）';
COMMENT ON COLUMN specimens_group.specimen_shape IS '试件形状（cube/cylinder/prism/dog_bone/beam/disk/plate/other）';
COMMENT ON COLUMN specimens_group.intended_test_type IS '预期试验类型（compressive_test/tensile_test/flexural_test等）';
COMMENT ON COLUMN specimens_group.age_at_test_day IS '试验龄期（天）';
COMMENT ON COLUMN specimens_group.curing_method IS '养护方式（water_curing/steam_curing/standard_curing等）';

CREATE INDEX idx_specgrp_mix_code ON specimens_group(mix_code);
CREATE INDEX idx_specgrp_shape ON specimens_group(specimen_shape);
CREATE INDEX idx_specgrp_test_type ON specimens_group(intended_test_type);

CREATE TRIGGER trg_specimens_group_updated
    BEFORE UPDATE ON specimens_group
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- ============================================
-- 5b. 个体级试件表（细粒度）
-- ============================================
DROP TABLE IF EXISTS specimens CASCADE;

CREATE TABLE specimens (
    specimen_id SERIAL PRIMARY KEY,
    specimen_code VARCHAR(70) UNIQUE NOT NULL,
    specimen_group_code VARCHAR(60) NOT NULL REFERENCES specimens_group(specimen_group_code) ON DELETE CASCADE,
    specimen_label VARCHAR(100),
    specimen_shape VARCHAR(30) NOT NULL,

    length_mm NUMERIC(8, 2),
    width_mm NUMERIC(8, 2),
    height_mm NUMERIC(8, 2),
    diameter_mm NUMERIC(8, 2),
    thickness_mm NUMERIC(6, 2),
    gauge_length_mm NUMERIC(8, 2),
    gauge_width_mm NUMERIC(6, 2),

    age_at_test_day INTEGER,
    curing_method VARCHAR(50),
    note TEXT,

    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

COMMENT ON TABLE specimens IS '个体级试件表 - 每个独立试件的详细记录';
COMMENT ON COLUMN specimens.specimen_code IS '个体试件编号（格式 P_001_M_001_Compr_S_001）';
COMMENT ON COLUMN specimens.specimen_group_code IS '所属试件组（外键→specimens_group）';

CREATE INDEX idx_specimens_group_code ON specimens(specimen_group_code);
CREATE INDEX idx_specimens_specimen_code ON specimens(specimen_code);

CREATE TRIGGER trg_specimens_updated
    BEFORE UPDATE ON specimens
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- ============================================
-- 6. 加热协议表（实验条件层 - 核心特色）
-- ============================================
DROP TABLE IF EXISTS heating_protocols CASCADE;

CREATE TABLE heating_protocols (
    heating_protocol_id VARCHAR(40) PRIMARY KEY,
    paper_code VARCHAR(30) NOT NULL REFERENCES material_data(paper_code) ON DELETE CASCADE,

    target_temperature NUMERIC(7, 1),
    target_temperature_display VARCHAR(50),

    cycle INTEGER NOT NULL DEFAULT 1,
    heating_rate_degree_min NUMERIC(6, 2),
    holding_time_min NUMERIC(8, 1),
    cooling_time_min NUMERIC(8, 1),
    cooling_method VARCHAR(50),

    fire_curve VARCHAR(100),
    loaded_during_heating VARCHAR(50),
    load_level_pct NUMERIC(5, 1),

    notes TEXT,

    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT chk_hp_cycle CHECK (cycle >= 1),
    CONSTRAINT chk_hp_target_temp CHECK (target_temperature IS NULL OR target_temperature >= -273.15)
);

COMMENT ON TABLE heating_protocols IS '加热协议表 - 定义高温试验的加热过程参数（本数据库核心特色）';
COMMENT ON COLUMN heating_protocols.heating_protocol_id IS '唯一加热协议编号（格式 P_001_H_001, Amb表示常温）';
COMMENT ON COLUMN heating_protocols.paper_code IS '所属论文编号';
COMMENT ON COLUMN heating_protocols.target_temperature IS '目标温度 (℃)，NULL或特殊值表示常温对照';
COMMENT ON COLUMN heating_protocols.target_temperature_display IS '目标温度的可读显示名称（如 "Load Level 0%"）';
COMMENT ON COLUMN heating_protocols.cycle IS '加热循环次数';
COMMENT ON COLUMN heating_protocols.heating_rate_degree_min IS '升温速率 (℃/min)';
COMMENT ON COLUMN heating_protocols.holding_time_min IS '恒温保持时间 (min)';
COMMENT ON COLUMN heating_protocols.fire_curve IS '遵循的火灾曲线标准（ISO-834, RABT, HC, ASTM-E119等）';
COMMENT ON COLUMN heating_protocols.loaded_during_heating IS '加热期间是否受载及载荷水平';
COMMENT ON COLUMN heating_protocols.load_level_pct IS '受载时的载荷水平 (%)';

CREATE INDEX idx_hp_paper_code ON heating_protocols(paper_code);
CREATE INDEX idx_hp_target_temp ON heating_protocols(target_temperature);
CREATE INDEX idx_hp_fire_curve ON heating_protocols(fire_curve);

CREATE TRIGGER trg_heating_protocols_updated
    BEFORE UPDATE ON heating_protocols
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- ============================================
-- 7. 试验方法表
-- ============================================
DROP TABLE IF EXISTS test_methods CASCADE;

CREATE TABLE test_methods (
    method_code VARCHAR(60) PRIMARY KEY,
    paper_code VARCHAR(30) REFERENCES material_data(paper_code) ON DELETE SET NULL,
    test_type VARCHAR(80) NOT NULL,
    test_state VARCHAR(50),
    standard VARCHAR(200),
    standard_code VARCHAR(50),
    loading_rate NUMERIC(12, 4),
    loading_rate_unit VARCHAR(30),
    machine_type VARCHAR(100),
    notes TEXT,

    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

COMMENT ON TABLE test_methods IS '试验方法表 - 定义力学性能测试的方法学细节';
COMMENT ON COLUMN test_methods.method_code IS '方法编号（如 P_001_ME_Compr_001）';
COMMENT ON COLUMN test_methods.test_type IS '试验类型（compressive_test/uniaxial_tensile_test/splitting_tensile_test/flexural_test等）';
COMMENT ON COLUMN test_methods.standard IS '遵循的标准全称（如 ASTM C39, GB/T 50081）';
COMMENT ON COLUMN test_methods.loading_rate IS '加载速率';
COMMENT ON COLUMN test_methods.loading_rate_unit IS '加载速率单位（N/s, MPa/s, mm/min等）';

CREATE INDEX idx_tm_test_type ON test_methods(test_type);
CREATE INDEX idx_tm_standard ON test_methods(standard_code);

CREATE TRIGGER trg_test_methods_updated
    BEFORE UPDATE ON test_methods
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- ============================================
-- 8. 试验结果组表（宽格式 - 核心输出表）
-- ============================================
DROP TABLE IF EXISTS test_result_group CASCADE;

CREATE TABLE test_result_group (
    result_group_code VARCHAR(60) PRIMARY KEY,

    paper_code VARCHAR(30) NOT NULL REFERENCES material_data(paper_code) ON DELETE CASCADE,
    heating_protocol_id VARCHAR(40) REFERENCES heating_protocols(heating_protocol_id) ON DELETE SET NULL,
    specimen_group_code VARCHAR(60) REFERENCES specimens_group(specimen_group_code) ON DELETE SET NULL,
    specimen_label VARCHAR(100),

    spalling VARCHAR(20),

    compressive_group_code VARCHAR(60) REFERENCES specimens_group(specimen_group_code) ON DELETE SET NULL,
    compressive_test_method_code VARCHAR(60) REFERENCES test_methods(method_code) ON DELETE SET NULL,
    compressive_strength NUMERIC(12, 4),

    direct_tensile_group_code VARCHAR(60) REFERENCES specimens_group(specimen_group_code) ON DELETE SET NULL,
    direct_tensile_test_method_code VARCHAR(60) REFERENCES test_methods(method_code) ON DELETE SET NULL,
    direct_tensile_strength NUMERIC(10, 4),

    splitting_tensile_group_code VARCHAR(60) REFERENCES specimens_group(specimen_group_code) ON DELETE SET NULL,
    splitting_tensile_method_code VARCHAR(60) REFERENCES test_methods(method_code) ON DELETE SET NULL,
    splitting_tensile_strength NUMERIC(10, 4),

    flexural_group_code VARCHAR(60) REFERENCES specimens_group(specimen_group_code) ON DELETE SET NULL,
    flexural_test_method_code VARCHAR(60) REFERENCES test_methods(method_code) ON DELETE SET NULL,
    flexural_strength NUMERIC(10, 4),

    elastic_modulus NUMERIC(10, 3),
    peak_strain NUMERIC(12, 6),

    mass_loss_ratio_percent NUMERIC(6, 3),

    failure_mode VARCHAR(100),

    residual_strength_ratio NUMERIC(6, 3),
    notes TEXT,

    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT chk_spalling CHECK (spalling IS NULL OR spalling IN ('yes', 'no', 'minor', 'severe', 'explosive', 'none'))
);

COMMENT ON TABLE test_result_group IS '试验结果组表（宽格式）- 将试件组+加热协议与多种力学性能关联的核心输出表';
COMMENT ON COLUMN test_result_group.result_group_code IS '结果组编号（格式 P_001_RG_001）';
COMMENT ON COLUMN test_result_group.heating_protocol_id IS '经历的加热协议（外键→heating_protocols，NULL表示常温）';
COMMENT ON COLUMN test_result_group.spalling IS '爆裂现象（yes/no/minor/severe/explosive/none）';
COMMENT ON COLUMN test_result_group.compressive_strength IS '抗压强度 (MPa)';
COMMENT ON COLUMN test_result_group.direct_tensile_strength IS '直接拉伸强度 (MPa)';
COMMENT ON COLUMN test_result_group.splitting_tensile_strength IS '劈裂抗拉强度 (MPa)';
COMMENT ON COLUMN test_result_group.flexural_strength IS '抗弯/抗折强度 (MPa)';
COMMENT ON COLUMN test_result_group.elastic_modulus IS '弹性模量 (GPa)';
COMMENT ON COLUMN test_result_group.peak_strain IS '峰值应变 (mm/mm)';
COMMENT ON COLUMN test_result_group.mass_loss_ratio_percent IS '质量损失率 (%)';
COMMENT ON COLUMN test_result_group.failure_mode IS '破坏模式描述';

CREATE INDEX idx_trg_paper_code ON test_result_group(paper_code);
CREATE INDEX idx_trg_heating_id ON test_result_group(heating_protocol_id);
CREATE INDEX idx_trg_spec_grp ON test_result_group(specimen_group_code);
CREATE INDEX idx_trg_compressive ON test_result_group(compressive_strength) WHERE compressive_strength IS NOT NULL;
CREATE INDEX idx_trg_direct_tensile ON test_result_group(direct_tensile_strength) WHERE direct_tensile_strength IS NOT NULL;
CREATE INDEX idx_trg_splitting ON test_result_group(splitting_tensile_strength) WHERE splitting_tensile_strength IS NOT NULL;
CREATE INDEX idx_trg_elastic_modulus ON test_result_group(elastic_modulus) WHERE elastic_modulus IS NOT NULL;
CREATE INDEX idx_trg_spalling ON test_result_group(spalling) WHERE spalling IS NOT NULL;

CREATE TRIGGER trg_test_result_group_updated
    BEFORE UPDATE ON test_result_group
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- ============================================
-- 9. 试验结果表（长格式 - 灵活查询用）
-- ============================================
DROP TABLE IF EXISTS test_results CASCADE;

CREATE TABLE test_results (
    result_id SERIAL PRIMARY KEY,
    result_code VARCHAR(70) UNIQUE NOT NULL,

    method_code VARCHAR(60) REFERENCES test_methods(method_code) ON DELETE SET NULL,
    specimen_code VARCHAR(70) REFERENCES specimens(specimen_code) ON DELETE SET NULL,
    specimen_label VARCHAR(100),

    heating_protocol_id VARCHAR(40) REFERENCES heating_protocols(heating_protocol_id) ON DELETE SET NULL,

    test_state VARCHAR(50),
    property_code VARCHAR(80) NOT NULL,

    value_numeric NUMERIC(14, 6),
    value_text TEXT,
    value_min NUMERIC(14, 6),
    value_max NUMERIC(14, 6),
    value_mean NUMERIC(14, 6),
    value_std_dev NUMERIC(14, 6),
    sample_size INTEGER,

    unit VARCHAR(20),
    failure_mode VARCHAR(100),
    spalling VARCHAR(20),

    notes TEXT,

    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT chk_sample_size CHECK (sample_size IS NULL OR sample_size > 0)
);

COMMENT ON TABLE test_results IS '试验结果表（长格式）- 每行一个性质-值对，适合程序化灵活查询和统计分析';
COMMENT ON COLUMN test_results.result_code IS '结果编号（格式 P_001_R_001）';
COMMENT ON COLUMN test_results.property_code IS '性质编码（外键语义→result_property_dict.property_code）';
COMMENT ON COLUMN test_results.value_numeric IS '数值型测量值';
COMMENT ON COLUMN test_results.value_mean IS '多次测量的平均值';
COMMENT ON COLUMN test_results.value_std_dev IS '标准差';
COMMENT ON COLUMN test_results.sample_size IS '样本数量（重复试验数）';

CREATE INDEX idx_results_method_code ON test_results(method_code);
CREATE INDEX idx_results_specimen_code ON test_results(specimen_code);
CREATE INDEX idx_results_heating_id ON test_results(heating_protocol_id);
CREATE INDEX idx_results_property_code ON test_results(property_code);
CREATE INDEX idx_results_value_numeric ON test_results(value_numeric) WHERE value_numeric IS NOT NULL;
CREATE INDEX idx_results_unit ON test_results(unit);

CREATE TRIGGER trg_test_results_updated
    BEFORE UPDATE ON test_results
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- ============================================
-- 10. 视图定义（常用查询视图）
-- ============================================

CREATE OR REPLACE VIEW v_paper_mix_fiber AS
SELECT
    md.paper_code,
    md.bib_key,
    md.title,
    md.year,
    mp.mix_code,
    mp.mix_label,
    mp.fiber_enhanced,
    mp.water_binder_ratio,
    f.fiber_code,
    f.fiber_type,
    f.display_name AS fiber_display_name,
    f.volume_fraction_pct,
    f.length_mm,
    f.diameter_min_mm,
    f.diameter_max_mm
FROM material_data md
LEFT JOIN mix_proportions mp ON md.paper_code = mp.paper_code
LEFT JOIN fibers f ON mp.mix_code = f.mix_code;

COMMENT ON VIEW v_paper_mix_fiber IS '文献-配合比-纤维 关联视图';

CREATE OR REPLACE VIEW v_full_experiment_chain AS
SELECT
    trg.result_group_code,
    md.paper_code,
    md.bib_key,
    md.title,
    md.year,
    mp.mix_code,
    mp.mix_label,
    mp.water_binder_ratio,
    sg.specimen_group_code,
    sg.specimen_shape,
    hp.heating_protocol_id,
    hp.target_temperature,
    hp.fire_curve,
    trg.compressive_strength,
    trg.direct_tensile_strength,
    trg.splitting_tensile_strength,
    trg.flexural_strength,
    trg.elastic_modulus,
    trg.peak_strain,
    trg.mass_loss_ratio_percent,
    trg.spalling,
    trg.failure_mode
FROM test_result_group trg
JOIN material_data md ON trg.paper_code = md.paper_code
LEFT JOIN mix_proportions mp ON trg.paper_code = mp.paper_code
LEFT JOIN specimens_group sg ON trg.specimen_group_code = sg.specimen_group_code
LEFT JOIN heating_protocols hp ON trg.heating_protocol_id = hp.heating_protocol_id;

COMMENT ON VIEW v_full_experiment_chain IS '完整实验链路视图 - 从论文到力学性能结果的全链路展示';

CREATE OR REPLACE VIEW v_temperature_strength AS
SELECT
    md.paper_code,
    md.title,
    mp.mix_label,
    hp.heating_protocol_id,
    COALESCE(hp.target_temperature, 0) AS temperature_c,
    hp.target_temperature_display,
    trg.compressive_strength,
    trg.direct_tensile_strength,
    trg.splitting_tensile_strength,
    trg.flexural_strength,
    trg.elastic_modulus,
    trg.mass_loss_ratio_percent,
    trg.spalling
FROM test_result_group trg
JOIN material_data md ON trg.paper_code = md.paper_code
LEFT JOIN mix_proportions mp ON mp.paper_code = md.paper_code
LEFT JOIN heating_protocols hp ON trg.heating_protocol_id = hp.heating_protocol_id
WHERE trg.compressive_strength IS NOT NULL
ORDER BY md.paper_code, COALESCE(hp.target_temperature, 0);

COMMENT ON VIEW v_temperature_strength IS '温度-强度关系视图 - 用于分析混凝土高温下力学性能衰减规律';

CREATE OR REPLACE VIEW v_result_statistics AS
SELECT
    tr.property_code,
    rpd.display_name,
    rpd.default_unit AS unit,
    COUNT(*) AS total_records,
    COUNT(tr.value_numeric) AS numeric_count,
    AVG(tr.value_numeric) AS avg_value,
    MIN(tr.value_numeric) AS min_value,
    MAX(tr.value_numeric) AS max_value,
    STDDEV(tr.value_numeric) AS std_dev_value,
    COUNT(DISTINCT tr.specimen_code) AS distinct_specimens,
    COUNT(DISTINCT tr.heating_protocol_id) AS distinct_temperatures
FROM test_results tr
LEFT JOIN result_property_dict rpd ON tr.property_code = rpd.property_code
GROUP BY tr.property_code, rpd.display_name, rpd.default_unit
ORDER BY total_records DESC;

COMMENT ON VIEW v_result_statistics IS '试验结果统计视图 - 按性质分组的统计摘要';

-- ============================================
-- 11. 验证与报告
-- ============================================

DO $$
DECLARE
    table_count INTEGER;
    view_count INTEGER;
BEGIN
    SELECT COUNT(*) INTO table_count FROM information_schema.tables
        WHERE table_schema = 'public' AND table_type = 'BASE TABLE'
        AND table_name IN (
            'material_data', 'mix_proportions', 'fibers', 'specimens_group',
            'specimens', 'heating_protocols', 'test_methods',
            'test_result_group', 'test_results', 'fiber_type_dict',
            'result_property_dict'
        );

    SELECT COUNT(*) INTO view_count FROM information_schema.views
        WHERE table_schema = 'public'
        AND table_name IN (
            'v_paper_mix_fiber', 'v_full_experiment_chain',
            'v_temperature_strength', 'v_result_statistics'
        );

    RAISE NOTICE '';
    RAISE NOTICE '============================================================';
    RAISE NOTICE '  PostgreSQL v3.0 - material_data as main table';
    RAISE NOTICE '============================================================';
    RAISE NOTICE '  Tables: %', table_count;
    RAISE NOTICE '  Views:  %', view_count;
    RAISE NOTICE '============================================================';
    RAISE NOTICE '';
END $$;

SELECT
    'Table Structure Verification' AS check_item,
    table_name AS table_name,
    (SELECT COUNT(*) FROM information_schema.columns c WHERE c.table_name = t.table_name AND c.table_schema = 'public') AS column_count,
    (SELECT COUNT(*) FROM pg_indexes i WHERE i.tablename = t.table_name) AS index_count
FROM information_schema.tables t
WHERE t.table_schema = 'public' AND t.table_type = 'BASE TABLE'
AND t.table_name IN (
    'material_data', 'mix_proportions', 'fibers', 'specimens_group',
    'specimens', 'heating_protocols', 'test_methods',
    'test_result_group', 'test_results', 'fiber_type_dict',
    'result_property_dict'
)
ORDER BY CASE t.table_name
    WHEN 'fiber_type_dict' THEN 1
    WHEN 'result_property_dict' THEN 2
    WHEN 'material_data' THEN 3
    WHEN 'mix_proportions' THEN 4
    WHEN 'fibers' THEN 5
    WHEN 'specimens_group' THEN 6
    WHEN 'specimens' THEN 7
    WHEN 'heating_protocols' THEN 8
    WHEN 'test_methods' THEN 9
    WHEN 'test_result_group' THEN 10
    WHEN 'test_results' THEN 11
END;
