from __future__ import annotations

import json
import re
from typing import Optional, List, Dict, Any


TABLE_SCHEMAS = {
    "material_data": {
        "description": "文献主表 - 对应数据库 papers 表，所有子表外键指向此表",
        "fields": [
            ("paper_code", "str", "全局唯一论文编号(PK)，格式 P_001, P_002..."),
            ("bib_key", "str", "BibTeX风格唯一标识符(UNIQUE)，如 zhang2021spalling"),
            ("entry_type", "str", "文献类型: article/conference/report/patent/book"),
            ("title", "str", "完整标题"),
            ("authors_bib", "str", "作者列表(BibTeX格式)，用 and 或逗号连接"),
            ("journal", "str", "期刊/会议名称"),
            ("volume", "str", "卷号"),
            ("number", "str", "期号"),
            ("pages", "str", "页码范围"),
            ("year", "str", "发表年份(4位数字)"),
            ("publisher", "str", "出版社"),
            ("doi", "str", "DOI标识符"),
            ("abstract", "str", "摘要或关键描述"),
            ("notes", "str", "备注"),
        ],
        "required_fields": ["paper_code", "title"],
    },
    "mix_proportions": {
        "description": "混凝土配合比表 - 外键→material_data.paper_code",
        "fields": [
            ("mix_code", "str", "配合比编号(PK)，格式 P_001_M_001"),
            ("paper_code", "str", "所属论文编号(外键→material_data.paper_code)"),
            ("mix_label", "str", "作者定义的配合比标签名, 如 M0, S-PE1.5"),
            ("author_defined_concrete_label", "str", "作者定义的混凝土类型名, 如 UHPC, NSC, HPC"),
            ("fiber_enhanced", "int", "是否纤维增强(0=否, 1=是)"),
            ("binder_type", "str", "胶凝材料类型"),
            ("water_binder_ratio", "float", "水胶比(无量纲数值)"),
            ("cement_kg_m3", "float", "水泥用量(kg/m3)"),
            ("silica_fume_kg_m3", "float", "硅灰用量(kg/m3)"),
            ("limestone_filler_kg_m3", "float", "石灰石粉(kg/m3)"),
            ("fly_ash_kg_m3", "float", "粉煤灰(kg/m3)"),
            ("slag_kg_m3", "float", "矿渣(kg/m3)"),
            ("metakaolin_kg_m3", "float", "偏高岭土(kg/m3)"),
            ("water_kg_m3", "float", "用水量(kg/m3)"),
            ("fine_aggregate_kg_m3", "float", "细骨料(kg/m3)"),
            ("coarse_aggregate_kg_m3", "float", "粗骨料(kg/m3)"),
            ("silica_sand_kg_m3", "float", "石英砂(kg/m3)"),
            ("lightweight_aggregate_kg_m3", "float", "轻骨料(kg/m3)"),
            ("superplasticizer_kg_m3", "float", "减水剂(kg/m3)"),
            ("steel_fiber_volume_fraction", "float", "钢纤维体积掺量(%)"),
            ("pp_fiber_volume_fraction", "float", "PP纤维体积掺量(%)"),
            ("pe_fiber_volume_fraction", "float", "PE纤维体积掺量(%)"),
            ("pva_fiber_volume_fraction", "float", "PVA纤维体积掺量(%)"),
            ("pom_fiber_volume_fraction", "float", "POM纤维体积掺量(%)"),
            ("glass_fiber_volume_fraction", "float", "玻璃纤维体积掺量(%)"),
            ("carbon_fiber_volume_fraction", "float", "碳纤维体积掺量(%)"),
            ("other_fiber_volume_fraction", "float", "其他纤维体积掺量(%)"),
            ("notes", "str", "备注"),
        ],
        "required_fields": ["mix_code", "paper_code", "mix_label"],
    },
    "fibers": {
        "description": "纤维明细表 - 外键→mix_proportions.mix_code",
        "fields": [
            ("fiber_code", "str", "纤维编号(PK), 格式 P_001_M_001_F01"),
            ("mix_code", "str", "所属配合比编号(外键→mix_proportions.mix_code)"),
            ("fiber_type", "str", "纤维类型: steel/polypropylene/polyethylene/polyvinyl_alcohol/polyoxymethylene/glass/carbon/basalt/other"),
            ("display_name", "str", "显示名称, 如 Steel, Polypropylene (PP)"),
            ("material_class", "str", "材料大类: metallic/synthetic_polymer/mineral/other"),
            ("volume_fraction_pct", "float", "体积掺量(%)"),
            ("length_mm", "float", "纤维长度(mm)"),
            ("diameter_min_mm", "float", "最小直径(mm)"),
            ("diameter_max_mm", "float", "最大直径(mm)"),
            ("aspect_ratio", "float", "长径比"),
            ("mass_kg_m3", "float", "纤维质量(kg/m3)"),
            ("shape", "str", "形状: straight/hooked/crimped/twisted"),
            ("elastic_modulus_gpa", "float", "弹性模量(GPa)"),
            ("tensile_strength_mpa", "float", "抗拉强度(MPa)"),
            ("melting_temp_c", "float", "熔点温度(C), 对高温分析关键"),
            ("density_g_cm3", "float", "密度(g/cm3)"),
            ("note", "str", "备注"),
        ],
        "required_fields": ["fiber_code", "mix_code", "fiber_type"],
    },
    "specimens_group": {
        "description": "试件组表 - 外键→mix_proportions.mix_code",
        "fields": [
            ("specimen_group_code", "str", "试件组编号(PK), 格式 P_001_Compr_G_001"),
            ("mix_code", "str", "所属配合比编号(外键→mix_proportions.mix_code)"),
            ("specimen_label", "str", "试件标签, 如 S-PE1.5, M0"),
            ("specimen_shape", "str", "形状: cube/cylinder/prism/dog_bone/beam/disk/plate/other"),
            ("intended_test_type", "str", "预期试验: compressive_test/tensile_test/flexural_test"),
            ("length_mm", "float", "长度(mm)"),
            ("width_mm", "float", "宽度(mm)"),
            ("height_mm", "float", "高度(mm)"),
            ("diameter_mm", "float", "直径(mm), 圆柱体用"),
            ("thickness_mm", "float", "厚度(mm), 板状用"),
            ("gauge_length_mm", "float", "标距长度(mm), 拉伸试验用"),
            ("gauge_width_mm", "float", "标距宽度(mm), 狗骨头用"),
            ("age_at_test_day", "int", "试验龄期(天), 通常28"),
            ("curing_method", "str", "养护方式: water_curing/steam_curing/standard_curing/air_curing"),
            ("curing_temp_c", "float", "养护温度(C)"),
            ("curing_rh_pct", "float", "养护湿度(%)"),
            ("note", "str", "备注"),
        ],
        "required_fields": ["specimen_group_code", "mix_code", "specimen_shape"],
    },
    "specimens": {
        "description": "个体级试件表 - 外键→specimens_group.specimen_group_code",
        "fields": [
            ("specimen_id", "int", "自增主键(SERIAL), 数据库自动管理"),
            ("specimen_code", "str", "个体试件编号(UNIQUE), 格式 P_001_M_001_Compr_S_001"),
            ("specimen_group_code", "str", "所属试件组编号(外键→specimens_group.specimen_group_code)"),
            ("specimen_label", "str", "试件标签"),
            ("specimen_shape", "str", "形状: cube/cylinder/prism/dog_bone/beam/disk/plate/other"),
            ("length_mm", "float", "长度(mm)"),
            ("width_mm", "float", "宽度(mm)"),
            ("height_mm", "float", "高度(mm)"),
            ("diameter_mm", "float", "直径(mm)"),
            ("thickness_mm", "float", "厚度(mm)"),
            ("gauge_length_mm", "float", "标距长度(mm)"),
            ("gauge_width_mm", "float", "标距宽度(mm)"),
            ("age_at_test_day", "int", "试验龄期(天)"),
            ("curing_method", "str", "养护方式"),
            ("note", "str", "备注"),
        ],
        "required_fields": ["specimen_code", "specimen_group_code", "specimen_shape"],
    },
    "heating_protocols": {
        "description": "加热协议表 - 外键→material_data.paper_code",
        "fields": [
            ("heating_protocol_id", "str", "加热协议编号(PK), 格式 P_001_H_001, 常温用 P_001_Amb"),
            ("paper_code", "str", "所属论文编号(外键→material_data.paper_code)"),
            ("target_temperature", "float", "目标温度(C), 常温填20或null"),
            ("target_temperature_display", "str", "温度显示名, 如 '200 C', 'Load Level 30%'"),
            ("cycle", "int", "加热循环次数, 默认1"),
            ("heating_rate_degree_min", "float", "升温速率(C/min)"),
            ("holding_time_min", "float", "恒温保持时间(min)"),
            ("cooling_time_min", "float", "冷却时间(min)"),
            ("cooling_method", "str", "冷却方式: natural/air/water"),
            ("fire_curve", "str", "火灾曲线标准: ISO-834/RABT/HC/ASTM-E119"),
            ("loaded_during_heating", "str", "加热时受载: yes/no"),
            ("load_level_pct", "float", "载荷水平(%)"),
            ("notes", "str", "备注"),
        ],
        "required_fields": ["heating_protocol_id", "paper_code"],
    },
    "test_methods": {
        "description": "试验方法表 - 外键→material_data.paper_code",
        "fields": [
            ("method_code", "str", "方法编号(PK), 格式 P_001_ME_Compr_001"),
            ("paper_code", "str", "所属论文编号(外键→material_data.paper_code)"),
            ("test_type", "str", "试验类型: compressive_test/uniaxial_tensile_test/splitting_tensile_test/flexural_test"),
            ("test_state", "str", "试验状态: hot/ambient/cold/post-cooling"),
            ("standard", "str", "遵循标准全称, 如 ASTM C39 / GB/T 50081"),
            ("standard_code", "str", "标准编号, 如 ASTM C39"),
            ("loading_rate", "float", "加载速率数值"),
            ("loading_rate_unit", "str", "加载速率单位: N/s/MPa/s/mm/min/kN/s"),
            ("machine_type", "str", "试验机类型"),
            ("notes", "str", "备注"),
        ],
        "required_fields": ["method_code", "test_type"],
    },
    "test_result_group": {
        "description": "试验结果组表(宽格式) - 核心输出表",
        "fields": [
            ("result_group_code", "str", "结果组编号(PK), 格式 P_001_RG_001"),
            ("paper_code", "str", "所属论文编号(外键→material_data.paper_code)"),
            ("heating_protocol_id", "str", "加热协议ID(外键)"),
            ("specimen_group_code", "str", "试件组ID(外键)"),
            ("specimen_label", "str", "试件标签"),
            ("spalling", "str", "爆裂现象: yes/no/minor/severe/explosive/none"),
            ("compressive_group_code", "str", "抗压试件组ID(外键)"),
            ("compressive_test_method_code", "str", "抗压试验方法ID(外键)"),
            ("compressive_strength", "float", "抗压强度(MPa)"),
            ("direct_tensile_group_code", "str", "直接拉伸试件组ID(外键)"),
            ("direct_tensile_test_method_code", "str", "直接拉伸试验方法ID(外键)"),
            ("direct_tensile_strength", "float", "直接拉伸强度(MPa)"),
            ("splitting_tensile_group_code", "str", "劈裂拉伸试件组ID(外键)"),
            ("splitting_tensile_method_code", "str", "劈裂拉伸试验方法ID(外键)"),
            ("splitting_tensile_strength", "float", "劈裂抗拉强度(MPa)"),
            ("flexural_group_code", "str", "抗弯试件组ID(外键)"),
            ("flexural_test_method_code", "str", "抗弯试验方法ID(外键)"),
            ("flexural_strength", "float", "抗弯强度(MPa)"),
            ("elastic_modulus", "float", "弹性模量(GPa)"),
            ("peak_strain", "float", "峰值应变(mm/mm)"),
            ("mass_loss_ratio_percent", "float", "质量损失率(%)"),
            ("failure_mode", "str", "破坏模式描述"),
            ("residual_strength_ratio", "float", "残余强度比"),
            ("notes", "str", "备注"),
        ],
        "required_fields": ["result_group_code", "paper_code"],
    },
    "test_results": {
        "description": "试验结果表(长格式) - 每行一个性质值对",
        "fields": [
            ("result_id", "int", "自增主键(SERIAL), 数据库自动管理"),
            ("result_code", "str", "结果编号(UNIQUE), 格式 P_001_R_001"),
            ("method_code", "str", "方法编号(外键→test_methods)"),
            ("specimen_code", "str", "个体试件编号(外键→specimens.specimen_code)"),
            ("specimen_label", "str", "试件标签"),
            ("heating_protocol_id", "str", "加热协议ID"),
            ("test_state", "str", "试验状态: hot/ambient/cold/post-cooling"),
            ("property_code", "str", "性质编码: compressive_strength/elastic_modulus/peak_strain/mass_loss_ratio_percent等"),
            ("value_numeric", "float", "数值型测量值"),
            ("value_text", "str", "文本型测量值"),
            ("value_min", "float", "最小值"),
            ("value_max", "float", "最大值"),
            ("value_mean", "float", "平均值"),
            ("value_std_dev", "float", "标准差"),
            ("sample_size", "int", "样本数量"),
            ("unit", "str", "单位: MPa/GPa/mm/mm/%"),
            ("failure_mode", "str", "破坏模式"),
            ("spalling", "str", "爆裂现象: yes/no/minor/severe/explosive/none"),
            ("notes", "str", "备注"),
        ],
        "required_fields": ["result_code", "property_code"],
    },
}


class get_data_v2:
    """
    耦合版多表LLM数据提取器 v3.0

    核心设计：material_data 为主表(目录)，融合v1单表与v2多表
    - material_data 替代了原来的 papers 表
    - 所有子表外键指向 material_data.paper_code
    - 支持部分列为空（不是每个文档都有所有列的数据）
    - 单表插入(文献元数据)与多表插入(实验数据)统一流程

    使用流程：
    1. extractor = get_data_v2(llm_client)
    2. result = extractor.extract(content)   # 返回 {table_name: [rows...]}
    3. extractor.preview()                   # 预览提取结果
    """

    description = "耦合版多表LLM数据提取器v3.0 - material_data为主表(目录)"

    def __init__(self, llm_client=None):
        self.llm_client = llm_client
        self.content = None
        self.data = None
        self._last_llm_response = None

    def extract(self, content: str, custom_prompt: Optional[str] = None) -> Dict[str, list]:
        if not content or not content.strip():
            raise ValueError("文档内容为空")

        import time as _time
        _t0 = _time.monotonic()

        self.content = content
        _t1 = _time.monotonic()
        prompt = custom_prompt or self._build_extraction_prompt()
        _t2 = _time.monotonic()
        print(f"[LLM ⏱] Prompt built: {len(prompt)} chars ({_t2 - _t1:.1f}s)")

        response = self._call_llm(prompt)
        _t3 = _time.monotonic()
        print(f"[LLM ⏱] LLM call: ({_t3 - _t2:.1f}s)")

        self.data = self._parse_multi_table_response(response)
        _t4 = _time.monotonic()
        print(f"[LLM ⏱] Total extract: ({_t4 - _t0:.1f}s) = prompt({_t2 - _t1:.1f}s) + llm({_t3 - _t2:.1f}s) + parse({_t4 - _t3:.1f}s)")
        return self.data

    def _build_extraction_prompt(self) -> str:
        content = self.content
        original_length = len(content)

        content = self._smart_truncate(content, max_length=45000)

        if len(content) < original_length:
            print(f"\n[INFO] 文档已智能截断: {original_length} -> ~{len(content)} 字符")
        else:
            print(f"\n[INFO] 文档长度: {original_length} 字符 (无需截断)")

        schema_descriptions = []
        for table_name, schema in TABLE_SCHEMAS.items():
            field_lines = []
            for fname, ftype, fdesc in schema["fields"]:
                field_lines.append(f"      - {fname} ({ftype}): {fdesc}")
            required_str = ", ".join(schema["required_fields"])
            fields_block = "\n".join(field_lines)
            schema_descriptions.append(f"""### 表: {table_name} ({schema['description']})
      必填字段: {required_str}
      字段列表:
{fields_block}""")

        all_schemas = "\n\n".join(schema_descriptions)

        return f"""You are an expert data extraction system specializing in concrete high-temperature performance experiments. Extract structured experimental data from the following academic paper.

## CRITICAL RULES (MUST FOLLOW):

1. **ONLY extract data explicitly stated in the document** - If a field is not mentioned, fill null. NEVER guess or fabricate values.
2. **Preserve exact numeric precision** - Do NOT round or approximate. "34.1" stays "34.1", not "34" or "34.10".
3. **Standardize units** - Use: MPa (strength), GPa (modulus), mm (length), kg/m3 (density/mix), % (ratio/fraction), C (temperature).
4. **Relational integrity** - Foreign keys (paper_code, mix_code) MUST have matching records in parent tables.
5. **Completeness over precision** - Better to extract an extra record than to miss one, especially for mix proportions and test results.
6. **material_data is the master table** - Every paper MUST have one record here first; all other tables reference it via paper_code.

## TABLE SCHEMAS:

{all_schemas}

## EXTRACTION STRATEGY:

### material_data (Master Table) - MANDATORY
- One record per paper
- paper_code: P_001, P_002... (sequential)
- bib_key: generate from title+author+year (e.g., zhang2021spalling)
- authors_bib: join author names with " and "
- Fill even if the paper has no experimental data

### mix_proportions - MOST CRITICAL TABLE! Data is mostly in tables!
- One record per distinct mix design (each table row = one record)
- mix_code format: P_XXX_M_YYY
- **KEY: Mix proportion data in academic papers is almost always in tables! Read EVERY [Table X] section carefully!**

#### Column Name Mapping (document abbreviation -> database field):

| Document abbreviation | Database field | Unit |
|---|---|---|
| C / Cement / OPC | cement_kg_m3 | kg/m3 |
| SF / Silica fume | silica_fume_kg_m3 | kg/m3 |
| FA / Fly ash | fly_ash_kg_m3 | kg/m3 |
| Slag / GGBS | slag_kg_m3 | kg/m3 |
| MK / Metakaolin | metakaolin_kg_m3 | kg/m3 |
| LF / Limestone filler | limestone_filler_kg_m3 | kg/m3 |
| SS / Silica sand | silica_sand_kg_m3 | kg/m3 |
| Sand / Fine aggregate | fine_aggregate_kg_m3 | kg/m3 |
| CA / Coarse aggregate | coarse_aggregate_kg_m3 | kg/m3 |
| W / Water | water_kg_m3 | kg/m3 |
| w/b / W/B / w/c / w/cm | water_binder_ratio | dimensionless |
| SP / Superplasticizer / HRWRA | superplasticizer_kg_m3 | kg/m3 or L/m3 |
| Steel fiber | steel_fiber_volume_fraction | % |
| PP fiber / PPF | pp_fiber_volume_fraction | % |
| PE fiber / PEF | pe_fiber_volume_fraction | % |
| PVA fiber | pva_fiber_volume_fraction | % |
| Glass fiber | glass_fiber_volume_fraction | % |
| Carbon fiber | carbon_fiber_volume_fraction | % |
| Flow / Slump | notes field | mm/% |

#### Handling HORIZONTAL tables (CRITICAL!):
Some papers arrange mix data horizontally (each COLUMN = one mixture):
```
Table 2. Mix proportions
Mixture    M0    M1    M2    M3
Cement     350   400   400   400
w/c ratio  0.45  0.30  0.30  0.30
PP fiber   0     0.1   0.2   0.3
```
**Each COLUMN becomes one mix_proportions record!** Transpose rows to fields using the mapping above.
Result: 4 records (M0, M1, M2, M3), each with cement_kg_m3, water_binder_ratio, pp_fiber_volume_fraction filled.

#### Fiber volume fraction rules:
- If column header says "vol%" or "%" -> value is volume fraction, fill directly into xxx_fiber_volume_fraction
- If column header says "kg/m3" -> value is mass, convert: volume_fraction = mass / (fiber_density * 100). If density unknown, put mass in notes.
- fiber_enhanced = 1 if ANY fiber field > 0, else 0
- If a component amount is 0 or blank -> fill null (not 0)

#### Water-binder ratio:
- If document says "water-to-binder ratio was 0.2" or "w/b=0.2" -> water_binder_ratio=0.2
- This is often in the text, not in the table!

### fibers - Fiber properties are CRITICAL for high-temperature analysis!
- One record per fiber type used (mixed fibers = multiple records)
- fiber_code format: P_XXX_M_YYY_FZZ
- **Fiber properties (length, diameter, tensile strength, elastic modulus, density, melting point) are often in a SEPARATE table**, e.g., "Table 2: Properties of PE and PP fibers"
- **MUST extract fiber property table if present!**
- Example: "PE: Diameter 26-30um, Length 12mm, Tensile strength 3250 MPa, Elastic modulus 113 GPa, Density 0.96 g/cm3"
  -> fiber_type="polyethylene", diameter_min_mm=0.026, diameter_max_mm=0.030, length_mm=12, tensile_strength_mpa=3250, elastic_modulus_gpa=113, density_g_cm3=0.96
- **melting_temp_c is CRITICAL for high-temperature analysis!** PP fiber ~160-175C, PE fiber ~130-145C
- If the document mentions fiber melting point, it MUST be extracted!

### specimens_group
- One record per group of specimens with identical geometry
- specimen_group_code format: P_XXX_TestType_G_ZZZ
- **Specimen dimensions are often described in the text**, e.g., "Cubic (50 mm), dog bone (150 mm x 35 mm x 15 mm), cylindrical (diameter: 50 mm, height: 100 mm)"
- Shape mapping: cube/cylinder/prism/dog_bone/beam/disk/plate/other
- Test type mapping: compressive_test/uniaxial_tensile_test/splitting_tensile_test/flexural_test

### specimens
- One record per individual specimen (finer granularity than specimens_group)
- If the document does not provide individual specimen data, leave as empty array []

### heating_protocols - CORE for high-temperature research!
- One record per temperature level / heating condition
- heating_protocol_id format: P_XXX_H_ZZZ
- **Ambient control group MUST also have a record** with target_temperature=20, heating_rate_degree_min=null
- **Heating info is often scattered in the text**, e.g., "exposed to ISO 834 fire curve for 1 h" or "heated to the required temperature for a duration of 1 h"
- fire_curve: ISO 834, RABT, HC, ASTM-E119 etc.
- cooling_method: "cooled down naturally" -> natural, "taken out for testing" -> air
- If the paper has NO high-temperature experiments, leave as empty array []

### test_methods
- One record per test method
- method_code format: P_XXX_ME_TestType_YYY
- Loading rate: "loading rate of 100 kN/min" -> loading_rate=100, loading_rate_unit="kN/min"
- Test standard: "ASTM C1437-15", "ASTM C39" etc.
- test_state: hot/ambient/cold/post-cooling

### test_result_group - MOST IMPORTANT OUTPUT TABLE!
- One record per (mix + heating condition) combination
- result_group_code format: P_XXX_RG_ZZZ
- **Test results may be in tables OR in the text**
- Strength extraction rules:
  - "34.1 MPa" -> compressive_strength=34.1
  - "34.1 (100%)" -> compressive_strength=34.1, residual_strength_ratio=1.0
  - "7.69 +/- 0.65 MPa" -> compressive_strength=7.69 (mean value)
  - "34.1 (100%)" and "28.9 (85%)" -> TWO records with residual_strength_ratio 1.0 and 0.85
- **spalling field**: If the paper describes spalling, MUST extract! yes/no/minor/severe/explosive/none
- **CRITICAL: If the paper has multiple mixes at different temperatures, create one record per (mix x temperature) combination!**
  - e.g., 10 mixes x 6 temperatures = up to 60 test_result_group records
  - e.g., 7 mixes x 5 temperatures = up to 35 test_result_group records
- **Horizontal strength tables**: If the table has mixtures as columns and properties as rows, transpose:
  ```
  Table 4. Strength at 200C
  Mixture  M1    M2    M3
  Comp.    45.0  31.8  25.0
  Split.   3.3   3.2   2.3
  ```
  -> One record per Mixture with compressive_strength and splitting_tensile_strength filled

### test_results (long format, optional)
- One row per measured property
- If test_result_group already contains all results, leave as empty array []

## DOCUMENT CONTENT:

{content}

## ADDITIONAL EXTRACTION RULES:

#### Numeric value handling:
- "34.1 ± 2.3" → extract "34.1" (the mean), ignore ± range
- "34.1 (2.3)" → extract "34.1" if it's mean(std), ignore parenthetical std
- "34.1 MPa (100%)" → compressive_strength=34.1, residual_strength_ratio=1.0
- "-" (dash) in a table cell → treat as null (not applicable), NOT as 0
- "0" or "0.0" → extract as 0 (explicit zero IS data)
- An empty cell → fill null

#### Disambiguation rules:
- "Compressive strength" without qualifier → compressive_strength in test_result_group
- "Splitting tensile" or "split tensile" → splitting_tensile_strength
- "Flexural" or "bending" → flexural_strength
- "Modulus of elasticity" or "E" → elastic_modulus
- "Peak strain" or "εmax" → peak_strain
- "Mass loss" or "weight loss" → mass_loss_pct
- If a table has columns "20C 200C 400C 600C" → these are temperatures, create ONE heating_protocol per temp AND ONE test_result_group per (mix x temp)

#### Cross-referencing (CRITICAL for accuracy!):
- When extracting test_result_group records, make SURE each mix_label + temperature combination references the CORRECT:
  - paper_code (from material_data)
  - specimen_group_code (from the right specimens_group)
  - heating_protocol_id (from the right heating_protocols)
  - method_code (from the right test_methods)
- If you create a P_001_M_002 mix, its test results MUST use the same mix_code, not P_001_M_001

#### Handling the Qwen-VL markdown table output:
- The document content includes markdown tables labeled as [Table N: ...] — these are pre-extracted by vision AI
- Read EVERY [Table N] block carefully — this is where mix proportions, fiber properties, and test results live
- The markdown format is: header row, separator row (|---|---|), data rows
- Each data ROW in a mix proportion table = one mix_proportions record
- Each data ROW in a strength table = one or more test_result_group records (one per temperature column)

## OUTPUT FORMAT (strict JSON):

```json
{{
  "material_data": [
    {{"paper_code": "P_001", "bib_key": "...", "title": "...", ...}}
  ],
  "mix_proportions": [
    {{"mix_code": "P_001_M_001", "paper_code": "P_001", "mix_label": "M0", "cement_kg_m3": 350, "water_binder_ratio": 0.45, ...}}
  ],
  "fibers": [
    {{"fiber_code": "P_001_M_001_F01", "mix_code": "P_001_M_001", "fiber_type": "polypropylene", "length_mm": 12, ...}}
  ],
  "specimens_group": [
    {{"specimen_group_code": "P_001_H_G_001", "shape": "cube", "dimension_1_mm": 50, ...}}
  ],
  "specimens": [],
  "heating_protocols": [
    {{"heating_protocol_id": "P_001_H_001", "paper_code": "P_001", "target_temperature": 20, ...}},
    {{"heating_protocol_id": "P_001_H_002", "paper_code": "P_001", "target_temperature": 200, ...}}
  ],
  "test_methods": [
    {{"method_code": "P_001_ME_Compressive_001", "test_type": "compressive_test", ...}}
  ],
  "test_result_group": [
    {{"result_group_code": "P_001_RG_001", "paper_code": "P_001", "mix_code": "P_001_M_001", "heating_protocol_id": "P_001_H_001", "compressive_strength": 45.0, ...}}
  ],
  "test_results": []
}}
```

Read the document carefully. Focus on:
1. EVERY [Table N] block — these contain pre-extracted tabular data (mix proportions, fiber properties, test results)
2. Text before and after tables — often contains specimen dimensions, test conditions, and critical details not in the table
3. Heating conditions — every temperature level needs a protocol record + a result group record per mix
4. Cross-referencing: make sure foreign keys are consistent across tables

CRITICAL: If the paper has NO data for a table, output an EMPTY ARRAY [] — do NOT omit the key.

For uncertain fields, fill null rather than fabricate.
Return ONLY pure JSON, no other text."""

    def _smart_truncate(self, content: str, max_length: int = 45000) -> str:
        if len(content) <= max_length:
            return content

        table_blocks = []
        non_table_parts = []
        last_end = 0

        for m in re.finditer(r'\[Table\s+\d+[:\s].*?(?=\n=== Page|\Z)', content, re.DOTALL):
            table_blocks.append(content[m.start():m.end()])
            non_table_parts.append(content[last_end:m.start()])
            last_end = m.end()

        non_table_parts.append(content[last_end:])

        compressed_tables = []
        for tb in table_blocks:
            compressed = re.sub(r'\n{3,}', '\n\n', tb)
            lines = compressed.split('\n')
            filtered = [l for l in lines if l.strip()]
            compressed_tables.append('\n'.join(filtered))

        table_text = "\n\n".join(compressed_tables)
        table_len = len(table_text)

        if table_len > max_length * 0.85:
            max_table_len = int(max_length * 0.85)
            compressed_tables2 = []
            current_len = 0
            for tb in compressed_tables:
                if current_len + len(tb) + 2 <= max_table_len:
                    compressed_tables2.append(tb)
                    current_len += len(tb) + 2
                else:
                    remaining_space = max_table_len - current_len
                    if remaining_space > 200:
                        compressed_tables2.append(tb[:remaining_space] + "\n[... 表格截断 ...]")
                    break
            table_text = "\n\n".join(compressed_tables2)
            table_len = len(table_text)

        remaining = max_length - table_len

        if remaining > 3000:
            priority_sections = []
            other_sections = []
            for part in non_table_parts:
                part_lower = part.lower()
                is_priority = any(kw in part_lower for kw in [
                    'result', 'strength', 'mpa', 'spalling', 'compressive',
                    'tensile', 'specimen', 'test method', 'loading rate',
                    'splitting', 'modulus', 'mass loss', 'table',
                    'mix proportion', 'fiber', 'heating', 'temperature',
                    'cube', 'cylinder', 'dog bone', 'prism',
                    'w/b', 'w/c', 'water-binder', 'water-cement',
                    'elastic modulus', 'peak strain', 'residual', 'retained',
                    'fire curve', 'iso 834', 'astm e119', 'astm c39', 'furnace',
                    'exposed to', 'elevated temperature', 'target temperature',
                    'cooling', 'heating rate', 'duration', 'soaking',
                    'spalling', 'explosive', 'surface scaling',
                    'cement', 'silica fume', 'fly ash', 'slag', 'ggbs',
                    'superplasticizer', 'water reducer', 'hrwra',
                    'steel fiber', 'pp fiber', 'pe fiber', 'pva fiber',
                    'polypropylene', 'polyethylene', 'polyvinyl alcohol',
                    'volume fraction', 'aspect ratio', 'tensile strength',
                    'melting point', 'density', 'elongation',
                    'fine aggregate', 'coarse aggregate', 'limestone',
                    'quartz sand', 'silica sand', 'lightweight',
                    'permeability', 'porosity', 'microstructure',
                    'scanning electron', 'optical microscope',
                    'conclusion', 'abstract', 'introduction',
                ])
                if is_priority:
                    priority_sections.append(part)
                else:
                    other_sections.append(part)

            priority_text = "\n\n".join(priority_sections)
            other_text = "\n\n".join(other_sections)

            priority_len = len(priority_text)
            other_remaining = remaining - priority_len

            if other_remaining > 2000:
                if len(other_text) > other_remaining:
                    keep_start = int(other_remaining * 0.6)
                    keep_end = other_remaining - keep_start
                    other_text = (
                        other_text[:keep_start] +
                        "\n\n[... 文档中间部分已省略 ...]\n\n" +
                        other_text[-keep_end:]
                    )
                return table_text + "\n\n" + priority_text + "\n\n" + other_text
            elif other_remaining > 0:
                return table_text + "\n\n" + priority_text + "\n\n" + other_text[:other_remaining]
            else:
                combined = table_text + "\n\n" + priority_text
                if len(combined) > max_length:
                    return combined[:max_length]
                return combined
        elif remaining > 0:
            non_table_text = "\n\n".join(non_table_parts)
            return table_text + "\n\n" + non_table_text[:remaining]
        else:
            return content[:max_length]

    def _call_llm(self, prompt: str, retries: int = 2) -> str:
        if not self.llm_client:
            raise ValueError("未配置 LLM 客户端")
        last_error = None
        for attempt in range(retries + 1):
            try:
                response = self.llm_client.generate(
                    messages=[{"role": "user", "content": prompt}],
                    temperature=0,
                    max_tokens=24576,
                    seed=42,
                )
                result = response.choices[0].message.content
                if not result or len(result.strip()) < 50:
                    raise RuntimeError(f"LLM returned empty or too-short response ({len(result)} chars)")
                self._last_llm_response = result
                return result
            except Exception as e:
                last_error = e
                if attempt < retries:
                    wait = 3 * (attempt + 1)
                    print(f"[LLM] Call failed (attempt {attempt+1}/{retries+1}): {e}, retrying in {wait}s...")
                    import time
                    time.sleep(wait)
                    continue
        raise RuntimeError(f"LLM 调用失败 after {retries+1} attempts: {last_error}")

    def _parse_multi_table_response(self, response: str) -> Dict[str, list]:
        text = response.strip()
        
        if text.startswith("```"):
            match = re.search(r'```(?:json)?\s*\n?(.*?)```', text, re.DOTALL)
            if match:
                text = match.group(1).strip()
            else:
                text = re.sub(r'^```(?:json)?\s*\n?', '', text).strip()

        try:
            raw_data = json.loads(text)
        except json.JSONDecodeError as e:
            print(f"\n[WARN] JSON解析失败: {str(e)}")
            print(f"[WARN] 响应长度: {len(text)} 字符")
            
            # 🔧 智能截断修复策略
            raw_data = self._fix_truncated_json(text, e)
            
            if isinstance(raw_data, dict) and "error" in raw_data:
                # 修复失败，返回错误信息
                return raw_data

        if not isinstance(raw_data, dict):
            return {"error": [{"error": "顶层必须是JSON对象", "raw_text": str(raw_data)[:500]}]}

        result = {}
        total_records = 0
        errors = []

        for table_name in TABLE_SCHEMAS.keys():
            table_data = raw_data.get(table_name, [])
            if table_data is None:
                table_data = []
            if isinstance(table_data, dict):
                table_data = [table_data]
            if not isinstance(table_data, list):
                errors.append(f"{table_name}: 期望list, 得到{type(table_data).__name__}")
                table_data = []

            cleaned_rows = []
            for row in table_data:
                if isinstance(row, dict):
                    cleaned_rows.append(row)
                    total_records += 1
                else:
                    errors.append(f"{table_name}: 跳过非dict行")

            result[table_name] = cleaned_rows

        result["_meta"] = {
            "total_records": total_records,
            "tables_with_data": sum(1 for k, v in result.items() if k != "_meta" and len(v) > 0),
            "errors": errors,
        }
        return result
    
    def _fix_truncated_json(self, text: str, original_error: Exception) -> Dict[str, Any]:
        """
        Smart JSON repair for truncated LLM responses.
        
        Strategies (tried in order):
        1. Find the last complete closing brace and truncate there
        2. Complete unclosed braces/quotes
        3. Strip trailing incomplete records from the last array
        4. Regex-based field-level repair for the last partial object
        """
        error_msg = str(original_error)
        original_text = text
        
        # ── Strategy 1: Find last complete closing brace ──
        last_brace = text.rfind('}')
        if last_brace > 0 and last_brace > len(text) * 0.6:
            try:
                fixed = text[:last_brace + 1]
                data = json.loads(fixed)
                print(f"[FIX] Strategy 1: truncated at last }}, position {last_brace+1}")
                return data
            except Exception:
                pass
        
        # ── Strategy 2: Complete unclosed braces and quotes ──
        try:
            fixed = self._complete_truncated_json(text)
            data = json.loads(fixed)
            print(f"[FIX] Strategy 2: brace completion succeeded")
            return data
        except Exception:
            pass
        
        # ── Strategy 3: Strip trailing incomplete array entries ──
        try:
            # Find the last complete object in the last array
            # Pattern: },{ or }] — try to truncate at the second-to-last closing brace
            # First, try removing everything after the last `},` (common semi-complete object)
            stripped = re.sub(r',\s*\{\s*"[^}]*$', '', text)
            # Then close arrays/objects
            fixed = self._complete_truncated_json(stripped)
            data = json.loads(fixed)
            print(f"[FIX] Strategy 3: stripped trailing incomplete record, then completed braces")
            return data
        except Exception:
            pass
        
        # ── Strategy 4: Last-resort — try to recover by removing the LAST key in each array ──
        try:
            # For each table, try to drop the last object in each array
            for table_name in TABLE_SCHEMAS.keys():
                pattern = rf'("{table_name}"\s*:\s*\[.*?)(\{{\s*"[^}}]*$|"[^"]*"\s*:\s*[^,}}\]]*$)'
                match = re.search(pattern, text, re.DOTALL)
                if match:
                    # Remove the incomplete trailing fragment
                    text = text[:match.start(1)] + text[match.start(1):match.end(1)].rstrip(', \t\n')
                    if not text.rstrip().endswith(']'):
                        text = text.rstrip() + '\n]'
            # Try completing braces
            fixed = self._complete_truncated_json(text)
            data = json.loads(fixed)
            print(f"[FIX] Strategy 4: dropped incomplete last entries, then completed braces")
            return data
        except Exception:
            pass
        
        # ── All strategies failed ──
        print(f"[ERROR] All JSON repair strategies failed. Error: {error_msg[:200]}")
        return {
            "error": [{
                "error": f"JSON解析失败(所有修复策略均失败): {error_msg[:200]}",
                "raw_text": original_text[:1000],
                "_truncated": True,
                "_original_length": len(original_text),
                "_hint": "LLM响应被截断或格式严重错误。建议：1)缩短文档 2)减小max_tokens 3)检查API响应"
            }]
        }
    
    def _complete_truncated_json(self, text: str) -> str:
        """
        Complete truncated JSON by counting and closing unpaired braces/quotes.
        
        Handles:
        - Unclosed strings
        - Unclosed objects/arrays
        - Trailing garbage characters
        - Comma-dangling before closing
        """
        # Remove trailing garbage (commas, whitespace, partial tokens)
        text = text.rstrip()
        # Remove trailing comma before a closing brace/bracket that was never written
        text = re.sub(r',\s*$', '', text)
        # Remove trailing partial key-value like '"key":' or '"key": val'
        text = re.sub(r',\s*"[^"]*"\s*:\s*[^\s,}]*$', '', text)
        
        # Count braces
        stack = []
        in_string = False
        escape_next = False
        
        for i, char in enumerate(text):
            if escape_next:
                escape_next = False
                continue
                
            if char == '\\' and in_string:
                escape_next = True
                continue
                
            if char == '"' and not escape_next:
                in_string = not in_string
                continue
                
            if not in_string:
                if char in '{[':
                    stack.append(char)
                elif char == '}':
                    if stack and stack[-1] == '{':
                        stack.pop()
                elif char == ']':
                    if stack and stack[-1] == '[':
                        stack.pop()
        
        # Close unclosed string
        if in_string:
            text += '"'
        
        # Close remaining openers
        while stack:
            opener = stack.pop()
            closer = '}' if opener == '{' else ']'
            text += closer
        
        return text

    def preview(self, max_items: int = 3) -> Dict[str, Any]:
        if not self.data:
            return {"total_tables": 0, "tables": {}}

        preview_output = {}
        meta = self.data.get("_meta", {})

        for table_name, rows in self.data.items():
            if table_name == "_meta":
                continue
            schema = TABLE_SCHEMAS.get(table_name, {})
            preview_rows = []
            for i, row in enumerate(rows[:max_items]):
                if row.get("error"):
                    preview_rows.append({"_index": i + 1, "**ERROR**": row.get("error")})
                else:
                    preview_row = {"_index": i + 1}
                    for key, val in list(row.items())[:8]:
                        preview_row[key] = str(val)[:50] if val is not None else "NULL"
                    preview_rows.append(preview_row)

            preview_output[table_name] = {
                "description": schema.get("description", ""),
                "total_rows": len(rows),
                "preview": preview_rows,
                "has_data": len(rows) > 0,
            }

        return {
            "total_tables": len([k for k in self.data if k != "_meta"]),
            "tables_with_data": meta.get("tables_with_data", 0),
            "total_records": meta.get("total_records", 0),
            "tables": preview_output,
            "errors": meta.get("errors", []),
        }

    def get_table_data(self, table_name: str) -> list:
        if not self.data:
            return []
        return self.data.get(table_name, [])

    def get_all_data(self) -> Dict[str, list]:
        return {k: v for k, v in (self.data or {}).items() if k != "_meta"}
