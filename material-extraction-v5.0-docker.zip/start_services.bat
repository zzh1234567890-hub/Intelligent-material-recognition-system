@echo off
chcp 65001 >nul
title 智能材料识别系统 - 启动脚本

echo.
echo ========================================
echo   智能材料识别系统 - 一键启动
echo ========================================
echo.

:: 检查Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python未安装或不在PATH中
    pause
    exit /b 1
)

:: 显示Python版本
echo [INFO] Python版本:
python --version
echo.

:: 启动后端服务
echo [STEP 1/2] 启动后端服务 (端口 8000)...
echo.
start "Backend Server" cmd /k "cd /d %~dp0 && python -m uvicorn backend.main:app --reload --host 0.0.0.0 --port 8000"

:: 等待后端启动
echo [WAIT] 等待后端服务启动...
timeout /t 3 /nobreak >nul

:: 测试后端连接
curl -s http://localhost:8000/health >nul 2>&1
if errorlevel 1 (
    echo [WARN] 后端可能还在启动中，请稍等...
    timeout /t 2 /nobreak >nul
)

echo.
echo [STEP 2/2] 启动前端服务 (端口 3000)...
echo.
start "Frontend Server" cmd /k "cd /d %~dp0frontend && npm run dev"

echo.
echo ========================================
echo   ✅ 服务启动完成！
echo ========================================
echo.
echo   前端地址: http://localhost:3000
echo   后端地址: http://localhost:8000
echo   API文档: http://localhost:8000/docs
echo.
echo   请在浏览器中打开: http://localhost:3000
echo.
echo   按任意键关闭此窗口（服务将继续运行）...
echo.

pause >nul
