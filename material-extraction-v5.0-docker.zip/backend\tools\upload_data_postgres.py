from __future__ import annotations

import os
from typing import Optional, Dict, Any, List
from datetime import datetime

try:
    import psycopg
    from psycopg import sql as pg_sql
    from psycopg.rows import dict_row
    HAS_POSTGRES = True
except ImportError:
    HAS_POSTGRES = False


class PostgresUploader:
    """
    PostgreSQL 数据库上传工具
    
    功能：
    - 从 Excel 文件读取数据并批量插入到 PostgreSQL
    - 基于 identifier 字段自动去重
    - 支持错误记录和统计
    
    使用示例：
        uploader = PostgresUploader(
            host="localhost",
            port=5432,
            user="postgres",
            password="postgres",
            database="material_db"
        )
        
        result = uploader.upload_from_file("output/material_data.xlsx")
        print(f"成功: {result['success']}, 失败: {result['failed']}")
    """

    description = "PostgreSQL 数据上传工具：Excel → PostgreSQL"

    def __init__(
        self,
        host: str = "localhost",
        port: int = 5432,
        user: str = "postgres",
        password: str = "",
        database: str = "material_db",
        table_name: str = "material_data",
        force_mode: bool = False
    ):
        if not HAS_POSTGRES:
            raise ImportError(
                "请安装 PostgreSQL 驱动: pip install 'psycopg[binary]'"
            )

        self.host = host
        self.port = port
        self.user = user
        self.password = password
        self.database = database
        self.table_name = table_name
        self.force_mode = force_mode  # 强制模式：忽略去重检查

        self.connection: Optional[psycopg.Connection] = None
        self.cursor: Optional[psycopg.Cursor] = None
        
        self.uploaded_count: int = 0
        self.error_records: List[Dict[str, Any]] = []

    def connect(self) -> bool:
        """连接到 PostgreSQL 数据库"""
        try:
            conn_str = f"host={self.host} port={self.port} user={self.user}"
            if self.password:
                conn_str += f" password={self.password}"
            conn_str += f" dbname={self.database}"

            self.connection = psycopg.connect(conn_str)
            # 使用字典游标
            self.cursor = self.connection.cursor(row_factory=dict_row)

            print(f"[PostgreSQL] 已连接: {self.host}:{self.port}/{self.database}")

            # 自动检查并创建表（如果不存在）
            self._ensure_table_exists()

            return True

        except Exception as e:
            print(f"[PostgreSQL] 连接失败: {e}")
            raise

    def _ensure_table_exists(self):
        """确保目标表存在，如果不存在则自动创建"""
        try:
            # 检查表是否存在
            self.cursor.execute("""
                SELECT EXISTS (
                    SELECT FROM information_schema.tables
                    WHERE table_schema = 'public'
                    AND table_name = %s
                );
            """, (self.table_name,))

            # dict_row 游标返回字典，需要使用列名访问
            row = self.cursor.fetchone()
            exists = list(row.values())[0] if row else False

            if not exists:
                print(f"[PostgreSQL] 表 {self.table_name} 不存在，正在自动创建...")
                self._create_table()
                print(f"[PostgreSQL] ✅ 表 {self.table_name} 创建成功")
            else:
                print(f"[PostgreSQL] ✅ 表 {self.table_name} 已存在")

        except Exception as e:
            print(f"[PostgreSQL] 检查/创建表失败: {e}")
            raise

    def _create_table(self):
        """创建 material_data 表"""
        create_sql = """
        CREATE TABLE IF NOT EXISTS material_data (
            id SERIAL PRIMARY KEY,
            identifier VARCHAR(100) NOT NULL DEFAULT '' UNIQUE,
            type VARCHAR(50) NOT NULL DEFAULT '',
            title TEXT,
            authors TEXT,
            journal VARCHAR(200) DEFAULT '',
            volume VARCHAR(20) DEFAULT '',
            issue VARCHAR(20) DEFAULT '',
            pages VARCHAR(50) DEFAULT '',
            year CHAR(4) DEFAULT '',
            publisher VARCHAR(200) DEFAULT '',
            doi VARCHAR(200) DEFAULT '',
            abstract TEXT,

            -- 系统字段
            source_file VARCHAR(500) DEFAULT '',
            uploaded_by VARCHAR(100),
            session_id VARCHAR(100),

            -- 时间戳
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        -- 创建索引
        CREATE INDEX IF NOT EXISTS idx_type ON material_data(type);
        CREATE INDEX IF NOT EXISTS idx_year ON material_data(year);
        CREATE INDEX IF NOT EXISTS idx_journal ON material_data(journal);
        CREATE INDEX IF NOT EXISTS idx_created_at ON material_data(created_at);

        -- 创建更新时间戳触发器
        CREATE OR REPLACE FUNCTION update_updated_at_column()
        RETURNS TRIGGER AS $$
        BEGIN
            NEW.updated_at = CURRENT_TIMESTAMP;
            RETURN NEW;
        END;
        $$ language 'plpgsql';

        DROP TRIGGER IF EXISTS update_material_data_updated_at ON material_data;
        CREATE TRIGGER update_material_data_updated_at
            BEFORE UPDATE ON material_data
            FOR EACH ROW
            EXECUTE FUNCTION update_updated_at_column();
        """

        self.cursor.execute(create_sql)
        self.connection.commit()

    def disconnect(self):
        """断开连接"""
        if self.cursor:
            self.cursor.close()
        if self.connection:
            self.connection.close()
        self.connection = None
        self.cursor = None

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.disconnect()

    def _escape_column_name(self, name: str) -> str:
        """转义列名（PostgreSQL 风格）"""
        return name

    def _get_existing_identifiers(self) -> set:
        """获取数据库中已有的 identifier 集合（用于去重）"""
        identifiers = set()
        try:
            query = pg_sql.SQL("SELECT DISTINCT {} FROM {} WHERE {} IS NOT NULL AND {} != ''").format(
                pg_sql.Identifier('identifier'),
                pg_sql.Identifier(self.table_name),
                pg_sql.Identifier('identifier'),
                pg_sql.Identifier('identifier')
            )
            self.cursor.execute(query)
            for row in self.cursor.fetchall():
                if row.get('identifier'):
                    identifiers.add(str(row['identifier']).strip())
                    
            if identifiers:
                print(f"[PostgreSQL] 数据库中已有 {len(identifiers)} 条记录的 identifier")
                
        except Exception as e:
            print(f"[PostgreSQL] 查询已有 identifier 失败: {e}")

        return identifiers

    def _get_existing_identifiers_quick(self, identifier: str) -> bool:
        """
        快速检查单个 identifier 是否已存在（用于强制模式统计更新数）

        Args:
            identifier: 要检查的标识符

        Returns:
            bool: 是否已存在
        """
        try:
            query = pg_sql.SQL("SELECT 1 FROM {} WHERE {} = %s LIMIT 1").format(
                pg_sql.Identifier(self.table_name),
                pg_sql.Identifier('identifier')
            )
            self.cursor.execute(query, (identifier,))
            return self.cursor.fetchone() is not None
        except Exception as e:
            print(f"[PostgreSQL] 检查 identifier 存在性失败: {e}")
            return False

    def upload_from_file(self, filepath: str) -> Dict[str, Any]:
        """
        从 Excel 文件读取数据并上传到 PostgreSQL

        Args:
            filepath: Excel 文件路径

        Returns:
            dict: 包含 success/failed/skipped_duplicates 统计信息
        """
        from openpyxl import load_workbook

        if not os.path.exists(filepath):
            raise FileNotFoundError(f"Excel 文件不存在: {filepath}")

        # 确保已连接数据库
        if not self.connection:
            self.connect()

        try:
            print(f"[PostgreSQL] 正在读取 Excel 文件: {filepath}")
            wb = load_workbook(filepath, read_only=True)
            sheet = wb.active

            data = []
            headers = []

            for row_idx, row in enumerate(sheet.iter_rows(values_only=True), 1):
                if row_idx == 1:
                    headers = [str(cell).strip() for cell in row if cell]
                    print(f"[PostgreSQL] 检测到列头: {headers}")
                    continue

                record = {}
                for col_idx, cell_value in enumerate(row):
                    col_idx_0 = col_idx + 1
                    if col_idx_0 <= len(headers):
                        key = headers[col_idx]
                        value = str(cell_value).strip() if cell_value is not None else ""
                        record[key] = value

                # 只添加非空记录
                if any(record.values()):
                    data.append(record)

            wb.close()
            print(f"[PostgreSQL] ✅ 从文件读取 {len(data)} 条记录")

            if not data:
                print("[PostgreSQL] ⚠️ 文件中没有数据可上传")
                return {
                    "success": 0,
                    "failed": 0,
                    "total": 0,
                    "skipped_duplicates": 0,
                    "table_name": self.table_name,
                    "errors": [],
                    "message": "Excel 文件为空或没有有效数据"
                }

            return self._insert_batch(data)

        except Exception as e:
            error_msg = f"读取或处理 Excel 文件失败: {e}"
            print(f"[PostgreSQL] ❌ {error_msg}")
            raise Exception(error_msg)

    def _insert_batch(self, data: List[Dict]) -> Dict[str, Any]:
        """
        批量插入数据（支持自动去重或强制模式）

        Args:
            data: 要插入的数据列表

        强制模式 (force_mode=True):
        - 跳过所有去重检查
        - 使用 ON CONFLICT DO UPDATE 更新已有记录（而不是跳过）
        - 适用于：跨电脑迁移、数据恢复、重新导入场景
        """
        if not data:
            return {"success": 0, "failed": 0, "total": 0, "skipped_duplicates": 0, "table_name": self.table_name, "errors": []}

        keys = [k for k in list(data[0].keys()) if k.lower() != 'id']
        
        if not keys:
            return {"success": 0, "failed": 0, "total": 0, "skipped_duplicates": 0, "table_name": self.table_name, "errors": ["没有可插入的列"]}

        has_identifier = 'identifier' in keys
        
        # 强制模式：不查询已有的 identifier，直接全部插入/更新
        if self.force_mode:
            print(f"[PostgreSQL] 🔄 强制模式已启用：将导入所有记录（更新已有记录）")
            existing_identifiers = set()
        else:
            # 正常模式：查询已有 identifier 用于去重
            existing_identifiers = set()
            if has_identifier:
                existing_identifiers = self._get_existing_identifiers()

        success_count = 0
        failed_count = 0
        skipped_duplicates = 0
        updated_count = 0  # 强制模式下更新的记录数
        errors = []

        for idx, record in enumerate(data, 1):
            # 正常模式的去重检查
            if has_identifier and not self.force_mode:
                identifier = str(record.get('identifier', '')).strip()
                if identifier and identifier in existing_identifiers:
                    skipped_duplicates += 1
                    continue

            try:
                columns = [pg_sql.Identifier(k) for k in keys]
                values = [record.get(key, "") for key in keys]

                # 根据模式选择不同的 SQL 策略
                if self.force_mode:
                    # 强制模式：ON CONFLICT DO UPDATE（更新已有记录）
                    insert_query = pg_sql.SQL("INSERT INTO {} ({}) VALUES ({}) ON CONFLICT (identifier) DO UPDATE SET {}").format(
                        pg_sql.Identifier(self.table_name),
                        pg_sql.SQL(', ').join(columns),
                        pg_sql.SQL(', ').join(pg_sql.Placeholder() * len(keys)),
                        pg_sql.SQL(', ').join([
                            pg_sql.SQL("{} = EXCLUDED.{}").format(pg_sql.Identifier(k), pg_sql.Identifier(k))
                            for k in keys if k != 'identifier'
                        ])
                    )
                    
                    # 检查是否为更新操作
                    identifier = str(record.get('identifier', '')).strip()
                    if has_identifier and identifier and identifier in self._get_existing_identifiers_quick(identifier):
                        updated_count += 1
                else:
                    # 正常模式：ON CONFLICT DO UPDATE SET updated_at（仅更新时间戳）
                    insert_query = pg_sql.SQL("INSERT INTO {} ({}) VALUES ({}) ON CONFLICT (identifier) DO UPDATE SET updated_at = CURRENT_TIMESTAMP").format(
                        pg_sql.Identifier(self.table_name),
                        pg_sql.SQL(', ').join(columns),
                        pg_sql.SQL(', ').join(pg_sql.Placeholder() * len(keys))
                    )
                
                self.cursor.execute(insert_query, values)
                success_count += 1

                if has_identifier:
                    new_identifier = str(record.get('identifier', '')).strip()
                    if new_identifier:
                        existing_identifiers.add(new_identifier)

            except Exception as e:
                failed_count += 1
                error_info = {
                    "row_index": idx,
                    "error": str(e),
                    "data_preview": {k: str(v)[:50] for k, v in list(record.items())[:3]}
                }
                errors.append(error_info)
                self.error_records.append(error_info)

        self.connection.commit()
        self.uploaded_count = success_count

        result = {
            "success": success_count,
            "failed": failed_count,
            "total": len(data),
            "skipped_duplicates": skipped_duplicates,
            "table_name": self.table_name,
            "errors": errors,
            "force_mode": self.force_mode
        }

        # 强制模式下额外返回更新的记录数
        if self.force_mode:
            result["updated_count"] = updated_count

        # 打印结果信息
        if self.force_mode:
            print(f"[PostgreSQL] ✅ 强制导入完成: 成功 {success_count} (其中更新 {updated_count}), 失败 {failed_count}")
        elif skipped_duplicates > 0 or success_count > 0:
            print(f"[PostgreSQL] 上传完成: 新增 {success_count}, 跳过重复 {skipped_duplicates}, 失败 {failed_count}")

        return result

    def get_table_info(self) -> Dict[str, Any]:
        """获取表结构信息"""
        self.cursor.execute("""
            SELECT column_name, data_type, is_nullable, column_default 
            FROM information_schema.columns 
            WHERE table_name = %s AND table_schema = 'public'
            ORDER BY ordinal_position
        """, (self.table_name,))
        
        columns = []
        for row in self.cursor.fetchall():
            columns.append({
                "name": row['column_name'],
                "type": row['data_type'],
                "nullable": row['is_nullable'],
                "default": row['column_default']
            })

        self.cursor.execute(f"SELECT COUNT(*) FROM {self.table_name}")
        total_rows = self.cursor.fetchone()['count']

        return {
            "table_name": self.table_name,
            "total_rows": total_rows,
            "columns": columns
        }

    def test_connection(self) -> bool:
        """测试连接是否正常"""
        try:
            self.connect()
            self.cursor.execute("SELECT version()")
            version = self.cursor.fetchone()
            print(f"[PostgreSQL] 连接测试成功: {version[0][:50]}...")
            return True
        except Exception as e:
            print(f"[PostgreSQL] 连接测试失败: {e}")
            return False
        finally:
            self.disconnect()
