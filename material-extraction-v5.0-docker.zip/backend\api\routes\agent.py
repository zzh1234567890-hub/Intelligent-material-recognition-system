"""
Agent API 路由

提供 LangGraph Agent 的 RESTful 接口，
支持完整工作流和分步执行两种模式。
"""

from fastapi import APIRouter, UploadFile, File, HTTPException, Query
from typing import Optional, List
from pydantic import BaseModel

router = APIRouter(prefix="/api/agent", tags=["Agent 智能处理"])


class AgentRequest(BaseModel):
    """Agent 处理请求模型"""
    user_input: str
    session_id: Optional[str] = None


class AgentResponse(BaseModel):
    """Agent 响应模型"""
    status: str
    message: str
    session_id: str
    final_response: Optional[str] = None
    summary: Optional[dict] = None


@router.post("/process", response_model=AgentResponse)
async def process_with_agent(
    user_input: str = Query(..., description="用户自然语言输入"),
    files: List[UploadFile] = File(default=[], description="上传的文件列表")
):
    """
    使用 Agent 完整流程处理文档
    
    一键式接口：自动完成「意图分析 → 任务规划 → 工具执行 → 结果汇总」
    
    - **user_input**: 用户需求描述（如"提取材料数据并上传到数据库"）
    - **files**: 可选的文档文件（PDF/Word/Markdown）
    
    返回：
    - 最终处理结果和会话信息
    """
    from backend.agents.graph import IntelligentCrawlerAgent
    
    try:
        # 准备文件列表
        file_paths = []
        for file in files:
            if file.filename:
                content = await file.read()
                import os
                import tempfile
                
                ext = os.path.splitext(file.filename)[1]
                temp_file = tempfile.NamedTemporaryFile(
                    delete=False,
                    suffix=ext,
                    dir="./uploads"
                )
                temp_file.write(content)
                temp_file.close()
                
                file_paths.append(temp_file.name)
        
        # 创建并运行 Agent
        agent = IntelligentCrawlerAgent()
        
        result = agent.process(
            user_input=user_input,
            files=file_paths if file_paths else None
        )
        
        return AgentResponse(
            status=result.get("status", "unknown"),
            message="处理完成",
            session_id=result.get("session_id", ""),
            final_response=result.get("final_response"),
            summary={
                "extracted_count": len(result.get("extracted_data", [])),
                "has_excel": bool(result.get("excel_path")),
                "mysql_uploaded": bool(result.get("mysql_result")),
                "error": bool(result.get("error_info"))
            }
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Agent 处理失败: {str(e)}")


@router.post("/session/create")
async def create_session(request: AgentRequest):
    """创建新的 Agent 会话"""
    from backend.agents.graph import IntelligentCrawlerAgent
    
    try:
        agent = IntelligentCrawlerAgent()
        session_id = agent.create_session(
            user_input=request.user_input
        )
        
        return {
            "status": "success",
            "message": "会话已创建",
            "session_id": session_id
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/session/{session_id}/step/intent")
async def analyze_intent_step(session_id: str):
    """执行意图分析步骤"""
    from backend.agents.graph import IntelligentCrawlerAgent
    
    try:
        agent = IntelligentCrawlerAgent()
        result = agent.analyze_intent(session_id)
        
        return {
            "status": "completed",
            "step": "intent_analysis",
            "intent": result.get("user_intent")
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/session/{session_id}/step/plan")
async def plan_tasks_step(session_id: str):
    """执行任务规划步骤"""
    from backend.agents.graph import IntelligentCrawlerAgent
    
    try:
        agent = IntelligentCrawlerAgent()
        result = agent.plan_tasks(session_id)
        
        return {
            "status": "completed",
            "step": "task_planning",
            "plan": result.get("task_plan"),
            "total_steps": result.get("total_steps")
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/session/{session_id}/step/execute")
async def execute_tools_step(session_id: str):
    """执行工具调用步骤"""
    from backend.agents.graph import IntelligentCrawlerAgent
    
    try:
        agent = IntelligentCrawlerAgent()
        result = agent.execute_tools(session_id)
        
        return {
            "status": "completed",
            "step": "tools_execution",
            "tool_results": {
                k: {"status": v["status"], "has_error": bool(v.get("error"))}
                for k, v in result.get("tool_results", {}).items()
            },
            "extracted_count": len(result.get("extracted_data", [])),
            "has_excel": bool(result.get("excel_path")),
            "mysql_uploaded": bool(result.get("mysql_result"))
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/session/{session_id}/step/summary")
async def summarize_step(session_id: str):
    """执行结果汇总步骤"""
    from backend.agents.graph import IntelligentCrawlerAgent
    
    try:
        agent = IntelligentCrawlerAgent()
        result = agent.summarize_results(session_id)
        
        return {
            "status": "completed",
            "step": "result_summary",
            "final_response": result.get("final_response"),
            "overall_status": result.get("status")
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/session/{session_id}/status")
async def get_session_status(session_id: str):
    """获取会话状态"""
    from backend.agents.graph import IntelligentCrawlerAgent
    
    try:
        agent = IntelligentCrawlerAgent()
        status = agent.get_session_status(session_id)
        
        return {
            "status": "success",
            "session_id": session_id,
            "data": status
        }
        
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/session/{session_id}/result")
async def get_session_result(session_id: str):
    """获取会话完整结果"""
    from backend.agents.graph import IntelligentCrawlerAgent
    
    try:
        agent = IntelligentCrawlerAgent()
        result = agent.get_session_result(session_id)
        
        return {
            "status": "success",
            "session_id": session_id,
            "data": dict(result)
        }
        
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
