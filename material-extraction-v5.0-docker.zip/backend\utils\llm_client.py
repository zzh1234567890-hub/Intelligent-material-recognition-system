"""
DeepSeek LLM 客户端封装
支持 deepseek-v4flash 模型
"""

import httpx
from typing import Optional, List, Dict, Any
from pydantic import BaseModel


class Message(BaseModel):
    """消息模型"""
    role: str  # system, user, assistant
    content: str


class ChatCompletionRequest(BaseModel):
    """聊天完成请求模型"""
    messages: List[Message]
    model: str = "deepseek-v4flash"
    temperature: float = 0.3
    max_tokens: int = 4096
    stream: bool = False


class ChatCompletionChoice(BaseModel):
    """聊天完成选项模型"""
    index: int
    message: Message
    finish_reason: str


class Usage(BaseModel):
    """使用量统计模型"""
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0


class ChatCompletionResponse(BaseModel):
    """聊天完成响应模型"""
    id: str = ""
    object: str = "chat.completion"
    created: int = 0
    model: str = ""
    choices: List[ChatCompletionChoice] = []
    usage: Usage = Usage()


class DeepSeekClient:
    """
    DeepSeek API 客户端
    
    封装了与 DeepSeek v4flash 模型的交互逻辑，
    提供统一的接口供 get_data 等工具调用。
    
    使用示例：
        client = DeepSeekClient(
            api_key="your-key",
            model="deepseek-v4flash"
        )
        
        response = client.generate(
            messages=[
                {"role": "user", "content": "Hello"}
            ],
            temperature=0.3
        )
        
        print(response.choices[0].message.content)
    """
    
    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.deepseek.com/v1/chat/completions",
        model: str = "deepseek-v4-flash",
        timeout: float = 180.0  # 增加到3分钟，适应大文件处理
    ):
        self.api_key = api_key
        self.base_url = base_url
        self.model = model
        self.timeout = timeout
        
        self._client = httpx.Client(timeout=timeout)
        
        if not api_key:
            raise ValueError("API Key 不能为空")
    
    def generate(
        self,
        messages: List[Dict[str, str]],
        temperature: float = 0.3,
        max_tokens: int = 4096,
        **kwargs
    ) -> ChatCompletionResponse:
        """
        调用 DeepSeek API 生成响应
        
        Args:
            messages: 消息列表，格式 [{"role": "user/assistant/system", "content": "..."}]
            temperature: 温度参数（0-2），越高越随机，默认 0.3（较确定）
            max_tokens: 最大生成 token 数
            **kwargs: 其他可选参数
            
        Returns:
            ChatCompletionResponse: 包含生成的文本内容
            
        Raises:
            Exception: API 调用失败时抛出异常
        """
        try:
            request_data = {
                "model": self.model,
                "messages": messages,
                "temperature": temperature,
                "max_tokens": max_tokens,
                **kwargs
            }
            
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            }
            
            response = self._client.post(
                self.base_url,
                json=request_data,
                headers=headers
            )
            
            response.raise_for_status()
            
            data = response.json()
            
            usage = data.get("usage", {})
            if usage:
                print(f"[DeepSeek] Token用量: prompt={usage.get('prompt_tokens',0)}, "
                      f"completion={usage.get('completion_tokens',0)}, "
                      f"total={usage.get('total_tokens',0)}")
            
            return self._parse_response(data)
            
        except httpx.HTTPStatusError as e:
            error_detail = e.response.text if e.response else str(e)
            raise Exception(f"DeepSeek API HTTP 错误 {e.response.status_code}: {error_detail}")
        except httpx.RequestError as e:
            raise Exception(f"DeepSeek API 请求错误: {str(e)}")
        except Exception as e:
            raise Exception(f"DeepSeek API 调用失败: {str(e)}")
    
    def _parse_response(self, data: Dict[str, Any]) -> ChatCompletionResponse:
        """解析 API 响应数据"""
        choices = []
        for choice in data.get("choices", []):
            message_data = choice.get("message", {})
            choice_obj = ChatCompletionChoice(
                index=choice.get("index", 0),
                message=Message(
                    role=message_data.get("role", "assistant"),
                    content=message_data.get("content", "")
                ),
                finish_reason=choice.get("finish_reason", "stop")
            )
            choices.append(choice_obj)
        
        usage_data = data.get("usage", {})
        usage = Usage(
            prompt_tokens=usage_data.get("prompt_tokens", 0),
            completion_tokens=usage_data.get("completion_tokens", 0),
            total_tokens=usage_data.get("total_tokens", 0)
        )
        
        return ChatCompletionResponse(
            id=data.get("id", ""),
            object=data.get("object", "chat.completion"),
            created=data.get("created", 0),
            model=data.get("model", self.model),
            choices=choices,
            usage=usage
        )
    
    async def generate_async(
        self,
        messages: List[Dict[str, str]],
        temperature: float = 0.3,
        max_tokens: int = 4096,
        **kwargs
    ) -> ChatCompletionResponse:
        """
        异步调用 DeepSeek API（用于 FastAPI 异步环境）
        
        参数同 generate() 方法
        """
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                request_data = {
                    "model": self.model,
                    "messages": messages,
                    "temperature": temperature,
                    "max_tokens": max_tokens,
                    **kwargs
                }
                
                headers = {
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json"
                }
                
                response = await client.post(
                    self.base_url,
                    json=request_data,
                    headers=headers
                )
                
                response.raise_for_status()
                
                data = response.json()
                return self._parse_response(data)
                
        except Exception as e:
            raise Exception(f"DeepSeek 异步 API 调用失败: {str(e)}")
    
    def test_connection(self) -> bool:
        """测试 API 连接是否正常"""
        try:
            response = self.generate(
                messages=[{"role": "user", "content": "Hi"}],
                max_tokens=10
            )
            return len(response.choices) > 0
        except Exception:
            return False
    
    def close(self):
        """关闭 HTTP 客户端"""
        if self._client and not self._client.is_closed:
            self._client.close()


def create_deepseek_client() -> DeepSeekClient:
    """
    工厂函数：根据配置创建 DeepSeek 客户端
    
    从 config.py 中读取配置信息并实例化客户端
    
    Returns:
        DeepSeekClient: 配置好的客户端实例
        
    Raises:
        ValueError: 如果未配置 API Key
    """
    from backend.config import get_settings
    
    settings = get_settings()
    
    if not settings.DEEPSEEK_API_KEY:
        raise ValueError(
            "未配置 DEEPSEEK_API_KEY！"
            "\n请在 .env 文件中设置：DEEPSEEK_API_KEY=your_api_key"
        )
    
    return DeepSeekClient(
        api_key=settings.DEEPSEEK_API_KEY,
        base_url=settings.DEEPSEEK_API_URL,
        model=settings.DEEPSEEK_MODEL
    )
