import io
import re
from typing import Optional, List, Tuple
from concurrent.futures import ThreadPoolExecutor, as_completed
from PyPDF2 import PdfReader
from docx import Document as DocxDocument

try:
    import pdfplumber
    HAS_PDFPLUMBER = True
except ImportError:
    HAS_PDFPLUMBER = False

try:
    import pytesseract
    from PIL import Image
    HAS_OCR = True
    import os
    _tesseract_path = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
    if os.path.exists(_tesseract_path):
        pytesseract.pytesseract.tesseract_cmd = _tesseract_path
        print(f"[OCR] Tesseract found: {_tesseract_path}")
    else:
        HAS_OCR = False
        print(f"[WARN] Tesseract not found at {_tesseract_path}, OCR disabled")
except ImportError:
    HAS_OCR = False


class everything_read:
    description = "解析文档内容相关工具"

    SUPPORTED_TYPES = {
        ".pdf": "pdf",
        ".docx": "docx",
        ".doc": "docx",
        ".md": "markdown",
        ".markdown": "markdown",
    }

    def __init__(self):
        self.document = None
        self.content = ""
        self.file_type = None
        self.file_name = ""

    def _detect_type(self, file_name: str) -> Optional[str]:
        file_name_lower = file_name.lower()
        for ext, doc_type in self.SUPPORTED_TYPES.items():
            if file_name_lower.endswith(ext):
                return doc_type
        return None

    def read(self, document) -> str:
        self.document = document
        self.file_name = getattr(document, "filename", None) or getattr(document, "name", "unknown")
        self.file_type = self._detect_type(self.file_name)

        if self.file_type is None:
            raise ValueError(
                f"不支持的文件类型: {self.file_name}，"
                f"当前支持: {list(self.SUPPORTED_TYPES.keys())}"
            )

        raw_bytes = document.read()

        if self.file_type == "pdf":
            self.content = self._read_pdf(raw_bytes)
        elif self.file_type == "docx":
            self.content = self._read_docx(raw_bytes)
        elif self.file_type == "markdown":
            self.content = self._read_markdown(raw_bytes)
        else:
            raise ValueError(f"未知的文件类型: {self.file_type}")

        return self.content

    def read_pdf(self, document) -> str:
        self.document = document
        self.file_name = getattr(document, "filename", None) or getattr(document, "name", "unknown")
        raw_bytes = document.read()
        self.content = self._read_pdf(raw_bytes)
        self.file_type = "pdf"
        return self.content

    def _read_pdf(self, raw_bytes: bytes) -> str:
        if HAS_PDFPLUMBER:
            try:
                return self._read_pdf_hybrid(raw_bytes)
            except Exception as e:
                print(f"[WARN] pdfplumber 解析失败，回退到 PyPDF2: {e}")

        pdf_file = io.BytesIO(raw_bytes)
        reader = PdfReader(pdf_file)
        text_parts = []
        for page in reader.pages:
            page_text = page.extract_text()
            if page_text:
                text_parts.append(page_text)

        if text_parts and sum(len(t.strip()) for t in text_parts) > 100:
            return "\n".join(text_parts)

        if HAS_OCR:
            try:
                return self._read_pdf_ocr(raw_bytes)
            except Exception as e:
                print(f"[WARN] OCR 解析失败: {e}")

        return "\n".join(text_parts)

    # ──────────────────────────────────────────────
    #  Domain-specific Qwen-VL prompt for table extraction
    # ──────────────────────────────────────────────
    _QWEN_TABLE_EXTRACTION_PROMPT = (
        "You are an expert in extracting tabular data from academic papers about concrete, "
        "high-temperature experiments, fiber-reinforced composites, and mechanical testing.\n\n"
        "Extract ALL content from this PDF page. Follow these rules strictly:\n\n"
        "## TEXT CONTENT\n"
        "- Output all running text first, preserving paragraph structure.\n"
        "- Preserve ALL numeric values exactly as they appear (no rounding, no approximation).\n"
        "- Preserve ALL units: MPa, GPa, mm, kg/m³, %, °C, μm, g/cm³, kN, N, etc.\n"
        "- Pay special attention to superscripts/subscripts: kg/m³ not kg/m3, °C not C.\n\n"
        "## TABLE DETECTION & EXTRACTION\n"
        "- If this page contains ANY data table(s), extract each one as a Markdown table.\n"
        "- Use this exact format for every table:\n"
        "  [Table N: table_caption_or_title]\n"
        "  | Column1 | Column2 | Column3 |\n"
        "  |---------|---------|---------|\n"
        "  | value1  | value2  | value3  |\n"
        "- Do NOT skip any rows or columns — even partially empty ones.\n"
        "- If a cell appears to span multiple columns, repeat its value in each column.\n"
        "- If a cell is genuinely empty, leave it blank (||).\n"
        "- Preserve ALL numeric precision: \"34.1\" stays \"34.1\", \"0.045\" stays \"0.045\".\n\n"
        "## HORIZONTAL TABLE TRANSPOSITION (CRITICAL!)\n"
        "- If the table is arranged HORIZONTALLY (each COLUMN = one mixture/specimen, each ROW = one property):\n"
        "  TRANSPOSE it so each mixture becomes one ROW and each property becomes one COLUMN.\n"
        "  Example — if you see:\n"
        "    Mixture    M0    M1    M2\n"
        "    Cement     350   400   400\n"
        "    w/c ratio  0.45  0.30  0.30\n"
        "  Output as:\n"
        "    | Mixture | Cement (kg/m³) | w/c ratio |\n"
        "    |---------|---------------|-----------|\n"
        "    | M0      | 350           | 0.45      |\n"
        "    | M1      | 400           | 0.30      |\n"
        "    | M2      | 400           | 0.30      |\n\n"
        "## DOMAIN-SPECIFIC GUIDANCE\n"
        "- Mix proportion tables: look for Cement/OPC, Silica fume/SF, Fly ash/FA, Slag/GGBS, "
        "Water, w/b or w/c ratio, Superplasticizer/SP/HRWRA, aggregates, fibers.\n"
        "- Fiber property tables: look for fiber type, length (mm), diameter (μm or mm), "
        "tensile strength (MPa), elastic modulus (GPa), density (g/cm³), melting point (°C).\n"
        "- Strength/test result tables: compressive strength (MPa), splitting tensile (MPa), "
        "flexural strength (MPa), elastic modulus (GPa), residual strength ratio (%), mass loss (%).\n"
        "- Heating protocol tables: target temperature (°C), heating rate (°C/min), "
        "duration (min or h), fire curve standard (ISO 834, ASTM E119, RABT, HC).\n\n"
        "## OUTPUT FORMAT\n"
        "- If the page HAS tables: output text first, then each table in Markdown format.\n"
        "- If the page has NO tables: output only the text content.\n"
        "- Do NOT add commentary like \"This page contains a table...\" — just output the data.\n"
        "- Label each table with its table number and caption: [Table 2: Mix proportions (kg/m³)]"
    )

    def _read_pdf_hybrid(self, raw_bytes: bytes) -> str:
        """
        Single-pass hybrid PDF parsing (optimized):
        1. pdfplumber extracts text from all pages
        2. Keyword pre-filter identifies candidate table pages (wider patterns)
        3. Qwen-VL does ONE call per candidate page: detects + extracts tables
           at high resolution (scale=2.0, quality=80) in parallel (max 5 workers)
        4. pdfplumber fallback for pages Qwen couldn't handle
        5. Non-candidate pages use pdfplumber text as-is
        """
        import time as _time
        _t0 = _time.monotonic()

        pdf_file = io.BytesIO(raw_bytes)
        all_content = []

        with pdfplumber.open(pdf_file) as pdf:
            total_pages = len(pdf.pages)
            for page_num, page in enumerate(pdf.pages):
                text = page.extract_text() or ""
                all_content.append({
                    "page_num": page_num,
                    "text": text,
                })

        print(f"[PDF] pdfplumber text extracted: {total_pages} pages ({_time.monotonic() - _t0:.1f}s)")

        # ── Step 1: Wider pre-filter ──
        candidate_pages = self._pre_filter_table_pages(all_content)
        print(f"[PDF] Keyword pre-filter: {len(candidate_pages)}/{total_pages} candidate table pages")

        # ── Step 2: Single-pass Qwen-VL extraction (detection + recognition merged) ──
        qwen_client = self._create_qwen_client()
        qwen_results = {}

        if qwen_client and candidate_pages:
            print(f"[PDF] Qwen-VL single-pass extraction on {len(candidate_pages)} pages (parallel)...")
            _t_qwen_start = _time.monotonic()
            qwen_results = self._extract_pages_with_qwen(
                qwen_client, raw_bytes, candidate_pages
            )
            _t_qwen = _time.monotonic() - _t_qwen_start
            print(f"[PDF] Qwen-VL extraction done: {len(qwen_results)}/{len(candidate_pages)} pages ({_t_qwen:.1f}s)")
        elif not qwen_client:
            print("[PDF] Qwen-VL unavailable, using pdfplumber fallback")
            qwen_results = self._extract_tables_with_pdfplumber(
                raw_bytes, candidate_pages
            )

        qwen_success = set(qwen_results.keys())
        fallback_pages = [p for p in candidate_pages if p not in qwen_success]

        # ── Step 3: pdfplumber fallback for missed pages ──
        fallback_texts = {}
        if fallback_pages:
            print(f"[PDF] {len(fallback_pages)} pages not covered by Qwen, pdfplumber fallback")
            fallback_texts = self._extract_tables_with_pdfplumber(
                raw_bytes, fallback_pages
            )

        # ── Step 4: Assemble final output ──
        result_parts = []
        for page_info in all_content:
            page_num = page_info["page_num"]
            text = page_info["text"]

            page_parts = [f"\n=== Page {page_num + 1} ==="]

            if page_num in qwen_success:
                page_parts.append(qwen_results[page_num])
            elif page_num in fallback_texts:
                page_parts.append(fallback_texts[page_num])
            elif text:
                page_parts.append(text)

            result_parts.append("\n".join(page_parts))

        result = "\n\n".join(result_parts)
        _t_total = _time.monotonic() - _t0
        print(f"[PDF ⏱] Hybrid done: {len(result)} chars ({_t_total:.1f}s total) "
              f"(text {total_pages - len(candidate_pages)}p + Qwen-VL {len(qwen_success)}p + "
              f"pdfplumber {len(fallback_texts)}p)")

        return result

    def _pre_filter_table_pages(self, all_content: list) -> List[int]:
        """
        Pre-filter: use strong signals + domain keywords to find table-containing pages.

        Matches:
        - Explicit table labels: Table 1, Table 2.1, Tab. 3
        - Domain-specific headers common in concrete research tables:
          Mix/Mixture, Cement, w/b, w/c, Compressive, Tensile, Fiber, etc.
        - Any page where the NUMBER of numeric tokens suggests a table
        """
        candidate_pages = []
        table_label_patterns = [
            r'\bTable\s+\d+',
            r'\bTable\s+\d+[\.-]\d+',
            r'\bTab\.\s*\d+',
            r'\bTab\s+\d+',
        ]
        # Domain headers that strongly suggest a data table
        domain_table_signals = [
            r'\b(Mix|Mixture|Mix ID|Mix code|Specimen|Sample)\b',
            r'\b(Cement|OPC|Silica\s*fume|Fly\s*ash|Slag|GGBS|Metakaolin)\b',
            r'\b(w/b|w/c|water.binder|water.cement|W/B|W/C)\b',
            r'\b(Compressive|Tensile|Flexural|Splitting)\s+(strength|Strength)\b',
            r'\b(Elastic\s*modulus|Modulus\s*of\s*elasticity)\b',
            r'\b(Fiber|Fibre|Steel\s*fiber|PP\s*fiber|PE\s*fiber|PVA\s*fiber)\b',
            r'\b(Temperature|Heating|Target\s*temp|Fire\s*curve)\b',
            r'\b(kg/m3|kg/m³|MPa|GPa|°C|%\s*vol|vol\s*%)\b',
            r'\b(Residual|Retained|Normalized)\b',
            r'\b(Spalling|Explosive|Surface)\b',
            r'\b(Mean|Average|Std|Standard\s*deviation|COV)\b',
        ]

        for page_info in all_content:
            page_num = page_info["page_num"]
            text = page_info["text"]

            # Check for explicit table labels
            has_label = any(
                re.search(p, text, re.IGNORECASE)
                for p in table_label_patterns
            )

            # Check for domain-specific table signals
            signal_count = sum(
                1 for p in domain_table_signals
                if re.search(p, text, re.IGNORECASE)
            )

            # High signal density = likely a table page even without explicit label
            has_strong_signals = signal_count >= 3

            if has_label or has_strong_signals:
                candidate_pages.append(page_num)

        return sorted(set(candidate_pages))

    def _create_qwen_client(self):
        try:
            from backend.utils.multimodal_client import create_qwen_vl_client
            client = create_qwen_vl_client()
            return client
        except Exception as e:
            print(f"[Qwen-VL] client creation failed: {e}")
            return None

    def _extract_pages_with_qwen(
        self, client, raw_bytes: bytes, page_indices: List[int]
    ) -> dict:
        """
        Single-pass Qwen-VL extraction: render at high-res (scale=2.0, quality=90),
        send the domain-specific prompt, and parse the result.

        This REPLACES the old two-pass (detection + recognition) — one API call per page.
        """
        page_images = {}
        for pn in page_indices:
            img = self._render_page_to_image(
                raw_bytes, pn, scale=2.0, fmt="jpeg", quality=80
            )
            if img:
                page_images[pn] = img
            else:
                print(f"[Qwen-VL] Page {pn + 1} render failed, skip")

        if not page_images:
            return {}

        prompt = self._QWEN_TABLE_EXTRACTION_PROMPT

        def extract_page(page_num, img_bytes):
            _t_page_start = _time.monotonic()
            print(f"[Qwen-VL] Extracting Page {page_num + 1}...")
            try:
                result = client.analyze_image(
                    image_bytes=img_bytes,
                    prompt=prompt,
                    max_tokens=8192,
                    temperature=0.0,
                )
                _t_page = _time.monotonic() - _t_page_start
                if result and len(result.strip()) > 50:
                    has_table = "[Table" in result or "| --" in result or "|---|---" in result
                    tag = "[TABLE]" if has_table else "[text]"
                    print(f"[Qwen-VL ⏱] Page {page_num + 1}: {len(result)} chars {tag} ({_t_page:.1f}s)")
                    return page_num, result
                else:
                    print(f"[Qwen-VL ⏱] Page {page_num + 1}: result too short ({_t_page:.1f}s), skip")
                    return page_num, None
            except Exception as e:
                _t_page = _time.monotonic() - _t_page_start
                print(f"[Qwen-VL ⏱] Page {page_num + 1} extraction failed ({_t_page:.1f}s): {e}")
                return page_num, None

        result = {}
        max_workers = min(5, len(page_images))

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = {
                executor.submit(extract_page, pn, img): pn
                for pn, img in page_images.items()
            }
            for future in as_completed(futures):
                page_num, qwen_result = future.result()
                if qwen_result:
                    result[page_num] = qwen_result

        return result

    def _extract_tables_with_pdfplumber(
        self, raw_bytes: bytes, page_indices: List[int]
    ) -> dict:
        result = {}
        # Multiple extraction strategies to try, from most precise to most aggressive
        extraction_strategies = [
            # Strategy 1: line-based (works well for bordered tables)
            {
                "vertical_strategy": "lines",
                "horizontal_strategy": "lines",
                "snap_tolerance": 4,
                "join_tolerance": 3,
                "edge_min_length": 3,
            },
            # Strategy 2: lines + text hybrid (for tables with partial borders)
            {
                "vertical_strategy": "lines",
                "horizontal_strategy": "text",
                "snap_tolerance": 6,
                "join_tolerance": 4,
                "edge_min_length": 2,
            },
            # Strategy 3: text-based (for borderless tables)
            {
                "vertical_strategy": "text",
                "horizontal_strategy": "text",
                "snap_tolerance": 8,
                "join_tolerance": 5,
                "text_tolerance": 3,
            },
            # Strategy 4: aggressive text (for dense data tables with no borders)
            {
                "vertical_strategy": "text",
                "horizontal_strategy": "text",
                "snap_tolerance": 12,
                "join_tolerance": 6,
                "text_tolerance": 5,
                "intersection_tolerance": 3,
            },
        ]

        try:
            import pdfplumber
            pdf_file = io.BytesIO(raw_bytes)
            with pdfplumber.open(pdf_file) as pdf:
                for page_num in page_indices:
                    if page_num >= len(pdf.pages):
                        continue
                    page = pdf.pages[page_num]
                    text = page.extract_text() or ""

                    all_tables = []
                    for strategy in extraction_strategies:
                        try:
                            tables = page.extract_tables(table_settings=strategy)
                            if tables:
                                valid = [t for t in tables if t and len(t) >= 2]
                                if valid:
                                    all_tables.extend(valid)
                                    break  # Stop at first successful strategy
                        except Exception:
                            continue

                    # Deduplicate tables (same first row + same row count)
                    seen = set()
                    unique_tables = []
                    for table in all_tables:
                        key = (str(table[0]), len(table))
                        if key not in seen:
                            seen.add(key)
                            unique_tables.append(table)

                    page_parts = []
                    if text:
                        page_parts.append(text)

                    table_idx = 0
                    for table in unique_tables:
                        cleaned = self._clean_table(table)
                        if cleaned and len(cleaned) >= 2:
                            table_idx += 1
                            formatted = self._format_table_markdown(
                                cleaned, table_idx
                            )
                            if formatted:
                                page_parts.append(formatted)

                    combined = "\n".join(page_parts)
                    if combined.strip():
                        result[page_num] = combined

        except Exception as e:
            print(f"[PDF] pdfplumber fallback failed: {e}")

        return result

    @staticmethod
    def _clean_table(table: list) -> list:
        cleaned = []
        for row in table:
            cleaned_row = []
            for cell in row:
                if cell is None:
                    cleaned_row.append("")
                else:
                    cell_str = str(cell).strip()
                    cell_str = re.sub(r'\s+', ' ', cell_str)
                    cleaned_row.append(cell_str)
            if any(c for c in cleaned_row):
                cleaned.append(cleaned_row)
        return cleaned

    @staticmethod
    def _format_table_markdown(table: list, table_idx: int, merged_note: str = "") -> str:
        if not table or len(table) < 2:
            return ""

        lines = [f"\n[Table {table_idx}{merged_note}]"]

        header = table[0]
        header_parts = [str(cell or "").strip() for cell in header]
        lines.append("| " + " | ".join(header_parts) + " |")
        lines.append("| " + " | ".join(["---"] * len(header_parts)) + " |")

        for row in table[1:]:
            row_parts = [str(cell or "").strip() for cell in row]
            if any(c for c in row_parts):
                lines.append("| " + " | ".join(row_parts) + " |")

        return "\n".join(lines)

    def _render_page_to_image(
        self,
        raw_bytes: bytes,
        page_num: int,
        scale: float = 2.0,
        fmt: str = "png",
        quality: int = 85,
    ) -> Optional[bytes]:
        """
        Render PDF page to image

        Args:
            raw_bytes: PDF raw bytes
            page_num: page index (0-based)
            scale: zoom factor (1.0=72dpi, 2.0=144dpi, 1.5=108dpi)
            fmt: "png" or "jpeg"
            quality: JPEG quality (1-100), ignored for PNG
        """
        try:
            import fitz
            doc = fitz.open(stream=raw_bytes, filetype="pdf")
            page = doc[page_num]
            mat = fitz.Matrix(scale, scale)
            pix = page.get_pixmap(matrix=mat)
            if fmt == "jpeg":
                buf = io.BytesIO()
                pix.save(buf, format="jpeg", jpeg_quality=quality)
                img_data = buf.getvalue()
            else:
                img_data = pix.tobytes("png")
            doc.close()
            return img_data
        except ImportError:
            pass

        try:
            import pdfplumber
            resolution = int(72 * scale)
            pdf_file = io.BytesIO(raw_bytes)
            with pdfplumber.open(pdf_file) as pdf:
                page = pdf.pages[page_num]
                img = page.to_image(resolution=resolution)
                pil_img = img.original
                buf = io.BytesIO()
                if fmt == "jpeg":
                    pil_img.save(buf, format="JPEG", quality=quality)
                else:
                    pil_img.save(buf, format="PNG")
                return buf.getvalue()
        except Exception as e:
            print(f"[PDF] Page {page_num + 1} render failed: {e}")

        return None

    def _read_pdf_ocr(self, raw_bytes: bytes) -> str:
        if not HAS_OCR:
            raise ImportError("pytesseract not installed")

        pdf_file = io.BytesIO(raw_bytes)
        all_text = []

        if HAS_PDFPLUMBER:
            with pdfplumber.open(pdf_file) as pdf:
                for page_num, page in enumerate(pdf.pages):
                    text = page.extract_text()
                    if text and len(text.strip()) > 50:
                        all_text.append(f"\n=== Page {page_num + 1} ===\n{text}")
                        continue

                    try:
                        img = page.to_image(resolution=300)
                        pil_img = img.original
                        ocr_text = pytesseract.image_to_string(pil_img, lang='eng')
                        if ocr_text.strip():
                            all_text.append(f"\n=== Page {page_num + 1} (OCR) ===\n{ocr_text}")
                    except Exception as e:
                        print(f"[WARN] Page {page_num + 1} OCR failed: {e}")
        else:
            reader = PdfReader(io.BytesIO(raw_bytes))
            for page_num, page in enumerate(reader.pages):
                text = page.extract_text()
                if text and len(text.strip()) > 50:
                    all_text.append(f"\n=== Page {page_num + 1} ===\n{text}")
                    continue

                try:
                    if hasattr(page, 'images') and page.images:
                        for img_info in page.images:
                            pil_img = Image.open(io.BytesIO(img_info.data))
                            ocr_text = pytesseract.image_to_string(pil_img, lang='eng')
                            if ocr_text.strip():
                                all_text.append(f"\n=== Page {page_num + 1} (OCR) ===\n{ocr_text}")
                                break
                except Exception as e:
                    print(f"[WARN] Page {page_num + 1} OCR failed: {e}")

        print(f"[PDF] OCR fallback: {len(all_text)} pages extracted")
        return "\n\n".join(all_text)

    def read_docx(self, document) -> str:
        self.document = document
        self.file_name = getattr(document, "filename", None) or getattr(document, "name", "unknown")
        raw_bytes = document.read()
        self.content = self._read_docx(raw_bytes)
        self.file_type = "docx"
        return self.content

    def _read_docx(self, raw_bytes: bytes) -> str:
        docx_file = io.BytesIO(raw_bytes)
        doc = DocxDocument(docx_file)
        text_parts = []
        for paragraph in doc.paragraphs:
            if paragraph.text.strip():
                text_parts.append(paragraph.text)
        return "\n".join(text_parts)

    def read_markdown(self, document) -> str:
        self.document = document
        self.file_name = getattr(document, "filename", None) or getattr(document, "name", "unknown")
        raw_bytes = document.read()
        self.content = self._read_markdown(raw_bytes)
        self.file_type = "markdown"
        return self.content

    def _read_markdown(self, raw_bytes: bytes) -> str:
        return raw_bytes.decode("utf-8")

    def get_content(self) -> str:
        return self.content

    def get_file_type(self) -> Optional[str]:
        return self.file_type

    def get_file_name(self) -> str:
        return self.file_name
