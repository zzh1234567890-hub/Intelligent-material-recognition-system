-- ============================================================
-- 在 postgres 数据库中创建 material_data 表
-- 执行方式: 在 PostgreSQL 工具中连接到 postgres 数据库后执行
-- ============================================================

-- 先检查当前数据库
SELECT current_database() AS "当前数据库";

-- 创建 material_data 表（如果不存在）
CREATE TABLE IF NOT EXISTS material_data (
    -- 主键
    id SERIAL PRIMARY KEY,
    
    -- 核心字段
    identifier VARCHAR(100) NOT NULL DEFAULT '' UNIQUE,
    type VARCHAR(50) NOT NULL DEFAULT '',
    title TEXT,
    authors TEXT,
    journal VARCHAR(200) DEFAULT '',
    volume VARCHAR(20) DEFAULT '',
    issue VARCHAR(20) DEFAULT '',
    pages VARCHAR(50) DEFAULT '',
    year CHAR(4) DEFAULT '',
    publisher VARCHAR(200) DEFAULT '',
    doi VARCHAR(200) DEFAULT '',
    abstract TEXT,
    
    -- 系统字段
    source_file VARCHAR(500) DEFAULT '',
    uploaded_by VARCHAR(100),
    session_id VARCHAR(100),
    
    -- 时间戳
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 创建索引
CREATE INDEX IF NOT EXISTS idx_type ON material_data(type);
CREATE INDEX IF NOT EXISTS idx_year ON material_data(year);
CREATE INDEX IF NOT EXISTS idx_journal ON material_data(journal);
CREATE INDEX IF NOT EXISTS idx_created_at ON material_data(created_at);
CREATE INDEX IF NOT EXISTS idx_identifier ON material_data(identifier);

-- 创建更新时间戳触发器
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

DROP TRIGGER IF EXISTS update_material_data_updated_at ON material_data;
CREATE TRIGGER update_material_data_updated_at
    BEFORE UPDATE ON material_data
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- 添加注释
COMMENT ON TABLE material_data IS '材料/文献数据表 - 存储从文档中提取的学术数据';

-- 验证创建结果
SELECT 
    '✅ material_data 表创建/验证完成!' AS 状态,
    (SELECT COUNT(*) FROM information_schema.columns WHERE table_name = 'material_data') AS "字段总数",
    (SELECT COUNT(*) FROM material_data) AS "当前记录数",
    pg_size_pretty(pg_total_relation_size('material_data')) AS "表大小",
    (SELECT COUNT(*) FROM pg_indexes WHERE tablename = 'material_data') AS "索引数量";
