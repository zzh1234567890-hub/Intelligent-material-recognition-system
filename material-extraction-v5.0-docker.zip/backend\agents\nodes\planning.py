"""
任务规划节点

根据意图分析结果，生成具体的任务执行计划
"""

from typing import Dict, Any, List
from backend.agents.state import AgentState, update_state_timestamp


def task_planning_node(state: AgentState) -> AgentState:
    """
    任务规划节点
    
    功能：
    1. 接收意图分析结果
    2. 根据用户意图生成详细的执行步骤
    3. 创建任务计划列表
    4. 更新状态并传递给工具执行节点
    
    Args:
        state: 当前 Agent 状态（需包含 user_intent）
        
    Returns:
        AgentState: 更新后的状态（包含 task_plan 字段）
    """
    print("\n" + "="*60)
    print("📋 [节点2] 任务规划")
    print("="*60)
    
    try:
        intent = state.get("user_intent", {})
        action = intent.get("action", "extract_upload")
        data_formats = intent.get("data_format", ["mysql"])
        
        # 根据不同动作类型生成计划
        if action == "extract_upload":
            plan = _create_extract_and_upload_plan(data_formats, state)
        elif action == "extract_only":
            plan = _create_extract_only_plan(data_formats, state)
        elif action == "query_data":
            plan = _create_query_plan(state)
        elif action == "preview_data":
            plan = _create_preview_plan(state)
        else:
            plan = _create_default_plan(state)
        
        # 更新状态
        state["task_plan"] = plan
        state["total_steps"] = len(plan)
        state["current_step"] = 0
        state = update_state_timestamp(state)
        
        # 打印计划
        _print_task_plan(plan)
        
        return state
        
    except Exception as e:
        error_msg = f"任务规划失败: {str(e)}"
        print(f"❌ {error_msg}")
        
        state["error_info"] = {
            "step": "task_planning",
            "error_type": "PLANNING_ERROR",
            "message": error_msg,
            "details": str(e)
        }
        state["status"] = "failed"
        state = update_state_timestamp(state)
        
        return state


def _create_extract_and_upload_plan(formats: List[str], state: AgentState) -> List[Dict[str, Any]]:
    """
    创建「提取+上传」的任务计划
    
    这是完整的处理流程，包括：
    1. 解析文档
    2. 提取数据
    3. 预览确认
    4. 写入 Excel
    5. 上传 MySQL
    """
    has_files = state.get("file_count", 0) > 0
    
    plan = []
    step = 0
    
    if has_files:
        step += 1
        plan.append({
            "step": step,
            "tool": "everything_read",
            "action": "parse_documents",
            "description": "解析上传的文档内容（PDF/Word/Markdown）",
            "status": "pending",
            "required": True
        })
    
    step += 1
    plan.append({
        "step": step,
        "tool": "get_data",
        "action": "extract_data",
        "description": "使用 LLM 从文档中提取材料/文献数据",
        "status": "pending",
        "required": True
    })
    
    step += 1
    plan.append({
        "step": step,
        "tool": "get_data",
        "action": "preview_data",
        "description": "展示提取的数据供用户预览确认",
        "status": "pending",
        "required": True
    })
    
    if "excel" in formats or "mysql" in formats:
        step += 1
        plan.append({
            "step": step,
            "tool": "format_data",
            "action": "write_excel",
            "description": "将确认后的数据写入 Excel 文件",
            "status": "pending",
            "required": ("excel" in formats or "mysql" in formats)
        })
    
    if "mysql" in formats:
        step += 1
        plan.append({
            "step": step,
            "tool": "upload_data",
            "action": "upload_to_mysql",
            "description": "将 Excel 数据上传到 MySQL 数据库",
            "status": "pending",
            "required": True
        })
    
    return plan


def _create_extract_only_plan(formats: List[str], state: AgentState) -> List[Dict[str, Any]]:
    """
    创建「仅提取」的任务计划
    （不包含上传步骤）
    """
    base_plan = _create_extract_and_upload_plan(["excel"], state)
    
    return [
        task for task in base_plan
        if task["tool"] != "upload_data"
    ]


def _create_query_plan(state: AgentState) -> List[Dict[str, Any]]:
    """
    创建「查询数据」的任务计划
    """
    return [
        {
            "step": 1,
            "tool": "upload_data",
            "action": "query_database",
            "description": "从 MySQL 数据库中查询已有数据",
            "status": "pending",
            "required": True
        },
        {
            "step": 2,
            "tool": "system",
            "action": "format_results",
            "description": "格式化查询结果并返回给用户",
            "status": "pending",
            "required": True
        }
    ]


def _create_preview_plan(state: AgentState) -> List[Dict[str, Any]]:
    """
   创建「预览」的任务计划
    """
    has_files = state.get("file_count", 0) > 0
    plan = []
    
    if has_files:
        plan.append({
            "step": 1,
            "tool": "everything_read",
            "action": "parse_documents",
            "description": "解析上传的文档内容",
            "status": "pending",
            "required": True
        })
    
    plan.append({
        "step": len(plan) + 1,
        "tool": "system",
        "action": "show_preview",
        "description": "展示文档内容的预览摘要",
        "status": "pending",
        "required": True
    })
    
    return plan


def _create_default_plan(state: AgentState) -> List[Dict[str, Any]]:
    """
    创建默认的任务计划（完整流程）
    """
    return _create_extract_and_upload_plan(["mysql", "excel"], state)


def _print_task_plan(plan: List[Dict[str, Any]]):
    """打印任务计划"""
    print(f"\n✅ 任务规划完成（共 {len(plan)} 个步骤）：")
    print("-"*60)
    
    for task in plan:
        status_icon = "⏳" if task["status"] == "pending" else "✓"
        required_mark = "[必须]" if task.get("required") else "[可选]"
        
        print(f"\n{status_icon} Step {task['step']}: {task['description']}")
        print(f"   工具: {task['tool']}")
        print(f"   操作: {task['action']}")
        print(f"   {required_mark}")
    
    print("\n" + "-"*60)
