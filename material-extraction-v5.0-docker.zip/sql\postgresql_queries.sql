-- ============================================================
-- PostgreSQL 数据库查询工具箱
-- 用于查看 material_data 表及相关信息
-- 使用方法: 复制需要的 SQL 语句到 psql 或 pgAdmin 执行
-- ============================================================

-- ========================================
-- 1️⃣ 基础连接测试
-- ========================================

-- 测试数据库连接
SELECT 
    version() AS "PostgreSQL版本",
    current_database() AS "当前数据库",
    current_user AS "当前用户",
    inet_server_addr() AS "服务器地址",
    inet_server_port() AS "端口",
    now() AS "当前时间";


-- ========================================
-- 2️⃣ 数据库列表
-- ========================================

-- 查看所有数据库
SELECT 
    datname AS "数据库名",
    pg_encoding_to_char(encoding) AS "编码",
    datcollate AS "排序规则",
    datctype AS "字符分类",
    datistemplate AS "是否模板库",
    pg_size_pretty(pg_database_size(datname)) AS "大小"
FROM pg_database 
WHERE datistemplate = false
ORDER BY pg_database_size(datname) DESC;


-- ========================================
-- 3️⃣ material_data 表结构详解
-- ========================================

-- 3.1 表的基本信息
SELECT 
    table_name AS "表名",
    table_type AS "类型"
FROM information_schema.tables 
WHERE table_schema = 'public' AND table_name = 'material_data';


-- 3.2 字段详细信息（推荐使用）
SELECT 
    column_name AS "字段名",
    ordinal_position AS "位置",
    column_default AS "默认值",
    is_nullable AS "允许NULL",
    data_type AS "数据类型",
    character_maximum_length AS "最大长度",
    numeric_precision AS "数值精度",
    numeric_scale AS "小数位数"
FROM information_schema.columns 
WHERE table_schema = 'public' AND table_name = 'material_data'
ORDER BY ordinal_position;


-- 3.3 更详细的字段信息（包含注释）
SELECT 
    a.attname AS "字段名",
    t.typname AS "数据类型",
    CASE WHEN a.attnotnull THEN 'NOT NULL' ELSE 'NULL' END AS "约束",
    COALESCE(d.description, '-') AS "注释",
    a.attnum AS "顺序"
FROM pg_class c
JOIN pg_attribute a ON a.attrelid = c.oid
LEFT JOIN pg_type t ON t.oid = a.atttypid
LEFT JOIN pg_description d ON d.objoid = c.oid AND d.objsubid = a.attnum
WHERE c.relname = 'material_data'
    AND a.attnum > 0
    AND NOT a.attisdropped
ORDER BY a.attnum;


-- ========================================
-- 4️⃣ 数据统计（重要！）
-- ========================================

-- 4.1 总记录数
SELECT COUNT(*) AS "总记录数" FROM material_data;

-- 4.2 各类统计
SELECT 
    COUNT(*) AS "总记录数",
    COUNT(CASE WHEN identifier IS NOT NULL AND identifier != '' THEN 1 END) AS "有标识符",
    COUNT(CASE WHEN title IS NOT NULL AND title != '' THEN 1 END) AS "有标题",
    COUNT(CASE WHEN authors IS NOT NULL AND authors != '' THEN 1 END) AS "有作者",
    COUNT(CASE WHEN year IS NOT NULL AND year != '' THEN 1 END) AS "有年份",
    COUNT(DISTINCT type) AS "文档类型数",
    COUNT(DISTINCT year) AS "年份数",
    MIN(year) AS "最早年份",
    MAX(year) AS "最晚年份"
FROM material_data;

-- 4.3 按类型分组统计
SELECT 
    COALESCE(type, '(空)') AS "文档类型",
    COUNT(*) AS "数量",
    ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER(), 2) AS "占比%"
FROM material_data
GROUP BY type
ORDER BY COUNT(*) DESC;

-- 4.4 按年份分布统计
SELECT 
    COALESCE(year, '(未知)') AS "年份",
    COUNT(*) AS "发表数量"
FROM material_data
GROUP BY year
ORDER BY year DESC NULLS LAST;

-- 4.5 按期刊/来源统计 TOP 10
SELECT 
    COALESCE(journal, '(未知)') AS "期刊/来源",
    COUNT(*) AS "文章数"
FROM material_data
GROUP BY journal
ORDER BY COUNT(*) DESC
LIMIT 10;


-- ========================================
-- 5️⃣ 查看实际数据
-- ========================================

-- 5.1 查看所有数据（限制20条）
SELECT * FROM material_data ORDER BY id DESC LIMIT 20;

-- 5.2 查看最新插入的5条记录
SELECT * FROM material_data ORDER BY created_at DESC LIMIT 5;

-- 5.3 指定字段查看（更清晰）
SELECT 
    id,
    identifier,
    type,
    LEFT(title, 50) AS "标题(截断)",
    LEFT(authors, 40) AS "作者(截断)",
    journal,
    year,
    created_at AS "创建时间"
FROM material_data
ORDER BY id DESC
LIMIT 15;

-- 5.4 搜索特定记录（按ID或标识符）
-- 示例: 查找 ID=3 的记录
SELECT * FROM material_data WHERE id = 3;

-- 示例: 查找特定标识符
SELECT * FROM material_data WHERE identifier = 'zhang2021spalling';

-- 5.5 模糊搜索（按标题或作者）
-- 搜索包含"concrete"的记录
SELECT id, identifier, title, authors, year 
FROM material_data 
WHERE title ILIKE '%concrete%' OR authors ILIKE '%concrete%'
ORDER BY id;


-- ========================================
-- 6️⃣ 索引信息
-- ========================================

-- 查看表上的所有索引
SELECT 
    i.relname AS "索引名称",
    am.amname AS "索引方法",
    ix.indisunique AS "是否唯一",
    ix.indisprimary AS "是否主键",
    array_to_string(array_agg(a.attname ORDER BY x.seq_in_index), ', ') AS "包含字段"
FROM pg_class t
JOIN pg_index ix ON ix.indrelid = t.oid
JOIN pg_class i ON i.oid = ix.indexrelid
JOIN pg_am am ON am.oid = i.relam
CROSS JOIN LATERAL unnest(ix.indkey) WITH ORDINALITY AS x(attnum, seq_in_index)
JOIN pg_attribute a ON a.attrelid = t.oid AND a.attnum = x.attnum
WHERE t.relname = 'material_data'
GROUP BY i.relname, am.amname, ix.indisunique, ix.indisprimary
ORDER BY i.relname;


-- ========================================
-- 7️⃣ 表空间和大小
-- ========================================

-- 查看 material_data 表占用空间
SELECT 
    relname AS "表名",
    pg_size_pretty(pg_total_relation_size(relid)) AS "总大小",
    pg_size_pretty(pg_relation_size(relid)) AS "数据大小",
    pg_size_pretty(pg_total_relation_size(relid) - pg_relation_size(relid)) AS "索引大小",
    n_live_tup AS "估算行数",
    n_dead_tup AS "死元组数"
FROM pg_stat_user_tables 
WHERE relname = 'material_data';


-- ========================================
-- 8️⃣ 会话和锁信息
-- ========================================

-- 当前活跃连接
SELECT 
    pid AS "进程ID",
    usename AS "用户名",
    application_name AS "应用名称",
    client_addr AS "客户端地址",
    state AS "状态",
    query_start AS "查询开始时间",
    LEFT(query, 100) AS "正在执行的SQL"
FROM pg_stat_activity 
WHERE datname = 'material_db'
ORDER BY query_start;


-- ========================================
-- 9️⃣ 性能监控
-- ========================================

-- 表访问统计
SELECT 
    seq_scan AS "全表扫描次数",
    seq_tup_read AS "全表扫描读取行数",
    idx_scan AS "索引扫描次数",
    idx_tup_fetch AS "索引扫描获取行数",
    n_tup_ins AS "插入行数",
    n_tup_upd AS "更新行数",
    n_tup_del AS "删除行数",
    last_vacuum AS "最后VACUUM时间",
    last_autovacuum AS "最后自动VACUUM时间"
FROM pg_stat_user_tables 
WHERE relname = 'material_data';


-- ========================================
-- 🔟 数据完整性检查
-- ========================================

-- 检查重复的 identifier
SELECT 
    identifier,
    COUNT(*) AS "重复次数"
FROM material_data
WHERE identifier IS NOT NULL AND identifier != ''
GROUP BY identifier
HAVING COUNT(*) > 1
ORDER BY COUNT(*) DESC;

-- 检查空值情况
SELECT 
    COUNT(*) - COUNT(identifier) AS "identifier空值数",
    COUNT(*) - COUNT(type) AS "type空值数",
    COUNT(*) - COUNT(title) AS "title空值数",
    COUNT(*) - COUNT(authors) AS "authors空值数",
    COUNT(*) - COUNT(year) AS "year空值数",
    COUNT(*) - COUNT(journal) AS "journal空值数"
FROM material_data;


-- ========================================
-- 📊 一键完整报告（推荐！）
-- ========================================

-- 生成完整的表状态报告
WITH stats AS (
    SELECT 
        COUNT(*) AS total_records,
        COUNT(DISTINCT type) AS types_count,
        COUNT(DISTINCT year) AS years_count,
        MIN(created_at) AS first_record,
        MAX(created_at) AS last_record,
        SUM(CASE WHEN identifier IS NOT NULL AND identifier != '' THEN 1 ELSE 0 END) AS has_identifier,
        SUM(CASE WHEN title IS NOT NULL AND title != '' THEN 1 ELSE 0 END) AS has_title
    FROM material_data
)
SELECT 
    '📋 material_data 表状态报告' AS "报告标题",
    '' AS "",
    (SELECT COUNT(*) FROM material_data) AS "✅ 总记录数",
    (SELECT COUNT(DISTINCT type) FROM material_data) AS "📁 文档类型数",
    (SELECT COUNT(DISTINCT year) FROM material_data) AS "📅 年份范围",
    (SELECT MIN(year) || ' ~ ' || MAX(year) FROM material_data WHERE year IS NOT NULL AND year != '') AS "📆 年份跨度",
    (SELECT pg_size_pretty(pg_total_relation_size('material_data'))) AS "💾 表大小",
    (SELECT COUNT(*) FROM pg_indexes WHERE tablename = 'material_data') AS "🔑 索引数量",
    '' AS "",
    '--- 详细统计 ---' AS "",
    s.*
FROM stats s
CROSS JOIN (SELECT 1) dummy;
