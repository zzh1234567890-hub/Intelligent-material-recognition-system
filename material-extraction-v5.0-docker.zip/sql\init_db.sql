SET client_encoding TO 'UTF8';

DROP TABLE IF EXISTS test_results CASCADE;
DROP TABLE IF EXISTS test_result_group CASCADE;
DROP TABLE IF EXISTS test_methods CASCADE;
DROP TABLE IF EXISTS heating_protocols CASCADE;
DROP TABLE IF EXISTS specimens CASCADE;
DROP TABLE IF EXISTS specimens_group CASCADE;
DROP TABLE IF EXISTS fibers CASCADE;
DROP TABLE IF EXISTS mix_proportions CASCADE;
DROP TABLE IF EXISTS material_data CASCADE;
DROP TABLE IF EXISTS fiber_type_dict CASCADE;
DROP TABLE IF EXISTS result_property_dict CASCADE;

CREATE TABLE fiber_type_dict (
    fiber_type_code VARCHAR(50) PRIMARY KEY,
    display_name VARCHAR(100) NOT NULL,
    notes TEXT
);

INSERT INTO fiber_type_dict (fiber_type_code, display_name) VALUES
    ('steel', 'Steel'),
    ('polypropylene', 'Polypropylene (PP)'),
    ('polyethylene', 'Polyethylene (PE)'),
    ('polyvinyl_alcohol', 'Poly alcohol (PVA)'),
    ('polyoxymethylene', 'Polyoxymethylene (POM)'),
    ('glass', 'Glass'),
    ('carbon', 'Carbon'),
    ('basalt', 'Basalt'),
    ('other', 'Other');

CREATE TABLE result_property_dict (
    property_code VARCHAR(80) PRIMARY KEY,
    display_name VARCHAR(100) NOT NULL,
    default_unit VARCHAR(20),
    notes TEXT
);

INSERT INTO result_property_dict (property_code, display_name, default_unit) VALUES
    ('compressive_strength', 'Compressive strength', 'MPa'),
    ('direct_tensile_strength', 'Direct tensile strength', 'MPa'),
    ('splitting_tensile_strength', 'Splitting tensile strength', 'MPa'),
    ('flexural_strength', 'Flexural strength', 'MPa'),
    ('elastic_modulus', 'Elastic modulus', 'GPa'),
    ('peak_strain', 'Peak strain', 'mm/mm'),
    ('mass_loss_ratio_percent', 'Mass loss ratio', '%'),
    ('residual_strength_ratio', 'Residual strength ratio', '-'),
    ('failure_mode', 'Failure mode', NULL),
    ('spalling', 'Spalling', NULL),
    ('thermal_conductivity', 'Thermal conductivity', 'W/(m·K)'),
    ('permeability', 'Permeability coefficient', 'm/s');

CREATE TABLE material_data (
    paper_code VARCHAR(30) PRIMARY KEY,
    bib_key VARCHAR(200) UNIQUE,
    entry_type VARCHAR(50) NOT NULL DEFAULT '',
    title TEXT NOT NULL,
    authors_bib TEXT,
    journal VARCHAR(300) DEFAULT '',
    volume VARCHAR(30) DEFAULT '',
    number VARCHAR(30) DEFAULT '',
    pages VARCHAR(50) DEFAULT '',
    year CHAR(4) DEFAULT '',
    publisher VARCHAR(200) DEFAULT '',
    doi VARCHAR(300) UNIQUE,
    abstract TEXT,
    notes TEXT,
    source_file VARCHAR(500) DEFAULT '',
    uploaded_by VARCHAR(100) DEFAULT '',
    session_id VARCHAR(100) DEFAULT '',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_material_data_year CHECK (year = '' OR year ~ '^\d{4}$')
);

CREATE INDEX idx_material_data_bib_key ON material_data(bib_key);
CREATE INDEX idx_material_data_year ON material_data(year);
CREATE INDEX idx_material_data_journal ON material_data(journal);

CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER trg_material_data_updated
    BEFORE UPDATE ON material_data
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TABLE mix_proportions (
    mix_code VARCHAR(40) PRIMARY KEY,
    paper_code VARCHAR(30) NOT NULL REFERENCES material_data(paper_code) ON DELETE CASCADE,
    mix_label VARCHAR(100) NOT NULL,
    author_defined_concrete_label VARCHAR(200) DEFAULT '',
    fiber_enhanced SMALLINT NOT NULL DEFAULT 0,
    binder_type VARCHAR(100),
    water_binder_ratio NUMERIC(5, 3),
    cement_kg_m3 NUMERIC(10, 2),
    silica_fume_kg_m3 NUMERIC(10, 2),
    limestone_filler_kg_m3 NUMERIC(10, 2),
    fly_ash_kg_m3 NUMERIC(10, 2),
    slag_kg_m3 NUMERIC(10, 2),
    metakaolin_kg_m3 NUMERIC(10, 2),
    water_kg_m3 NUMERIC(10, 2),
    fine_aggregate_kg_m3 NUMERIC(10, 2),
    coarse_aggregate_kg_m3 NUMERIC(10, 2),
    silica_sand_kg_m3 NUMERIC(10, 2),
    lightweight_aggregate_kg_m3 NUMERIC(10, 2),
    superplasticizer_kg_m3 NUMERIC(8, 3),
    steel_fiber_volume_fraction NUMERIC(5, 2),
    pp_fiber_volume_fraction NUMERIC(5, 2),
    pe_fiber_volume_fraction NUMERIC(5, 2),
    pva_fiber_volume_fraction NUMERIC(5, 2),
    pom_fiber_volume_fraction NUMERIC(5, 2),
    glass_fiber_volume_fraction NUMERIC(5, 2),
    carbon_fiber_volume_fraction NUMERIC(5, 2),
    other_fiber_volume_fraction NUMERIC(5, 2),
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_mix_fiber_enhanced CHECK (fiber_enhanced IN (0, 1)),
    CONSTRAINT chk_mix_wb_ratio CHECK (water_binder_ratio > 0 AND water_binder_ratio <= 10)
);

CREATE INDEX idx_mix_paper_code ON mix_proportions(paper_code);
CREATE INDEX idx_mix_fiber_enhanced ON mix_proportions(fiber_enhanced);

CREATE TRIGGER trg_mix_proportions_updated
    BEFORE UPDATE ON mix_proportions
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TABLE fibers (
    fiber_code VARCHAR(50) PRIMARY KEY,
    mix_code VARCHAR(40) NOT NULL REFERENCES mix_proportions(mix_code) ON DELETE CASCADE,
    fiber_type VARCHAR(50) NOT NULL,
    display_name VARCHAR(100),
    material_class VARCHAR(50),
    volume_fraction_pct NUMERIC(6, 3),
    length_mm NUMERIC(8, 3),
    diameter_min_mm NUMERIC(8, 4),
    diameter_max_mm NUMERIC(8, 4),
    aspect_ratio NUMERIC(8, 1),
    mass_kg_m3 NUMERIC(8, 3),
    shape VARCHAR(50),
    elastic_modulus_gpa NUMERIC(8, 2),
    tensile_strength_mpa NUMERIC(10, 2),
    melting_temp_c NUMERIC(6, 1),
    density_g_cm3 NUMERIC(6, 3),
    note TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_fiber_volume CHECK (volume_fraction_pct >= 0 AND volume_fraction_pct <= 100)
);

CREATE INDEX idx_fibers_mix_code ON fibers(mix_code);
CREATE INDEX idx_fibers_fiber_type ON fibers(fiber_type);

CREATE TRIGGER trg_fibers_updated
    BEFORE UPDATE ON fibers
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TABLE specimens_group (
    specimen_group_code VARCHAR(60) PRIMARY KEY,
    mix_code VARCHAR(40) NOT NULL REFERENCES mix_proportions(mix_code) ON DELETE CASCADE,
    specimen_label VARCHAR(100),
    specimen_shape VARCHAR(30) NOT NULL,
    intended_test_type VARCHAR(80),
    length_mm NUMERIC(8, 2),
    width_mm NUMERIC(8, 2),
    height_mm NUMERIC(8, 2),
    diameter_mm NUMERIC(8, 2),
    thickness_mm NUMERIC(6, 2),
    gauge_length_mm NUMERIC(8, 2),
    gauge_width_mm NUMERIC(6, 2),
    age_at_test_day INTEGER,
    curing_method VARCHAR(50),
    curing_temp_c NUMERIC(5, 1),
    curing_rh_pct NUMERIC(5, 1),
    note TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_specimen_shape CHECK (specimen_shape IN (
        'cube', 'cylinder', 'prism', 'dog_bone', 'beam', 'disk', 'plate', 'other'
    ))
);

CREATE INDEX idx_specgrp_mix_code ON specimens_group(mix_code);
CREATE INDEX idx_specgrp_shape ON specimens_group(specimen_shape);

CREATE TRIGGER trg_specimens_group_updated
    BEFORE UPDATE ON specimens_group
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TABLE specimens (
    specimen_id SERIAL PRIMARY KEY,
    specimen_code VARCHAR(70) UNIQUE NOT NULL,
    specimen_group_code VARCHAR(60) NOT NULL REFERENCES specimens_group(specimen_group_code) ON DELETE CASCADE,
    specimen_label VARCHAR(100),
    specimen_shape VARCHAR(30) NOT NULL,
    length_mm NUMERIC(8, 2),
    width_mm NUMERIC(8, 2),
    height_mm NUMERIC(8, 2),
    diameter_mm NUMERIC(8, 2),
    thickness_mm NUMERIC(6, 2),
    gauge_length_mm NUMERIC(8, 2),
    gauge_width_mm NUMERIC(6, 2),
    age_at_test_day INTEGER,
    curing_method VARCHAR(50),
    note TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_specimens_group_code ON specimens(specimen_group_code);

CREATE TRIGGER trg_specimens_updated
    BEFORE UPDATE ON specimens
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TABLE heating_protocols (
    heating_protocol_id VARCHAR(40) PRIMARY KEY,
    paper_code VARCHAR(30) NOT NULL REFERENCES material_data(paper_code) ON DELETE CASCADE,
    target_temperature NUMERIC(7, 1),
    target_temperature_display VARCHAR(50),
    cycle INTEGER NOT NULL DEFAULT 1,
    heating_rate_degree_min NUMERIC(6, 2),
    holding_time_min NUMERIC(8, 1),
    cooling_time_min NUMERIC(8, 1),
    cooling_method VARCHAR(50),
    fire_curve VARCHAR(100),
    loaded_during_heating VARCHAR(50),
    load_level_pct NUMERIC(5, 1),
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_hp_cycle CHECK (cycle >= 1)
);

CREATE INDEX idx_hp_paper_code ON heating_protocols(paper_code);
CREATE INDEX idx_hp_target_temp ON heating_protocols(target_temperature);

CREATE TRIGGER trg_heating_protocols_updated
    BEFORE UPDATE ON heating_protocols
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TABLE test_methods (
    method_code VARCHAR(60) PRIMARY KEY,
    paper_code VARCHAR(30) REFERENCES material_data(paper_code) ON DELETE SET NULL,
    test_type VARCHAR(80) NOT NULL,
    test_state VARCHAR(50),
    standard VARCHAR(200),
    standard_code VARCHAR(50),
    loading_rate NUMERIC(12, 4),
    loading_rate_unit VARCHAR(30),
    machine_type VARCHAR(100),
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_tm_test_type ON test_methods(test_type);

CREATE TRIGGER trg_test_methods_updated
    BEFORE UPDATE ON test_methods
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TABLE test_result_group (
    result_group_code VARCHAR(60) PRIMARY KEY,
    paper_code VARCHAR(30) NOT NULL REFERENCES material_data(paper_code) ON DELETE CASCADE,
    heating_protocol_id VARCHAR(40) REFERENCES heating_protocols(heating_protocol_id) ON DELETE SET NULL,
    specimen_group_code VARCHAR(60) REFERENCES specimens_group(specimen_group_code) ON DELETE SET NULL,
    specimen_label VARCHAR(100),
    spalling VARCHAR(20),
    compressive_group_code VARCHAR(60) REFERENCES specimens_group(specimen_group_code) ON DELETE SET NULL,
    compressive_test_method_code VARCHAR(60) REFERENCES test_methods(method_code) ON DELETE SET NULL,
    compressive_strength NUMERIC(12, 4),
    direct_tensile_group_code VARCHAR(60) REFERENCES specimens_group(specimen_group_code) ON DELETE SET NULL,
    direct_tensile_test_method_code VARCHAR(60) REFERENCES test_methods(method_code) ON DELETE SET NULL,
    direct_tensile_strength NUMERIC(10, 4),
    splitting_tensile_group_code VARCHAR(60) REFERENCES specimens_group(specimen_group_code) ON DELETE SET NULL,
    splitting_tensile_method_code VARCHAR(60) REFERENCES test_methods(method_code) ON DELETE SET NULL,
    splitting_tensile_strength NUMERIC(10, 4),
    flexural_group_code VARCHAR(60) REFERENCES specimens_group(specimen_group_code) ON DELETE SET NULL,
    flexural_test_method_code VARCHAR(60) REFERENCES test_methods(method_code) ON DELETE SET NULL,
    flexural_strength NUMERIC(10, 4),
    elastic_modulus NUMERIC(10, 3),
    peak_strain NUMERIC(12, 6),
    mass_loss_ratio_percent NUMERIC(6, 3),
    failure_mode VARCHAR(100),
    residual_strength_ratio NUMERIC(6, 3),
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_spalling CHECK (spalling IS NULL OR spalling IN ('yes', 'no', 'minor', 'severe', 'explosive', 'none'))
);

CREATE INDEX idx_trg_paper_code ON test_result_group(paper_code);
CREATE INDEX idx_trg_heating_id ON test_result_group(heating_protocol_id);
CREATE INDEX idx_trg_compressive ON test_result_group(compressive_strength) WHERE compressive_strength IS NOT NULL;
CREATE INDEX idx_trg_spalling ON test_result_group(spalling) WHERE spalling IS NOT NULL;

CREATE TRIGGER trg_test_result_group_updated
    BEFORE UPDATE ON test_result_group
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TABLE test_results (
    result_id SERIAL PRIMARY KEY,
    result_code VARCHAR(70) UNIQUE NOT NULL,
    method_code VARCHAR(60) REFERENCES test_methods(method_code) ON DELETE SET NULL,
    specimen_code VARCHAR(70) REFERENCES specimens(specimen_code) ON DELETE SET NULL,
    specimen_label VARCHAR(100),
    heating_protocol_id VARCHAR(40) REFERENCES heating_protocols(heating_protocol_id) ON DELETE SET NULL,
    test_state VARCHAR(50),
    property_code VARCHAR(80) NOT NULL,
    value_numeric NUMERIC(14, 6),
    value_text TEXT,
    value_min NUMERIC(14, 6),
    value_max NUMERIC(14, 6),
    value_mean NUMERIC(14, 6),
    value_std_dev NUMERIC(14, 6),
    sample_size INTEGER,
    unit VARCHAR(20),
    failure_mode VARCHAR(100),
    spalling VARCHAR(20),
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_results_property_code ON test_results(property_code);
CREATE INDEX idx_results_heating_id ON test_results(heating_protocol_id);

CREATE TRIGGER trg_test_results_updated
    BEFORE UPDATE ON test_results
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();
