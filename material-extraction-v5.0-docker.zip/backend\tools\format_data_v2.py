from __future__ import annotations

import os
import re
import time
from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter

from backend.tools.get_data_v2 import TABLE_SCHEMAS


class format_data_v2:
    """
    多表结构Excel文件管理器 v3.0
    
    核心变更（v3.0）：
    - 始终追加到同一个Excel文件（material_data_v2.xlsx）
    - ID自动递增：根据Excel已有数据自动计算下一个编号
      paper_code: P_001 -> P_002 -> P_003 ...
      mix_code: P_002_M_001 ...
      所有外键级联更新
    - 写入后返回重映射后的数据（用于PostgreSQL上传）
    
    使用流程：
    1. create_or_open()  -> 打开已有Excel（或创建新的）
    2. write_all(data)   -> 追加数据，自动递增ID，返回重映射数据
    3. save()            -> 保存文件
    """

    description = "多表Excel管理器v3.0 - 追加模式、ID自动递增、级联更新"

    DEFAULT_FILENAME = "material_data_v2.xlsx"

    TABLE_ORDER = [
        "material_data", "mix_proportions", "fibers",
        "specimens_group", "specimens",
        "heating_protocols", "test_methods",
        "test_result_group", "test_results",
    ]

    PRIMARY_KEYS = {
        "material_data": "paper_code",
        "mix_proportions": "mix_code",
        "fibers": "fiber_code",
        "specimens_group": "specimen_group_code",
        "specimens": "specimen_code",
        "heating_protocols": "heating_protocol_id",
        "test_methods": "method_code",
        "test_result_group": "result_group_code",
        "test_results": "result_code",
    }

    # 外键关系：子表字段 -> 父表主键
    FOREIGN_KEY_RELATIONS = {
        "mix_proportions": {"paper_code": ("material_data", "paper_code")},
        "fibers": {"mix_code": ("mix_proportions", "mix_code")},
        "specimens_group": {"mix_code": ("mix_proportions", "mix_code")},
        "specimens": {"specimen_group_code": ("specimens_group", "specimen_group_code")},
        "heating_protocols": {"paper_code": ("material_data", "paper_code")},
        "test_methods": {"paper_code": ("material_data", "paper_code")},
        "test_result_group": {
            "paper_code": ("material_data", "paper_code"),
            "heating_protocol_id": ("heating_protocols", "heating_protocol_id"),
            "specimen_group_code": ("specimens_group", "specimen_group_code"),
            "compressive_group_code": ("specimens_group", "specimen_group_code"),
            "direct_tensile_group_code": ("specimens_group", "specimen_group_code"),
            "splitting_tensile_group_code": ("specimens_group", "specimen_group_code"),
            "flexural_group_code": ("specimens_group", "specimen_group_code"),
            "compressive_test_method_code": ("test_methods", "method_code"),
            "direct_tensile_test_method_code": ("test_methods", "method_code"),
            "splitting_tensile_method_code": ("test_methods", "method_code"),
            "flexural_test_method_code": ("test_methods", "method_code"),
        },
        "test_results": {
            "result_group_code": ("test_result_group", "result_group_code"),
            "method_code": ("test_methods", "method_code"),
            "heating_protocol_id": ("heating_protocols", "heating_protocol_id"),
            "specimen_code": ("specimens", "specimen_code"),
        },
    }

    def __init__(self, output_dir: str = "./output"):
        self.output_dir = output_dir
        self.workbook = None
        self.filepath = None
        self.existing_primary_keys: Dict[str, set] = {}
        self.max_paper_index: int = 0
        self._ensure_output_dir()

    def _ensure_output_dir(self):
        if not os.path.exists(self.output_dir):
            os.makedirs(self.output_dir)

    def get_filepath(self) -> str:
        base_path = os.path.join(self.output_dir, self.DEFAULT_FILENAME)
        if not os.path.exists(base_path):
            return base_path
        if self._is_file_locked(base_path):
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            name, ext = os.path.splitext(self.DEFAULT_FILENAME)
            new_filename = f"{name}_{timestamp}{ext}"
            new_path = os.path.join(self.output_dir, new_filename)
            print(f"[Excel v3] 原文件被锁定，使用新文件: {new_filename}")
            return new_path
        return base_path

    def _is_file_locked(self, filepath: str) -> bool:
        try:
            with open(filepath, 'a'):
                pass
            return False
        except IOError:
            return True

    def create_or_open(self) -> str:
        self.filepath = self.get_filepath()
        max_retries = 3
        for attempt in range(max_retries):
            try:
                if os.path.exists(self.filepath):
                    self._open_existing()
                else:
                    self._create_new()
                return self.filepath
            except PermissionError as e:
                if attempt < max_retries - 1:
                    time.sleep(1)
                    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                    name, ext = os.path.splitext(self.DEFAULT_FILENAME)
                    new_filename = f"{name}_{timestamp}_retry{attempt+1}{ext}"
                    self.filepath = os.path.join(self.output_dir, new_filename)
                else:
                    raise RuntimeError(f"无法创建/打开Excel文件（已重试{max_retries}次）: {str(e)}")
        return self.filepath

    def _create_new(self):
        self.workbook = Workbook()
        default_sheet = self.workbook.active
        self.workbook.remove(default_sheet)
        dummy = self.workbook.create_sheet(title="_temp")
        self.workbook.save(self.filepath)
        self.max_paper_index = 0
        print(f"[Excel v3] 创建新文件: {self.filepath}")

    def _open_existing(self):
        self.workbook = load_workbook(self.filepath)
        self.existing_primary_keys = {}
        self.max_paper_index = 0

        for sheet_name in self.workbook.sheetnames:
            if sheet_name.startswith("_"):
                continue
            pk_field = self.PRIMARY_KEYS.get(sheet_name)
            if not pk_field:
                continue

            sheet = self.workbook[sheet_name]
            existing_keys = set()

            header_row = None
            for row_idx in range(1, min(sheet.max_row + 1, 2)):
                row_values = [sheet.cell(row=row_idx, column=col).value for col in range(1, sheet.max_column + 1)]
                if any(v for v in row_values):
                    header_row = row_values
                    break

            if header_row and pk_field in header_row:
                pk_col = header_row.index(pk_field) + 1
                for row_idx in range(2, sheet.max_row + 1):
                    val = sheet.cell(row=row_idx, column=pk_col).value
                    if val is not None:
                        existing_keys.add(str(val).strip())

                        # 提取 paper_code 中的最大序号
                        if sheet_name == "material_data" and pk_field == "paper_code":
                            match = re.match(r'P_(\d+)', str(val).strip())
                            if match:
                                idx = int(match.group(1))
                                if idx > self.max_paper_index:
                                    self.max_paper_index = idx

            self.existing_primary_keys[sheet_name] = existing_keys

        total_existing = sum(len(v) for v in self.existing_primary_keys.values())
        print(f"[Excel v3] 打开已有文件: {self.filepath}")
        print(f"   已有记录: {total_existing} 条")
        print(f"   当前最大论文编号: P_{self.max_paper_index:03d}")

    def _get_next_paper_index(self) -> int:
        return self.max_paper_index + 1

    def _remap_ids(self, data: Dict[str, List[Dict]], start_index: int) -> Tuple[Dict[str, List[Dict]], Dict[str, str]]:
        """
        重映射所有ID，使paper_code从 start_index 开始递增
        同时级联更新所有子表的外键

        Returns:
            (remapped_data, paper_code_mapping)
            paper_code_mapping: {"P_001": "P_002", ...} 旧编号 -> 新编号
        """
        paper_code_mapping = {}
        remapped_data = {}

        # 第1步：重映射 material_data 的 paper_code
        old_rows = data.get("material_data", [])
        new_material_rows = []

        for row in old_rows:
            old_code = str(row.get("paper_code", "")).strip()
            if not old_code:
                continue

            new_code = f"P_{start_index:03d}"
            paper_code_mapping[old_code] = new_code
            start_index += 1

            new_row = dict(row)
            new_row["paper_code"] = new_code
            new_material_rows.append(new_row)

        remapped_data["material_data"] = new_material_rows

        # 第2步：收集子表中用到的旧编号映射
        # 对于 mix_code, fiber_code 等，需要基于新的 paper_code 重建
        # 旧格式: P_001_M_001 -> 新格式: P_002_M_001
        mix_code_mapping = {}
        fiber_code_mapping = {}
        specimen_group_code_mapping = {}
        specimen_code_mapping = {}
        heating_protocol_id_mapping = {}
        method_code_mapping = {}
        result_group_code_mapping = {}
        result_code_mapping = {}

        # 第3步：重映射子表
        for table_name in self.TABLE_ORDER:
            if table_name == "material_data":
                continue

            old_rows = data.get(table_name, [])
            new_rows = []

            for row in old_rows:
                new_row = dict(row)

                # 更新 paper_code 外键
                if "paper_code" in new_row:
                    old_pc = str(new_row.get("paper_code", "")).strip()
                    if old_pc in paper_code_mapping:
                        new_row["paper_code"] = paper_code_mapping[old_pc]

                # 更新 mix_code（主键和外键）
                if table_name == "mix_proportions" and "mix_code" in new_row:
                    old_mc = str(new_row.get("mix_code", "")).strip()
                    if old_mc:
                        # 从旧 mix_code 提取序号部分: P_001_M_001 -> M_001
                        parts = old_mc.split("_")
                        # 找到新的 paper_code
                        old_paper = "_".join(parts[:2])  # P_001
                        new_paper = paper_code_mapping.get(old_paper, old_paper)
                        # 保留 M_XXX 部分
                        m_part = "_".join(parts[2:]) if len(parts) > 2 else "M_001"
                        new_mc = f"{new_paper}_{m_part}"
                        mix_code_mapping[old_mc] = new_mc
                        new_row["mix_code"] = new_mc

                # 更新 fibers 的 fiber_code 和 mix_code 外键
                if table_name == "fibers":
                    if "mix_code" in new_row:
                        old_mc = str(new_row.get("mix_code", "")).strip()
                        if old_mc in mix_code_mapping:
                            new_row["mix_code"] = mix_code_mapping[old_mc]

                    if "fiber_code" in new_row:
                        old_fc = str(new_row.get("fiber_code", "")).strip()
                        if old_fc:
                            parts = old_fc.split("_")
                            old_paper = "_".join(parts[:2])
                            new_paper = paper_code_mapping.get(old_paper, old_paper)
                            rest = "_".join(parts[2:]) if len(parts) > 2 else "F01"
                            new_fc = f"{new_paper}_{rest}"
                            fiber_code_mapping[old_fc] = new_fc
                            new_row["fiber_code"] = new_fc

                # 更新 specimens_group
                if table_name == "specimens_group":
                    if "mix_code" in new_row:
                        old_mc = str(new_row.get("mix_code", "")).strip()
                        if old_mc in mix_code_mapping:
                            new_row["mix_code"] = mix_code_mapping[old_mc]

                    if "specimen_group_code" in new_row:
                        old_sgc = str(new_row.get("specimen_group_code", "")).strip()
                        if old_sgc:
                            parts = old_sgc.split("_")
                            old_paper = "_".join(parts[:2])
                            new_paper = paper_code_mapping.get(old_paper, old_paper)
                            rest = "_".join(parts[2:]) if len(parts) > 2 else "G_001"
                            new_sgc = f"{new_paper}_{rest}"
                            specimen_group_code_mapping[old_sgc] = new_sgc
                            new_row["specimen_group_code"] = new_sgc

                # 更新 specimens（个体级试件）
                if table_name == "specimens":
                    if "specimen_group_code" in new_row:
                        old_sgc = str(new_row.get("specimen_group_code", "")).strip()
                        if old_sgc in specimen_group_code_mapping:
                            new_row["specimen_group_code"] = specimen_group_code_mapping[old_sgc]

                    if "specimen_code" in new_row:
                        old_sc = str(new_row.get("specimen_code", "")).strip()
                        if old_sc:
                            parts = old_sc.split("_")
                            old_paper = "_".join(parts[:2])
                            new_paper = paper_code_mapping.get(old_paper, old_paper)
                            rest = "_".join(parts[2:]) if len(parts) > 2 else "S_001"
                            new_sc = f"{new_paper}_{rest}"
                            specimen_code_mapping[old_sc] = new_sc
                            new_row["specimen_code"] = new_sc

                # 更新 heating_protocols
                if table_name == "heating_protocols":
                    if "heating_protocol_id" in new_row:
                        old_hp = str(new_row.get("heating_protocol_id", "")).strip()
                        if old_hp:
                            parts = old_hp.split("_")
                            old_paper = "_".join(parts[:2])
                            new_paper = paper_code_mapping.get(old_paper, old_paper)
                            rest = "_".join(parts[2:]) if len(parts) > 2 else "H_001"
                            new_hp = f"{new_paper}_{rest}"
                            heating_protocol_id_mapping[old_hp] = new_hp
                            new_row["heating_protocol_id"] = new_hp

                # 更新 test_methods
                if table_name == "test_methods":
                    if "method_code" in new_row:
                        old_mc = str(new_row.get("method_code", "")).strip()
                        if old_mc:
                            parts = old_mc.split("_")
                            old_paper = "_".join(parts[:2])
                            new_paper = paper_code_mapping.get(old_paper, old_paper)
                            rest = "_".join(parts[2:]) if len(parts) > 2 else "ME_001"
                            new_mc = f"{new_paper}_{rest}"
                            method_code_mapping[old_mc] = new_mc
                            new_row["method_code"] = new_mc

                # 更新 test_result_group
                if table_name == "test_result_group":
                    if "heating_protocol_id" in new_row:
                        old_hp = str(new_row.get("heating_protocol_id", "")).strip()
                        if old_hp in heating_protocol_id_mapping:
                            new_row["heating_protocol_id"] = heating_protocol_id_mapping[old_hp]

                    if "specimen_group_code" in new_row:
                        old_sgc = str(new_row.get("specimen_group_code", "")).strip()
                        if old_sgc in specimen_group_code_mapping:
                            new_row["specimen_group_code"] = specimen_group_code_mapping[old_sgc]

                    for fk_field in [
                        "compressive_group_code", "direct_tensile_group_code",
                        "splitting_tensile_group_code", "flexural_group_code"
                    ]:
                        if fk_field in new_row:
                            old_val = str(new_row.get(fk_field, "")).strip()
                            if old_val and old_val in specimen_group_code_mapping:
                                new_row[fk_field] = specimen_group_code_mapping[old_val]

                    for fk_field in [
                        "compressive_test_method_code", "direct_tensile_test_method_code",
                        "splitting_tensile_method_code", "flexural_test_method_code"
                    ]:
                        if fk_field in new_row:
                            old_val = str(new_row.get(fk_field, "")).strip()
                            if old_val and old_val in method_code_mapping:
                                new_row[fk_field] = method_code_mapping[old_val]

                    if "result_group_code" in new_row:
                        old_rgc = str(new_row.get("result_group_code", "")).strip()
                        if old_rgc:
                            parts = old_rgc.split("_")
                            old_paper = "_".join(parts[:2])
                            new_paper = paper_code_mapping.get(old_paper, old_paper)
                            rest = "_".join(parts[2:]) if len(parts) > 2 else "RG_001"
                            new_rgc = f"{new_paper}_{rest}"
                            result_group_code_mapping[old_rgc] = new_rgc
                            new_row["result_group_code"] = new_rgc

                # 更新 test_results
                if table_name == "test_results":
                    if "result_group_code" in new_row:
                        old_rgc = str(new_row.get("result_group_code", "")).strip()
                        if old_rgc in result_group_code_mapping:
                            new_row["result_group_code"] = result_group_code_mapping[old_rgc]

                    if "method_code" in new_row:
                        old_mc = str(new_row.get("method_code", "")).strip()
                        if old_mc in method_code_mapping:
                            new_row["method_code"] = method_code_mapping[old_mc]

                    if "heating_protocol_id" in new_row:
                        old_hp = str(new_row.get("heating_protocol_id", "")).strip()
                        if old_hp in heating_protocol_id_mapping:
                            new_row["heating_protocol_id"] = heating_protocol_id_mapping[old_hp]

                    if "specimen_code" in new_row:
                        old_sc = str(new_row.get("specimen_code", "")).strip()
                        if old_sc in specimen_code_mapping:
                            new_row["specimen_code"] = specimen_code_mapping[old_sc]

                    if "result_code" in new_row:
                        old_rc = str(new_row.get("result_code", "")).strip()
                        if old_rc:
                            parts = old_rc.split("_")
                            old_paper = "_".join(parts[:2])
                            new_paper = paper_code_mapping.get(old_paper, old_paper)
                            rest = "_".join(parts[2:]) if len(parts) > 2 else "R_001"
                            new_rc = f"{new_paper}_{rest}"
                            result_code_mapping[old_rc] = new_rc
                            new_row["result_code"] = new_rc

                new_rows.append(new_row)

            remapped_data[table_name] = new_rows

        # 复制 _meta
        if "_meta" in data:
            remapped_data["_meta"] = data["_meta"]

        return remapped_data, paper_code_mapping

    def write_all(self, data: Dict[str, List[Dict]]) -> Dict[str, Any]:
        """
        写入所有表的数据（追加模式，ID自动递增）

        Args:
            data: {table_name: [row_dicts...]} 格式的数据（LLM原始输出）

        Returns:
            dict: {
                "_summary": {total_added, total_skipped, filepath, new_paper_codes},
                table_name: (新增数, 跳过重复数),
                "remapped_data": 重映射后的完整数据（用于PostgreSQL上传）
            }
        """
        if self.workbook is None:
            raise RuntimeError("请先调用 create_or_open()")

        # 核心步骤1：重映射ID
        next_index = self._get_next_paper_index()
        print(f"\n[Excel v3] ID重映射: 从 P_{next_index:03d} 开始")

        remapped_data, paper_mapping = self._remap_ids(data, next_index)

        if paper_mapping:
            print(f"[Excel v3] 编号映射:")
            for old, new in paper_mapping.items():
                print(f"   {old} -> {new}")

        # 核心步骤2：写入Excel（追加模式）
        results = {}
        total_added = 0
        total_skipped = 0

        for table_name in self.TABLE_ORDER:
            rows = remapped_data.get(table_name, [])
            if not rows:
                continue

            added, skipped = self._write_table(table_name, rows)
            results[table_name] = (added, skipped)
            total_added += added
            total_skipped += skipped

        for table_name, rows in remapped_data.items():
            if table_name.startswith("_") or table_name in self.TABLE_ORDER:
                continue
            if not rows:
                continue
            added, skipped = self._write_table(table_name, rows)
            results[table_name] = (added, skipped)
            total_added += added
            total_skipped += skipped

        if total_added > 0:
            self.workbook.save(self.filepath)
            # 更新最大论文编号
            self.max_paper_index = next_index + len(paper_mapping) - 1

        new_paper_codes = list(paper_mapping.values())

        results["_summary"] = {
            "total_added": total_added,
            "total_skipped": total_skipped,
            "filepath": self.filepath,
            "new_paper_codes": new_paper_codes,
            "next_paper_index": self.max_paper_index + 1,
        }

        # 核心步骤3：返回重映射后的数据（用于PostgreSQL上传）
        results["remapped_data"] = remapped_data

        print(f"\n[Excel v3] 写入完成: 新增 {total_added} 条, 跳过重复 {total_skipped} 条")
        print(f"[Excel v3] 新增论文编号: {', '.join(new_paper_codes)}")
        print(f"[Excel v3] 下次起始编号: P_{self.max_paper_index + 1:03d}")

        return results

    def _write_table(self, table_name: str, rows: List[Dict]) -> Tuple[int, int]:
        schema = TABLE_SCHEMAS.get(table_name)
        if not schema:
            field_names = list(rows[0].keys()) if rows else []
        else:
            field_names = [f[0] for f in schema["fields"]]

        pk_field = self.PRIMARY_KEYS.get(table_name)

        if table_name not in self.workbook.sheetnames:
            sheet = self.workbook.create_sheet(title=table_name)
            self._write_header(sheet, field_names, table_name)
            self.existing_primary_keys.setdefault(table_name, set())
        else:
            sheet = self.workbook[table_name]

        existing_keys = self.existing_primary_keys.get(table_name, set())

        added = 0
        skipped = 0

        start_row = sheet.max_row + 1 if sheet.max_row > 1 else 2

        for row_data in rows:
            if pk_field and pk_field in row_data:
                pk_val = str(row_data[pk_field]).strip()
                if pk_val and pk_val in existing_keys:
                    skipped += 1
                    continue
                if pk_val:
                    existing_keys.add(pk_val)

            for col_idx, field_name in enumerate(field_names, 1):
                value = row_data.get(field_name)
                cell = sheet.cell(row=start_row + added, column=col_idx, value=value)
                self._apply_cell_style(cell)

            added += 1

        if added > 0:
            self._auto_fit_columns(sheet, len(field_names))

        return added, skipped

    def _write_header(self, sheet, field_names: List[str], table_name: str):
        header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF", size=10)
        border = self._get_border()

        for col_idx, field_name in enumerate(field_names, 1):
            cell = sheet.cell(row=1, column=col_idx, value=field_name)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
            cell.border = border
            sheet.column_dimensions[get_column_letter(col_idx)].width = 18

    @staticmethod
    def _apply_cell_style(cell):
        cell.border = format_data_v2._get_border()
        cell.alignment = Alignment(wrap_text=True, vertical='top')

    @staticmethod
    def _auto_fit_columns(sheet, num_cols: int):
        for col_idx in range(1, num_cols + 1):
            max_length = 0
            col_letter = get_column_letter(col_idx)
            for row in range(1, min(sheet.max_row + 1, 50)):
                cell_value = sheet.cell(row=row, column=col_idx).value
                if cell_value:
                    max_length = max(max_length, len(str(cell_value)))
            adjusted_width = min(max(max_length + 2, 10), 50)
            sheet.column_dimensions[col_letter].width = adjusted_width

    @staticmethod
    def _get_border():
        return Border(
            left=Side(style='thin'),
            right=Side(style='thin'),
            top=Side(style='thin'),
            bottom=Side(style='thin')
        )

    def save(self) -> str:
        if self.workbook is None:
            raise RuntimeError("没有打开的工作簿")
        self.workbook.save(self.filepath)
        return self.filepath

    def close(self):
        if self.workbook:
            self.workbook.close()
            self.workbook = None

    def get_stats(self) -> Dict[str, Any]:
        stats = {"filepath": self.filepath, "sheets": {}, "max_paper_index": self.max_paper_index}
        if self.workbook:
            for name in self.workbook.sheetnames:
                sheet = self.workbook[name]
                stats["sheets"][name] = {
                    "rows": max(0, sheet.max_row - 1),
                    "columns": sheet.max_column,
                    "existing_keys": len(self.existing_primary_keys.get(name, set())),
                }
        return stats
