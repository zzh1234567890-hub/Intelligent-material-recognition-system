from fastapi import APIRouter
from . import document, data, agent

api_router = APIRouter()

api_router.include_router(document.router)
api_router.include_router(data.router)
api_router.include_router(agent.router)
