/**
 * 前端调试辅助脚本
 * 用于诊断预览界面空白的问题
 */

// 在浏览器控制台(F12)中运行此代码
// 或者在 HomeView.vue 的 extractData 函数中临时添加

const DEBUG_EXTRACT = {
  // 拦截 axios 响应
  logExtractResponse(response) {
    console.group('🔍 [DEBUG] 数据提取响应详情');
    console.log('✅ 响应状态:', response.status);
    console.log('✅ 完整响应数据:', response.data);
    console.log('📊 preview_items 数量:', response.data?.preview_items?.length || 0);
    console.log('📋 summary 对象:', response.data?.summary);
    console.log('🔑 is_multi_table:', response.data?.summary?.['is_multi_table']);
    
    if (response.data?.preview_items?.length > 0) {
      console.log('📝 前3条预览数据:');
      response.data.preview_items.slice(0, 3).forEach((item, idx) => {
        console.log(`  ${idx + 1}.`, item);
      });
    } else {
      console.warn('⚠️ preview_items 为空！');
    }
    
    console.groupEnd();
    return response;
  },

  // 检查 Vue 组件状态
  checkComponentState(component) {
    console.group('🔍 [DEBUG] 组件状态检查');
    console.log('extractedData:', component.extractedData);
    console.log('summary:', component.summary);
    console.log('currentStep:', component.currentStep);
    console.log('previewColumns:', component.previewColumns);
    console.log('tableCounts:', component.tableCounts);
    console.groupEnd();
  },

  // 测试 API 连接
  async testAPIConnection() {
    try {
      const response = await fetch('/api/health');
      const data = await response.json();
      console.log('✅ 后端健康检查:', data);
      return data;
    } catch (error) {
      console.error('❌ 后端连接失败:', error);
      return null;
    }
  }
};

// 导出供使用
window.DEBUG_EXTRACT = DEBUG_EXTRACT;

console.log('✅ 调试工具已加载！使用方法:');
console.log('  1. 运行完整提取后，在控制台输入: DEBUG_EXTRACT.checkComponentState(this)');
console.log('  2. 手动测试API: DEBUG_EXTRACT.testAPIConnection()');
