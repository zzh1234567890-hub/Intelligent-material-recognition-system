"""
Session 持久化存储管理器

将 Session 数据保存到文件系统，避免重启服务后丢失。
支持长时间跨天使用，不受内存限制。
自动定时清理过期 Session（每 48 小时）。
"""

import os
import json
import sys
import io

# 修复 Windows GBK 编码问题（支持 UTF-8 输出）
if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

import uuid
import threading
import time
from datetime import datetime, timedelta
from typing import Dict, Any, Optional


class PersistentSessionManager:
    """
    基于 Session 文件的持久化管理器
    
    特性：
    - 数据存储在 ./sessions/ 目录
    - 每个 Session 一个 JSON 文件
    - 支持设置过期时间（默认 7 天）
    - 自动定时清理过期 Session（每 48 小时）
    
    使用示例：
        manager = PersistentSessionManager()
        
        # 创建并保存 session
        session_id = manager.create(data={"file_name": "test.pdf"})
        
        # 获取 session
        data = manager.get(session_id)
        
        # 更新 session
        manager.update(session_id, {"status": "extracted"})
        
        # 列出所有 session
        all_sessions = manager.list_all()
        
        # 自动清理会在后台运行，无需手动调用
    """
    
    def __init__(self, storage_dir: str = "./sessions", expire_days: int = 7, cleanup_interval_hours: int = 48):
        self.storage_dir = storage_dir
        self.expire_days = expire_days
        self.cleanup_interval_hours = cleanup_interval_hours
        self._cleanup_thread = None
        self._stop_cleanup = threading.Event()
        
        self._ensure_storage_dir()
        self._start_auto_cleanup()
    
    def _ensure_storage_dir(self):
        """确保存储目录存在"""
        if not os.path.exists(self.storage_dir):
            os.makedirs(self.storage_dir)
    
    def _get_session_path(self, session_id: str) -> str:
        """获取 session 文件路径"""
        return os.path.join(self.storage_dir, f"{session_id}.json")
    
    def create(self, initial_data: Dict[str, Any] = None) -> str:
        """
        创建新的 Session 并返回 ID
        
        Args:
            initial_data: 初始数据
            
        Returns:
            str: session_id
        """
        session_id = str(uuid.uuid4())
        
        session_data = {
            "session_id": session_id,
            "created_at": datetime.now().isoformat(),
            "updated_at": datetime.now().isoformat(),
            "expires_at": (datetime.now() + timedelta(days=self.expire_days)).isoformat(),
            "status": "created",
            **(initial_data or {})
        }
        
        self._save(session_id, session_data)
        
        print(f"✅ Session 已创建: {session_id[:8]}...")
        return session_id
    
    def get(self, session_id: str) -> Optional[Dict[str, Any]]:
        """
        获取 Session 数据
        
        Args:
            session_id: 会话ID
            
        Returns:
            dict or None: Session 数据，不存在则返回 None
        """
        file_path = self._get_session_path(session_id)
        
        if not os.path.exists(file_path):
            return None
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            # 检查是否过期
            expires_at = datetime.fromisoformat(data.get("expires_at", ""))
            if datetime.now() > expires_at:
                self.delete(session_id)
                return None
            
            return data
            
        except (json.JSONDecodeError, KeyError, ValueError) as e:
            print(f"⚠️ Session {session_id[:8]}... 数据损坏: {e}")
            return None
    
    def update(self, session_id: str, update_data: Dict[str, Any]) -> bool:
        """
        更新 Session 数据
        
        Args:
            session_id: 会话ID
            update_data: 要更新的字段
            
        Returns:
            bool: 是否成功
        """
        existing = self.get(session_id)
        
        if not existing:
            return False
        
        existing.update(update_data)
        existing["updated_at"] = datetime.now().isoformat()
        
        self._save(session_id, existing)
        return True
    
    def delete(self, session_id: str) -> bool:
        """
        删除指定 Session
        
        Args:
            session_id: 会话ID
            
        Returns:
            bool: 是否成功删除
        """
        file_path = self._get_session_path(session_id)
        
        if os.path.exists(file_path):
            os.remove(file_path)
            return True
        
        return False
    
    def _save(self, session_id: str, data: Dict[str, Any]):
        """内部方法：保存 Session 到文件"""
        file_path = self._get_session_path(session_id)
        
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    
    def list_all(self, include_expired: bool = False) -> list:
        """
        列出所有 Session
        
        Args:
            include_expired: 是否包含已过期的
            
        Returns:
            list: Session 信息列表
        """
        sessions = []
        
        for filename in os.listdir(self.storage_dir):
            if not filename.endswith('.json'):
                continue
            
            file_path = os.path.join(self.storage_dir, filename)
            
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                
                if not include_expired:
                    expires_at = datetime.fromisoformat(data.get("expires_at", ""))
                    if datetime.now() > expires_at:
                        continue
                
                sessions.append({
                    "session_id": data.get("session_id"),
                    "status": data.get("status"),
                    "created_at": data.get("created_at"),
                    "updated_at": data.get("updated_at"),
                    "expires_at": data.get("expires_at"),
                    "file_name": data.get("file_name", ""),
                    "file_type": data.get("file_type", "")
                })
                
            except Exception as e:
                continue
        
        # 按更新时间倒序排列
        sessions.sort(key=lambda x: x["updated_at"], reverse=True)
        
        return sessions
    
    def cleanup(self) -> int:
        """
        清理过期的 Session（内部方法，由自动清理调用）
        
        Returns:
            int: 清理的数量
        """
        cleaned_count = 0
        now = datetime.now()
        
        for filename in os.listdir(self.storage_dir):
            if not filename.endswith('.json'):
                continue
            
            file_path = os.path.join(self.storage_dir, filename)
            
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                
                expires_at = datetime.fromisoformat(data.get("expires_at", ""))
                
                if now > expires_at:
                    os.remove(file_path)
                    cleaned_count += 1
                    
            except Exception:
                continue
        
        if cleaned_count > 0:
            print(f"🧹 [{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] 自动清理: 已删除 {cleaned_count} 个过期 Session")
        
        return cleaned_count
    
    def _start_auto_cleanup(self):
        """启动自动清理后台线程"""
        self._stop_cleanup.clear()
        self._cleanup_thread = threading.Thread(
            target=self._auto_cleanup_loop,
            daemon=True,
            name="SessionAutoCleanup"
        )
        self._cleanup_thread.start()
        print(f"✅ Session 自动清理已启动（每 {self.cleanup_interval_hours} 小时执行一次）")
    
    def _auto_cleanup_loop(self):
        """
        自动清理循环
        
        每 48 小时执行一次清理，直到服务停止。
        首次启动时会立即执行一次清理。
        """
        while not self._stop_cleanup.is_set():
            try:
                # 执行清理
                self.cleanup()
                
                # 等待下一次清理（每小时检查一次是否需要停止）
                for _ in range(self.cleanup_interval_hours):
                    if self._stop_cleanup.is_set():
                        return
                    time.sleep(3600)  # 每小时检查一次
                    
            except Exception as e:
                print(f"⚠️ Session 自动清理出错: {e}")
                time.sleep(3600)  # 出错后等待 1 小时再试
    
    def stop_auto_cleanup(self):
        """停止自动清理线程（服务关闭时调用）"""
        self._stop_cleanup.set()
        if self._cleanup_thread and self._cleanup_thread.is_alive():
            self._cleanup_thread.join(timeout=5)
        print("🛑 Session 自动清理已停止")
    
    def get_stats(self) -> Dict[str, Any]:
        """获取 Session 统计信息"""
        all_sessions = self.list_all(include_expired=True)
        active_sessions = [s for s in all_sessions 
                         if datetime.fromisoformat(s.get("expires_at", "")) > datetime.now()]
        
        return {
            "total_sessions": len(all_sessions),
            "active_sessions": len(active_sessions),
            "expired_sessions": len(all_sessions) - len(active_sessions),
            "storage_dir": os.path.abspath(self.storage_dir),
            "expire_days": self.expire_days,
            "cleanup_interval_hours": self.cleanup_interval_hours,
            "auto_cleanup_running": self._cleanup_thread is not None and self._cleanup_thread.is_alive()
        }


# 全局单例实例
_session_manager = None


def get_session_manager() -> PersistentSessionManager:
    """获取全局 Session 管理器实例"""
    global _session_manager
    
    if _session_manager is None:
        _session_manager = PersistentSessionManager()
    
    return _session_manager
