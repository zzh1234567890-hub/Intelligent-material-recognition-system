from __future__ import annotations

import os
from datetime import datetime
from typing import Dict, Any, Tuple

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side


class format_data:
    """
    Excel 文件管理器（单文件追加模式）
    
    特性：
    - 使用固定文件名：material_data.xlsx
    - 支持追加写入：新数据自动添加到已有文件末尾
    - 自动去重：基于 identifier 字段避免重复
    
    工作流程：
    1. create_or_open()  → 创建或打开 Excel 文件
    2. add_rows(records) → 批量添加数据（自动去重）
    3. save()           → 保存文件
    """

    description = "Excel 文件管理器：单文件追加模式、自动去重"

    DEFAULT_FILENAME = "material_data.xlsx"
    
    DEFAULT_COLUMNS = [
        ("id", "编号"),
        ("identifier", "标识符"),
        ("type", "类型"),
        ("title", "标题"),
        ("authors", "作者"),
        ("journal", "期刊/来源"),
        ("volume", "卷号"),
        ("issue", "期号"),
        ("pages", "页码"),
        ("year", "年份"),
        ("publisher", "出版社"),
        ("doi", "DOI"),
        ("abstract", "摘要/备注"),
    ]

    def __init__(self, output_dir: str = "./output"):
        self.output_dir = output_dir
        self.columns = self.DEFAULT_COLUMNS.copy()
        self.workbook = None
        self.sheet = None
        self.filepath = None
        self.current_row = 0
        self.existing_identifiers = set()  # 用于去重
        self._ensure_output_dir()

    def _ensure_output_dir(self):
        """确保输出目录存在"""
        if not os.path.exists(self.output_dir):
            os.makedirs(self.output_dir)

    def get_filepath(self) -> str:
        """获取固定的 Excel 文件路径"""
        return os.path.join(self.output_dir, self.DEFAULT_FILENAME)

    def create_or_open(self) -> str:
        """
        创建或打开 Excel 文件（固定文件名 + 追加模式）
        
        如果文件不存在，创建新的带表头的文件
        如果文件已存在，打开并读取已有的 identifier 用于去重
        
        Returns:
            str: Excel 文件路径
        """
        self.filepath = self.get_filepath()
        
        if os.path.exists(self.filepath):
            # 打开已有文件
            self._open_existing()
        else:
            # 创建新文件
            self._create_new()
        
        return self.filepath

    def _create_new(self):
        """创建新的 Excel 文件"""
        self.workbook = Workbook()
        self.sheet = self.workbook.active
        self.sheet.title = "材料数据"

        self._write_header()
        self._apply_header_style()

        self.current_row = 2
        self.workbook.save(self.filepath)

    def _open_existing(self):
        """打开已有的 Excel 文件"""
        self.workbook = load_workbook(self.filepath)
        
        if "材料数据" in self.workbook.sheetnames:
            self.sheet = self.workbook["材料数据"]
        else:
            self.sheet = self.workbook.active
            self.sheet.title = "材料数据"
            self._write_header()
            self._apply_header_style()
            self.current_row = 2
            self.workbook.save(self.filepath)
            return

        # 查找最后一行和已有 identifier
        self.current_row = 2  # 从第 2 行开始检查
        
        for row_idx in range(2, self.sheet.max_row + 1):
            cell_value = self.sheet.cell(row=row_idx, column=2).value  # identifier 在第 2 列
            
            if cell_value:
                self.existing_identifiers.add(str(cell_value).strip())
                self.current_row = row_idx + 1
            elif not any(
                self.sheet.cell(row=row_idx, column=col).value 
                for col in range(1, len(self.columns) + 1)
            ):
                break  # 空行，停止
            else:
                self.current_row = row_idx + 1

        print(f"📂 打开已有文件: {self.filepath}")
        print(f"   已有记录: {len(self.existing_identifiers)} 条")
        print(f"   下次写入位置: 第 {self.current_row} 行")

    def add_rows(self, records: list[dict]) -> tuple:
        """
        批量添加数据（自动去重）
        
        Args:
            records: 材料数据列表
            
        Returns:
            tuple: (实际新增数量, 跳过的重复数量)
        """
        if self.sheet is None:
            raise RuntimeError("请先调用 create_or_open() 创建或打开文件")

        added_count = 0
        skipped_count = 0
        new_records = []

        for record in records:
            identifier = record.get('identifier', '').strip()
            
            # 去重检查
            if identifier and identifier in self.existing_identifiers:
                skipped_count += 1
                continue
            
            # 添加数据
            row_num = self._add_single_row(record)
            
            # 记录 identifier
            if identifier:
                self.existing_identifiers.add(identifier)
            
            new_records.append(record)
            added_count += 1

        # 保存
        if added_count > 0:
            self.workbook.save(self.filepath)
            print(f"✅ 新增 {added_count} 条记录，跳过 {skipped_count} 条重复")

        return (added_count, skipped_count)

    def _add_single_row(self, record: dict) -> int:
        """添加单行数据"""
        for col_idx, (field_name, _) in enumerate(self.columns, 1):
            value = record.get(field_name, "")
            cell = self.sheet.cell(row=self.current_row, column=col_idx, value=value)
            self._apply_cell_style(cell)

        row_num = self.current_row
        self.current_row += 1
        return row_num

    def save(self) -> str:
        """保存 Excel 文件"""
        if self.workbook is None:
            raise RuntimeError("没有打开的工作簿")

        self.workbook.save(self.filepath)
        total_rows = self.current_row - 2
        return self.filepath

    def close(self):
        """关闭工作簿"""
        if self.workbook:
            self.workbook.close()
            self.workbook = None
            self.sheet = None

    def _write_header(self):
        """写入表头 - 使用英文字段名（与数据库一致）"""
        for col_idx, (field_name, _) in enumerate(self.columns, 1):
            cell = self.sheet.cell(row=1, column=col_idx, value=field_name)

    def _apply_header_style(self):
        """应用表头样式"""
        header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")
        border = self._get_border()

        for col_idx in range(1, len(self.columns) + 1):
            cell = self.sheet.cell(row=1, column=col_idx)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal='center', vertical='center')
            cell.border = border
            self.sheet.column_dimensions[cell.column_letter].width = 18

    def _apply_cell_style(self, cell):
        """应用单元格样式"""
        cell.border = self._get_border()
        cell.alignment = Alignment(wrap_text=True, vertical='top')

    @staticmethod
    def _get_border():
        return Border(
            left=Side(style='thin'),
            right=Side(style='thin'),
            top=Side(style='thin'),
            bottom=Side(style='thin')
        )

    @property
    def row_count(self) -> int:
        """已写入的数据行数"""
        return max(0, self.current_row - 2)

    @property
    def is_open(self) -> bool:
        """检查是否已创建并打开文件"""
        return self.workbook is not None

    def get_stats(self) -> dict:
        """获取当前文件统计信息"""
        return {
            'filepath': self.filepath,
            'total_rows': self.row_count,
            'existing_identifiers': len(self.existing_identifiers),
            'next_row': self.current_row,
            'file_exists': os.path.exists(self.get_filepath()) if not self.filepath else True
        }
