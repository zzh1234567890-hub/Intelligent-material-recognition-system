@echo off
echo ============================================
echo   PDFFigures 2.0 Docker Setup
echo ============================================
echo.

REM Check Docker
docker --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Docker not found! Please install Docker Desktop first.
    echo Download: https://www.docker.com/products/docker-desktop
    pause
    exit /b 1
)

echo [1/3] Cloning pdffigures-mcp-server...
if not exist pdffigures-mcp-server (
    git clone https://github.com/vlln/pdffigures-mcp-server.git
)

echo [2/3] Building Docker image (this may take a few minutes)...
cd pdffigures-mcp-server
docker build -t pdffigures2 .

echo [3/3] Starting PDFFigures 2.0 service on port 5001...
docker rm -f pdffigures2-server 2>nul
docker run -d -p 5001:5001 --name pdffigures2-server pdffigures2

echo.
echo Waiting for service to start...
timeout /t 10 /nobreak >nul

echo Testing API...
curl -s http://localhost:5001/docs >nul 2>&1
if %errorlevel% equ 0 (
    echo.
    echo ============================================
    echo   SUCCESS! PDFFigures 2.0 is running
    echo   API: http://localhost:5001/api/extract
    echo   Docs: http://localhost:5001/docs
    echo ============================================
) else (
    echo.
    echo [WARN] Service may still be starting. Check with:
    echo   docker logs pdffigures2-server
)

pause
