"""
LangGraph Agent 状态定义

定义 Agent 在工作流中传递的状态数据结构
"""

from typing import TypedDict, List, Dict, Any, Optional
from enum import Enum


class TaskStatus(str, Enum):
    """任务状态枚举"""
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"


class DocumentType(str, Enum):
    """文档类型枚举"""
    PDF = "pdf"
    DOCX = "docx"
    MARKDOWN = "markdown"
    UNKNOWN = "unknown"


class AgentState(TypedDict):
    """
    Agent 状态类型定义
    
    这是 LangGraph 工作流中各节点之间传递的数据结构，
    定义了完整的处理流程所需的所有状态字段。
    
    字段说明：
    ==========
    
    用户输入相关:
    - user_input: 用户的自然语言输入
    - user_intent: 解析后的用户意图
    
    文档相关:
    - uploaded_files: 上传的文件列表
    - document_content: 解析后的文档内容
    - document_type: 文档类型
    
    任务规划相关:
    - task_plan: 任务执行计划
    - current_step: 当前执行的步骤索引
    - total_steps: 总步骤数
    
    工具调用结果:
    - tool_results: 各工具的执行结果
    - extracted_data: LLM 提取的数据
    - excel_path: 生成的 Excel 文件路径
    - mysql_result: MySQL 上传结果
    
    输出相关:
    - final_response: 最终响应给用户的消息
    - error_info: 错误信息（如果有）
    - status: 整体处理状态
    - session_id: 会话标识符
    """
    
    # ==================== 用户输入 ====================
    user_input: str                          # 用户原始输入
    user_intent: Dict[str, Any]              # 意图分析结果 {
                                            #   "action": "extract_upload",
                                            #   "target": "material_data",
                                            #   "format": "mysql",
                                            #   "confidence": 0.95
                                            # }
    
    # ==================== 文档信息 ====================
    uploaded_files: List[Dict[str, Any]]     # 上传的文件列表 [{
                                            #   "name": "example.pdf",
                                            #   "type": "pdf",
                                            #   "size": 1234567,
                                            #   "path": "/tmp/xxx.pdf"
                                            # }]
    document_content: str                    # 解析后的纯文本内容
    document_type: str                       # pdf/docx/markdown
    file_count: int                         # 文件数量
    
    # ==================== 任务规划 ====================
    task_plan: List[Dict[str, Any]]          # 任务计划列表 [{
                                            #   "step": 1,
                                            #   "tool": "everything_read",
                                            #   "action": "parse_documents",
                                            #   "description": "解析上传的文档",
                                            #   "status": "pending"
                                            # }]
    current_step: int                        # 当前步骤（从1开始）
    total_steps: int                         # 总步骤数
    
    # ==================== 工具执行结果 ====================
    tool_results: Dict[str, Any]            # 各工具的执行结果 {
                                            #   "read_result": {...},
                                            #   "extract_result": [...],
                                            #   "excel_result": {...},
                                            #   "upload_result": {...}
                                            # }
    
    # 数据处理中间结果
    extracted_data: List[Dict[str, Any]]     # 提取的材料数据列表
    preview_data: Dict[str, Any]            # 预览数据 {
                                            #   "total": 15,
                                            #   "preview_items": [...],
                                            #   "summary": {...}
                                            # }
    excel_path: Optional[str]               # Excel 文件路径
    written_data_count: int                 # 写入 Excel 的数据条数
    
    # 数据库操作结果
    mysql_table_name: Optional[str]         # 目标表名
    mysql_result: Dict[str, Any]            # MySQL 上传结果 {
                                            #   "success": 14,
                                            #   "failed": 0,
                                            #   "total": 14,
                                            #   "table_name": "material_data"
                                            # }
    
    # ==================== 输出与状态 ====================
    final_response: str                     # 最终响应消息
    error_info: Optional[Dict[str, Any]]    # 错误信息 {
                                            #   "step": "extract_data",
                                            #   "error_type": "LLM_ERROR",
                                            #   "message": "...",
                                            #   "details": "..."
                                            # }
    status: str                             # pending/processing/completed/failed
    session_id: str                         # 会话 ID
    created_at: str                         # 创建时间
    updated_at: str                         # 最后更新时间


def create_initial_state(
    user_input: str = "",
    session_id: str = "",
    uploaded_files: list = None
) -> AgentState:
    """
    创建初始状态
    
    Args:
        user_input: 用户输入文本
        session_id: 会话ID（可选，不传则自动生成）
        uploaded_files: 已上传的文件列表
        
    Returns:
        AgentState: 初始化后的状态字典
    """
    import uuid
    from datetime import datetime
    
    if not session_id:
        session_id = str(uuid.uuid4())
    
    timestamp = datetime.now().isoformat()
    
    return AgentState(
        # 用户输入
        user_input=user_input or "",
        user_intent={},
        
        # 文档信息
        uploaded_files=uploaded_files or [],
        document_content="",
        document_type="",
        file_count=len(uploaded_files) if uploaded_files else 0,
        
        # 任务规划
        task_plan=[],
        current_step=0,
        total_steps=0,
        
        # 工具执行结果
        tool_results={},
        extracted_data=[],
        preview_data={},
        excel_path=None,
        written_data_count=0,
        
        # 数据库
        mysql_table_name=None,
        mysql_result={},
        
        # 输出与状态
        final_response="",
        error_info=None,
        status="pending",
        session_id=session_id,
        created_at=timestamp,
        updated_at=timestamp
    )


def update_state_timestamp(state: AgentState) -> AgentState:
    """更新状态的最后修改时间"""
    from datetime import datetime
    state["updated_at"] = datetime.now().isoformat()
    return state


def get_state_summary(state: AgentState) -> Dict[str, Any]:
    """
    获取状态摘要（用于日志和调试）
    
    Returns:
        dict: 包含关键状态信息的摘要
    """
    return {
        "session_id": state.get("session_id", ""),
        "status": state.get("status", "unknown"),
        "user_input": state.get("user_input", "")[:100],
        "file_count": state.get("file_count", 0),
        "current_step": f"{state.get('current_step', 0)}/{state.get('total_steps', 0)}",
        "extracted_count": len(state.get("extracted_data", [])),
        "has_excel": bool(state.get("excel_path")),
        "mysql_status": "uploaded" if state.get("mysql_result") else "not_uploaded",
        "error": bool(state.get("error_info")),
        "created_at": state.get("created_at", ""),
        "updated_at": state.get("updated_at", "")
    }
