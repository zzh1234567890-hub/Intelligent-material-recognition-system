-- ============================================
-- 智能材料数据识别系统 - PostgreSQL 建表脚本
-- ============================================
-- 
-- 使用说明：
-- 1. 确保 PostgreSQL 服务已启动
-- 2. 使用 psql 执行此脚本
-- 
-- 执行方式：
--   psql -U postgres -f create_tables_postgresql.sql
--
-- 或在 psql 命令行中：
--   \i d:/nnnnnnnnew_try/sql/create_tables_postgresql.sql
-- ============================================

-- 设置客户端编码
SET client_encoding TO 'UTF8';

-- ============================================
-- 1. 创建数据库（如果不存在）
-- ============================================
SELECT 'CREATE DATABASE material_db'
WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'material_db')\gexec

\c material_db

-- ============================================
-- 2. 删除旧表（如果存在）
-- ============================================
DROP TABLE IF EXISTS material_data CASCADE;

-- ============================================
-- 3. 创建材料数据表
-- ============================================
CREATE TABLE IF NOT EXISTS material_data (
    -- 主键
    id SERIAL PRIMARY KEY,
    
    -- 核心字段
    identifier VARCHAR(100) NOT NULL DEFAULT '' UNIQUE,
    type VARCHAR(50) NOT NULL DEFAULT '',
    title TEXT,
    authors TEXT,
    journal VARCHAR(200) DEFAULT '',
    volume VARCHAR(20) DEFAULT '',
    issue VARCHAR(20) DEFAULT '',
    pages VARCHAR(50) DEFAULT '',
    year CHAR(4) DEFAULT '',
    publisher VARCHAR(200) DEFAULT '',
    doi VARCHAR(200) DEFAULT '',
    abstract TEXT,
    
    -- 系统字段
    source_file VARCHAR(500) DEFAULT '',
    uploaded_by VARCHAR(100),
    session_id VARCHAR(100),
    
    -- 时间戳
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- 4. 创建索引
-- ============================================
CREATE INDEX IF NOT EXISTS idx_material_data_type ON material_data(type);
CREATE INDEX IF NOT EXISTS idx_material_data_year ON material_data(year);
CREATE INDEX IF NOT EXISTS idx_material_data_journal ON material_data(journal);
CREATE INDEX IF NOT EXISTS idx_material_data_created_at ON material_data(created_at);

-- ============================================
-- 5. 添加注释
-- ============================================
COMMENT ON TABLE material_data IS '材料/文献数据表';
COMMENT ON COLUMN material_data.id IS '自增主键';
COMMENT ON COLUMN material_data.identifier IS '唯一标识符';
COMMENT ON COLUMN material_data.type IS '文档类型';
COMMENT ON COLUMN material_data.title IS '标题';
COMMENT ON COLUMN material_data.authors IS '作者列表';
COMMENT ON COLUMN material_data.journal IS '期刊/来源名称';
COMMENT ON COLUMN material_data.year IS '出版年份';
COMMENT ON COLUMN material_data.doi IS 'DOI 数字对象标识符';
COMMENT ON COLUMN material_data.abstract IS '摘要/备注';

-- ============================================
-- 6. 验证
-- ============================================
SELECT 
    '✅ 表创建成功' AS status,
    table_name,
    (SELECT COUNT(*) FROM information_schema.columns WHERE table_name = 'material_data') AS column_count
FROM information_schema.tables 
WHERE table_name = 'material_data'
AND table_schema = 'public';

\d+ material_data

-- ============================================
-- 完成
-- ============================================
SELECT '✅ PostgreSQL 数据库初始化完成！' AS message;
SELECT '数据库：material_db' AS database_info;
SELECT '表：material_data' AS table_info;
