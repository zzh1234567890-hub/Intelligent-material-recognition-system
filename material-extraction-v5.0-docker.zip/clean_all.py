"""
一键清理脚本 - 同时清空 Excel 文件和 PostgreSQL 数据库
用法: python clean_all.py
"""
import os
import sys
import glob

sys.path.insert(0, r'd:\nnnnnnnnew_try')

OUTPUT_DIR = os.path.join(r'd:\nnnnnnnnew_try', 'output')
EXCEL_FILES = [
    'material_data_v2.xlsx',
]
EXCEL_PATTERNS = ['material_data_v2*.xlsx']

print("=" * 60)
print("  一键清理工具 (Excel + PostgreSQL)")
print("=" * 60)

# ============================================================
# Part 1: 清理 Excel 文件
# ============================================================
print("\n[1/2] 清理 Excel 文件...")

excel_cleaned = []
for filename in EXCEL_FILES:
    filepath = os.path.join(OUTPUT_DIR, filename)
    if os.path.exists(filepath):
        try:
            os.remove(filepath)
            excel_cleaned.append(filename)
            print(f"  删除: {filepath}")
        except Exception as e:
            print(f"  失败: {filepath} - {e}")

for pattern in EXCEL_PATTERNS:
    matches = glob.glob(os.path.join(OUTPUT_DIR, pattern))
    for f in matches:
        if os.path.basename(f) not in excel_cleaned:
            try:
                os.remove(f)
                excel_cleaned.append(os.path.basename(f))
                print(f"  删除: {f}")
            except Exception as e:
                print(f"  失败: {f} - {e}")

if excel_cleaned:
    print(f"\n  ✅ 已删除 {len(excel_cleaned)} 个 Excel 文件")
else:
    print("\n  ℹ️ 没有找到需要删除的 Excel 文件")

# ============================================================
# Part 2: 清空 PostgreSQL 数据库
# ============================================================
print("\n[2/2] 清空 PostgreSQL 数据库...")

try:
    import psycopg
    from psycopg.rows import dict_row

    conn = psycopg.connect(
        host='localhost', port=5432,
        user='postgres', password='postgres',
        dbname='material_db'
    )
    conn.autocommit = True
    cur = conn.cursor(row_factory=dict_row)

    tables = [
        ('test_results', 'result_code'),
        ('test_result_group', 'result_group_code'),
        ('test_methods', 'method_code'),
        ('heating_protocols', 'heating_protocol_id'),
        ('specimens', 'specimen_code'),
        ('specimens_group', 'specimen_group_code'),
        ('fibers', 'fiber_code'),
        ('mix_proportions', 'mix_code'),
        ('material_data', 'paper_code'),
    ]

    total_deleted = 0
    for table_name, pk in tables:
        try:
            cur.execute(f'SELECT COUNT(*) as cnt FROM {table_name}')
            cnt = cur.fetchone()['cnt']
            if cnt > 0:
                cur.execute(f'DELETE FROM {table_name}')
                print(f'  清空 {table_name}: {cnt} 条记录')
                total_deleted += cnt
        except Exception as e:
            print(f'  跳过 {table_name}: {e}')

    print(f'\n  ✅ PostgreSQL 共清空 {total_deleted} 条记录')

    conn.close()

except ImportError:
    print("\n  ⚠️ psycopg 未安装，跳过数据库清理")
    print("  安装命令: pip install psycopg[binary]")
except Exception as e:
    print(f"\n  ❌ 数据库连接失败: {e}")
    print("  请确保 PostgreSQL 正在运行，且 .env 中配置正确")

# ============================================================
# 完成
# ============================================================
print("\n" + "=" * 60)
print("  清理完成！可以重新开始实验了")
print("=" * 60)
