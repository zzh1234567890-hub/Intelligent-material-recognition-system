from fastapi import APIRouter, Query, HTTPException
from typing import Optional

from backend.models.schemas import DatabaseQueryResponse
from backend.config import get_settings

router = APIRouter(prefix="/api/data", tags=["数据查询"])

settings = get_settings()

ALLOWED_TABLE_NAMES = {
    "material_data", "mix_proportions", "fibers", "specimens_group",
    "specimens", "heating_protocols", "test_methods", "test_result_group",
    "test_results", "fiber_type_dict", "result_property_dict",
}


def _validate_table_name(table_name: str) -> str:
    if table_name not in ALLOWED_TABLE_NAMES:
        raise HTTPException(
            status_code=400,
            detail=f"不允许的表名: {table_name}，允许的表: {', '.join(sorted(ALLOWED_TABLE_NAMES))}"
        )
    return table_name


def _get_pg_connection():
    import psycopg
    return psycopg.connect(
        host=settings.POSTGRES_HOST,
        port=settings.POSTGRES_PORT,
        user=settings.POSTGRES_USER,
        password=settings.POSTGRES_PASSWORD,
        dbname=settings.POSTGRES_DATABASE,
    )


@router.get("/query", response_model=DatabaseQueryResponse)
async def query_data(
    table_name: str = "material_data",
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    search: Optional[str] = None
):
    """
    查询数据库中的材料数据

    - **table_name**: 表名（默认 material_data）
    - **page**: 页码（从1开始）
    - **page_size**: 每页条数（1-100）
    - **search**: 搜索关键词（可选，搜索标题和作者）
    """
    table_name = _validate_table_name(table_name)

    try:
        conn = _get_pg_connection()

        with conn.cursor() as cursor:
            base_query = f'SELECT * FROM "{table_name}"'
            count_query = f'SELECT COUNT(*) as total FROM "{table_name}"'

            where_clause = ""
            params = []

            if search:
                where_clause = " WHERE title LIKE %s OR authors LIKE %s"
                search_term = f"%{search}%"
                params.extend([search_term, search_term])

            query_with_where = base_query + where_clause
            count_with_where = count_query + where_clause

            cursor.execute(count_with_where, params)
            total = cursor.fetchone()["total"]

            offset = (page - 1) * page_size
            paginated_query = f'{query_with_where} ORDER BY id DESC LIMIT %s OFFSET %s'

            cursor.execute(paginated_query, params + [page_size, offset])
            columns = [desc[0] for desc in cursor.description]
            data = [dict(zip(columns, row)) for row in cursor.fetchall()]

        conn.close()

        return DatabaseQueryResponse(
            status="success",
            table_name=table_name,
            total_count=total,
            data=data,
            page=page,
            page_size=page_size
        )

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"数据库查询错误: {str(e)}")


@router.get("/tables")
async def list_tables():
    """获取数据库中所有表"""
    try:
        conn = _get_pg_connection()

        with conn.cursor() as cursor:
            cursor.execute(
                "SELECT table_name FROM information_schema.tables "
                "WHERE table_schema = 'public' ORDER BY table_name"
            )
            tables = [row[0] for row in cursor.fetchall()]

        conn.close()

        return {
            "status": "success",
            "database": settings.POSTGRES_DATABASE,
            "tables": tables,
            "count": len(tables)
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取表列表失败: {str(e)}")


@router.get("/table-schema/{table_name}")
async def get_table_schema(table_name: str):
    """获取指定表的结构"""
    table_name = _validate_table_name(table_name)

    try:
        conn = _get_pg_connection()

        with conn.cursor() as cursor:
            cursor.execute(
                "SELECT column_name, data_type, is_nullable, column_default "
                f'FROM information_schema.columns WHERE table_name = %s '
                "ORDER BY ordinal_position",
                [table_name]
            )
            columns = [dict(zip([desc[0] for desc in cursor.description], row))
                       for row in cursor.fetchall()]

            cursor.execute(f'SELECT COUNT(*) as count FROM "{table_name}"')
            row_count = cursor.fetchone()["count"]

        conn.close()

        return {
            "status": "success",
            "table_name": table_name,
            "row_count": row_count,
            "columns": columns
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取表结构失败: {str(e)}")
