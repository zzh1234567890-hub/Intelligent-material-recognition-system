-- ============================================
-- 智能材料数据识别系统 - 数据库建表脚本
-- ============================================
-- 使用说明：
-- 1. 确保 MySQL 服务已启动
-- 2. 使用 MySQL 客户端执行此脚本
-- 3. 数据库将自动创建（如果不存在）
-- 
-- 执行方式：
--   mysql -u root -p < create_tables.sql
-- 或在 MySQL 命令行中：
--   source d:/nnnnnnnnew_try/sql/create_tables.sql
-- ============================================

-- 设置字符集
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ============================================
-- 1. 创建数据库
-- ============================================
CREATE DATABASE IF NOT EXISTS `material_db` 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

USE `material_db`;

-- ============================================
-- 2. 创建材料数据表
-- ============================================
DROP TABLE IF EXISTS `material_data`;

CREATE TABLE `material_data` (
    -- 主键
    `id` INT AUTO_INCREMENT PRIMARY KEY COMMENT '自增主键',
    
    -- 核心字段
    `identifier` VARCHAR(100) NOT NULL DEFAULT '' COMMENT '唯一标识符（如：zhang2021spalling）',
    `type` VARCHAR(50) NOT NULL DEFAULT '' COMMENT '文档类型（article/patent/book 等）',
    `title` TEXT COMMENT '标题',
    `authors` TEXT COMMENT '作者列表',
    `journal` VARCHAR(200) DEFAULT '' COMMENT '期刊/来源名称',
    `volume` VARCHAR(20) DEFAULT '' COMMENT '卷号',
    `issue` VARCHAR(20) DEFAULT '' COMMENT '期号',
    `pages` VARCHAR(50) DEFAULT '' COMMENT '页码范围',
    `year` CHAR(4) DEFAULT '' COMMENT '出版年份',
    `publisher` VARCHAR(200) DEFAULT '' COMMENT '出版社',
    `doi` VARCHAR(200) DEFAULT '' COMMENT 'DOI 数字对象标识符',
    `abstract` TEXT COMMENT '摘要/备注',
    
    -- 系统字段
    `source_file` VARCHAR(500) DEFAULT '' COMMENT '来源文件名',
    `uploaded_by` VARCHAR(100) DEFAULT NULL COMMENT '上传用户（预留）',
    `session_id` VARCHAR(100) DEFAULT NULL COMMENT '处理会话 ID',
    
    -- 时间戳
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    
    -- 索引优化
    UNIQUE KEY `uk_identifier` (`identifier`),
    KEY `idx_type` (`type`),
    KEY `idx_year` (`year`),
    KEY `idx_journal` (`journal`(50)),
    KEY `idx_created_at` (`created_at`)
    
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='材料/文献数据表';

-- ============================================
-- 3. 验证表结构
-- ============================================
SELECT '表创建成功！' AS status;

DESCRIBE `material_data`;

SELECT CONCAT('总字段数：', COUNT(*)) AS column_count FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = 'material_db' AND TABLE_NAME = 'material_data';

SET FOREIGN_KEY_CHECKS = 1;

-- ============================================
-- 4. 示例数据（可选）
-- ============================================
-- 如需插入测试数据，取消以下注释：
/*
INSERT INTO `material_data` 
(`identifier`, `type`, `title`, `authors`, `journal`, `volume`, `issue`, `pages`, `year`, `publisher`, `doi`, `abstract`, `source_file`) 
VALUES 
('zhang2021spalling', 'article', 'Spalling resistance and mechanical properties of strain-hardening ultra-high performance concrete at elevated temperature', 'Zhang, Dong and Liu, Yuchen and Tan, Kang Hai', 'Construction and Building Materials', '266', '', '120961', '2021', 'Elsevier', '10.1016/j.conbuildmat.2020.120961', 'In addition to mechanical testing, the article also conducted gas permeability tests', 'test.pdf');

SELECT '示例数据已插入' AS status;
SELECT * FROM `material_data` LIMIT 1;
*/

-- ============================================
-- 完成
-- ============================================
SELECT '✅ 数据库初始化完成！' AS message;
SELECT '数据库：material_db' AS database_info;
SELECT '表：material_data' AS table_info;
SELECT CONCAT('字符集：', @@character_set_database) AS charset_info;
