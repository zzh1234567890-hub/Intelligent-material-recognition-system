import os
from pydantic_settings import BaseSettings
from functools import lru_cache


class Settings(BaseSettings):
    """应用全局配置"""

    # 应用基础设置
    APP_NAME: str = "智能识别爬取系统"
    APP_VERSION: str = "5.0.0"
    DEBUG: bool = False

    # 服务器设置
    HOST: str = "0.0.0.0"
    PORT: int = 8008

    # 文件上传设置
    UPLOAD_DIR: str = "./uploads"
    OUTPUT_DIR: str = "./output"
    MAX_FILE_SIZE: int = 50 * 1024 * 1024  # 50MB
    ALLOWED_EXTENSIONS: list = [".pdf", ".docx", ".doc", ".md", ".markdown"]

    # DeepSeek LLM 设置 (用于数据提取)
    DEEPSEEK_API_KEY: str = ""
    DEEPSEEK_API_URL: str = "https://api.deepseek.com/v1/chat/completions"
    DEEPSEEK_MODEL: str = "deepseek-v4-flash"

    # 多模态 AI 设置 (通义千问 Qwen-VL, 用于 PDF 视觉解析)
    QWEN_API_KEY: str = ""
    QWEN_MODEL: str = "qwen-vl-max"

    # 多模态增强开关 (True=对复杂页面用Qwen-VL增强)
    MULTIMODAL_ENHANCEMENT: bool = True
    # 多模态增强阈值 (pdfplumber提取的表格数低于此值时触发增强)
    MULTIMODAL_THRESHOLD_TABLES: int = 2

    # PDFFigures 2.0 设置 (用于从 PDF 提取与 test_result 相关的图表)
    PDFFIGURES_JAVA_EXE: str = ""
    PDFFIGURES_JAR_PATH: str = ""
    PDFFIGURES_DPI: int = 300
    PDFFIGURES_TIMEOUT: int = 180
    PDFFIGURES_SAVE_ALL: bool = False

    # MySQL 数据库设置
    MYSQL_HOST: str = "localhost"
    MYSQL_PORT: int = 3306
    MYSQL_USER: str = "root"
    MYSQL_PASSWORD: str = ""
    MYSQL_DATABASE: str = "material_db"
    MYSQL_CHARSET: str = "utf8mb4"

    # PostgreSQL 数据库设置
    POSTGRES_HOST: str = "localhost"
    POSTGRES_PORT: int = 5432
    POSTGRES_USER: str = "postgres"
    POSTGRES_PASSWORD: str = "postgres"
    POSTGRES_DATABASE: str = "material_db"

    # 数据库类型选择（mysql 或 postgresql）
    DATABASE_TYPE: str = "postgresql"

    # CORS 设置
    CORS_ORIGINS: list = ["*"]

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


@lru_cache()
def get_settings() -> Settings:
    """获取配置单例"""
    return Settings()
