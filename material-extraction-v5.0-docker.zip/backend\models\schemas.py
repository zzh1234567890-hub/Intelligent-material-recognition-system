# 定义响应模型
from pydantic import BaseModel
from typing import Optional, List, Dict, Any


class DocumentUploadResponse(BaseModel):
    """文档上传响应"""
    status: str
    message: str
    file_name: str
    file_type: Optional[str] = None
    content_length: int = 0
    session_id: str = ""


class DataPreviewResponse(BaseModel):
    """数据预览响应（支持v2多表）"""
    status: str
    total: int
    preview_items: List[Dict[str, Any]]
    summary: Dict[str, Any]
    session_id: str
    tables_with_data: int = 0
    is_multi_table: bool = False
    figures: List[Dict[str, Any]] = []


class ConfirmWriteResponse(BaseModel):
    """确认写入响应（支持v2多表多Sheet）"""
    status: str
    message: str
    written_count: int
    excel_path: str
    data_sample: List[Dict[str, Any]] = []
    skipped_duplicates: int = 0
    sheets_written: int = 0


class UploadToMySQLResponse(BaseModel):
    """数据库上传响应（支持v2多表PostgreSQL）"""
    status: str
    message: str
    success_count: int
    failed_count: int
    total_count: int
    skipped_duplicates: int = 0
    table_name: str = ""
    errors: List[Dict[str, Any]] = []
    tables_uploaded: int = 0


class DatabaseQueryResponse(BaseModel):
    """数据库查询响应"""
    status: str
    table_name: str
    total_count: int
    data: List[Dict[str, Any]]
    page: int
    page_size: int


class ErrorResponse(BaseModel):
    """错误响应"""
    status: str = "error"
    error_code: str
    message: str
    details: Optional[str] = None


class HealthCheckResponse(BaseModel):
    status: str
    app_version: str
    mysql_status: str
    llm_status: str
    database_type: str = "postgresql"


class FigureExtractionResponse(BaseModel):
    """图表提取响应"""
    status: str
    message: str
    total_figures: int
    test_data_figures: int
    figures: List[Dict[str, Any]]
    extraction_time_seconds: float = 0.0
