import os
import re
import json
import shutil
import subprocess
import time
from pathlib import Path
from typing import Optional, List, Dict, Any


class PDFFiguresExtractor:
    """
    PDFFigures 2.0 图表提取器

    使用 OpenJDK 17 + pdffigures2.jar 从学术论文 PDF 中提取图表，
    并根据 test_result_group 表的参数关键词过滤出与试验数据相关的图表。

    用法:
        extractor = PDFFiguresExtractor()

        # 单个 PDF 提取
        result = extractor.extract_pdf("/path/to/paper.pdf")

        # 批量目录提取
        result = extractor.extract_directory("/path/to/pdfs/")

        # 指定输出目录
        extractor = PDFFiguresExtractor(output_dir="/custom/output/figures")

        # 获取提取结果
        for fig in result:
            print(fig["file"], fig["caption"], fig["is_test_data"])
    """

    TEST_RESULT_KEYWORDS = [
        re.compile(r"\bcompressive\s+strength\b", re.IGNORECASE),
        re.compile(r"\btensile\s+strength\b", re.IGNORECASE),
        re.compile(r"\bflexural\s+strength\b", re.IGNORECASE),
        re.compile(r"\bsplitting\s+tensile\b", re.IGNORECASE),
        re.compile(r"\bsplit[\s-]?tensile\b", re.IGNORECASE),
        re.compile(r"\belastic\s+modulus\b", re.IGNORECASE),
        re.compile(r"\bmodulus\s+of\s+elasticity\b", re.IGNORECASE),
        re.compile(r"\bpeak\s+strain\b", re.IGNORECASE),
        re.compile(r"\bstress[\s-]?strain\b", re.IGNORECASE),
        re.compile(r"\bmass\s+loss\b", re.IGNORECASE),
        re.compile(r"\bresidual\s+strength\b", re.IGNORECASE),
        re.compile(r"\bretained\s+strength\b", re.IGNORECASE),
        re.compile(r"\brelative\s+dynamic\s+elastic\b", re.IGNORECASE),
        re.compile(r"\bspalling\b", re.IGNORECASE),
        re.compile(r"\bfire\s+resistance\b", re.IGNORECASE),
        re.compile(r"\bstrength\b", re.IGNORECASE),
        re.compile(r"\b抗压\b"),
        re.compile(r"\b抗拉\b"),
        re.compile(r"\b抗弯\b"),
        re.compile(r"\b劈裂\b"),
        re.compile(r"\b弹性模量\b"),
        re.compile(r"\b峰值应变\b"),
        re.compile(r"\b应力.*应变\b"),
        re.compile(r"\b质量损失\b"),
        re.compile(r"\b残余强度\b"),
        re.compile(r"\b爆裂\b"),
    ]

    EXCLUDE_KEYWORDS = [
        re.compile(r"\bSEM\b", re.IGNORECASE),
        re.compile(r"\bTEM\b", re.IGNORECASE),
        re.compile(r"\bXRD\b", re.IGNORECASE),
        re.compile(r"\bX-ray\b", re.IGNORECASE),
        re.compile(r"\bmicrograph\b", re.IGNORECASE),
        re.compile(r"\bmicrostructure\b", re.IGNORECASE),
        re.compile(r"\bmorphology\b", re.IGNORECASE),
        re.compile(r"\bexperimental\s+setup\b", re.IGNORECASE),
        re.compile(r"\bflow\s+chart\b", re.IGNORECASE),
        re.compile(r"\bflowchart\b", re.IGNORECASE),
        re.compile(r"\bschematic\b", re.IGNORECASE),
        re.compile(r"\bapparatus\b", re.IGNORECASE),
        re.compile(r"\bTGA\b", re.IGNORECASE),
        re.compile(r"\bDTA\b", re.IGNORECASE),
        re.compile(r"\bDSC\b", re.IGNORECASE),
        re.compile(r"\bXPS\b", re.IGNORECASE),
        re.compile(r"\bFTIR\b", re.IGNORECASE),
        re.compile(r"\bEDS\b", re.IGNORECASE),
        re.compile(r"\bEDX\b", re.IGNORECASE),
    ]

    def __init__(
        self,
        java_exe: Optional[str] = None,
        jar_path: Optional[str] = None,
        output_dir: Optional[str] = None,
        dpi: int = 300,
        timeout: int = 180,
        save_all: bool = False,
    ):
        """
        Args:
            java_exe: Java 可执行文件路径，默认自动检测
            jar_path: pdffigures2.jar 路径，默认自动检测
            output_dir: 图表输出目录，默认 ./output/figures
            dpi: 渲染 DPI，默认 300
            timeout: 单个 PDF 处理超时（秒），默认 180
            save_all: 是否保存所有图表（不过滤），默认 False
        """
        self.dpi = dpi
        self.timeout = timeout
        self.save_all = save_all

        if java_exe:
            self.java_exe = java_exe
        else:
            self.java_exe = self._detect_java()

        if jar_path:
            self.jar_path = jar_path
        else:
            self.jar_path = self._detect_jar()

        if output_dir:
            self.output_dir = Path(output_dir)
        else:
            try:
                from backend.config import get_settings
                settings = get_settings()
                self.output_dir = Path(settings.OUTPUT_DIR) / "figures"
            except Exception:
                self.output_dir = Path("./output/figures")

        self.output_dir.mkdir(parents=True, exist_ok=True)

        self._last_results: List[Dict[str, Any]] = []

    @staticmethod
    def _detect_java() -> str:
        import shutil as _sh
        java = _sh.which("java")
        if java:
            return java

        candidates = [
            Path(__file__).resolve().parent.parent.parent / "tools" / "jdk" / "jdk-17.0.2" / "bin" / "java.exe",
            Path("C:/Program Files/Java/jdk-17/bin/java.exe"),
            Path("C:/Program Files/Eclipse Adoptium/jdk-17/bin/java.exe"),
        ]
        for c in candidates:
            if c.exists():
                return str(c)

        return "java"

    @staticmethod
    def _detect_jar() -> str:
        local = Path(__file__).resolve().parent.parent.parent / "tools" / "pdffigures2" / "pdffigures2.jar"
        if local.exists():
            return str(local)
        return "pdffigures2.jar"

    def is_available(self) -> bool:
        """检查 Java 和 pdffigures2.jar 是否可用"""
        try:
            result = subprocess.run(
                [self.java_exe, "-version"],
                capture_output=True, text=True, timeout=10,
            )
            if result.returncode != 0:
                return False
        except Exception:
            return False

        if not Path(self.jar_path).exists():
            return False

        return True

    @staticmethod
    def is_test_data_figure(caption: str, fig_type: str = "") -> bool:
        """
        判断图表是否与 test_result_group 参数相关

        Args:
            caption: 图表标题
            fig_type: 图表类型 (Figure/Table)

        Returns:
            True 表示与试验数据相关
        """
        if not caption:
            return False
        for excl in PDFFiguresExtractor.EXCLUDE_KEYWORDS:
            if excl.search(caption):
                return False
        for kw in PDFFiguresExtractor.TEST_RESULT_KEYWORDS:
            if kw.search(caption):
                return True
        return False

    @staticmethod
    def extract_paper_code(pdf_name: str) -> str:
        """从 PDF 文件名提取论文编号，如 1_Zhang2021.pdf -> P_001"""
        m = re.match(r"(\d+)_", pdf_name)
        if m:
            return f"P_{int(m.group(1)):03d}"
        return "P_000"

    @staticmethod
    def resolve_paper_code(pdf_path: str, pdf_name: Optional[str] = None) -> Optional[str]:
        """
        从数据库或 Excel 中查找 PDF 对应的正确 paper_code

        策略:
        1. 从 PDF 首页提取标题文本
        2. 先在 material_data 表中模糊匹配
        3. 再在 Excel 文件中查找
        4. 匹配成功则返回 paper_code

        Args:
            pdf_path: PDF 文件路径
            pdf_name: PDF 文件名（可选）

        Returns:
            paper_code 或 None（查不到时）
        """
        try:
            import fitz
            doc = fitz.open(pdf_path)
            first_page_text = ""
            for page_num in range(min(2, len(doc))):
                first_page_text += doc[page_num].get_text()
            doc.close()
        except Exception:
            return None

        title_candidates = []
        for line in first_page_text.split("\n"):
            line = line.strip()
            if len(line) > 20 and len(line) < 300:
                title_candidates.append(line)
            if len(title_candidates) >= 5:
                break

        if not title_candidates:
            return None

        db_rows = PDFFiguresExtractor._fetch_db_titles()
        if db_rows:
            result = PDFFiguresExtractor._match_title(title_candidates, db_rows)
            if result:
                return result

        excel_rows = PDFFiguresExtractor._fetch_excel_titles()
        if excel_rows:
            result = PDFFiguresExtractor._match_title(title_candidates, excel_rows)
            if result:
                return result

        return None

    @staticmethod
    def _fetch_db_titles() -> List[tuple]:
        try:
            import psycopg
            from backend.config import get_settings
            settings = get_settings()
            conn = psycopg.connect(
                host=settings.POSTGRES_HOST,
                port=settings.POSTGRES_PORT,
                user=settings.POSTGRES_USER,
                password=settings.POSTGRES_PASSWORD,
                dbname=settings.POSTGRES_DATABASE,
            )
            cur = conn.cursor()
            cur.execute("SELECT paper_code, title FROM material_data")
            rows = cur.fetchall()
            conn.close()
            return rows
        except Exception:
            return []

    @staticmethod
    def _fetch_excel_titles() -> List[tuple]:
        try:
            from backend.config import get_settings
            settings = get_settings()
            from openpyxl import load_workbook
            excel_path = os.path.join(settings.OUTPUT_DIR, "material_data_v2.xlsx")
            if not os.path.exists(excel_path):
                return []
            wb = load_workbook(excel_path, read_only=True)
            if "material_data" not in wb.sheetnames:
                wb.close()
                return []
            sheet = wb["material_data"]
            rows = []
            headers = None
            for i, row in enumerate(sheet.iter_rows(values_only=True)):
                if i == 0:
                    headers = [str(c).lower() if c else "" for c in row]
                    continue
                if not headers:
                    continue
                code_idx = headers.index("paper_code") if "paper_code" in headers else -1
                title_idx = headers.index("title") if "title" in headers else -1
                if code_idx >= 0 and title_idx >= 0:
                    rows.append((row[code_idx], row[title_idx]))
            wb.close()
            return rows
        except Exception:
            return []

    @staticmethod
    def _match_title(title_candidates: List[str], db_rows: List[tuple]) -> Optional[str]:
        best_match = None
        best_score = 0

        for row in db_rows:
            db_code, db_title = row[0], row[1]
            if not db_title:
                continue
            for candidate in title_candidates:
                db_lower = db_title.lower().strip()
                cand_lower = candidate.lower().strip()
                common = sum(1 for w in cand_lower.split() if w in db_lower)
                score = common / max(1, len(cand_lower.split()))
                if score > best_score and score > 0.5:
                    best_score = score
                    best_match = db_code

        return best_match

    def _run_pdffigures2(self, pdf_path: str, output_dir: str) -> List[Dict]:
        """
        调用 pdffigures2.jar 提取单个 PDF 的所有图表

        Args:
            pdf_path: PDF 文件路径
            output_dir: 临时输出目录

        Returns:
            图表元数据列表
        """
        os.makedirs(output_dir, exist_ok=True)
        prefix = os.path.join(output_dir, "")

        cmd = [
            self.java_exe,
            "-Dsun.java2d.cmm=sun.java2d.cmm.kcms.KcmsServiceProvider",
            "-jar", self.jar_path,
            pdf_path,
            "-m", prefix,
            "-d", prefix,
            "-i", str(self.dpi),
            "-e",
        ]

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=self.timeout,
            )
            if result.returncode != 0:
                stderr_preview = (result.stderr or "")[:300]
                print(f"[PDFFigures2] ERROR exit code {result.returncode}: {stderr_preview}")
                return []
        except subprocess.TimeoutExpired:
            print(f"[PDFFigures2] TIMEOUT after {self.timeout}s: {pdf_path}")
            return []
        except Exception as e:
            print(f"[PDFFigures2] ERROR: {e}")
            return []

        pdf_stem = Path(pdf_path).stem
        json_path = os.path.join(output_dir, f"{pdf_stem}.json")
        if not os.path.exists(json_path):
            print(f"[PDFFigures2] No JSON output: {json_path}")
            return []

        with open(json_path, "r", encoding="utf-8", errors="replace") as f:
            try:
                data = json.load(f)
            except json.JSONDecodeError:
                print(f"[PDFFigures2] Invalid JSON: {json_path}")
                return []

        if isinstance(data, dict):
            data = [data]

        return data if isinstance(data, list) else []

    def extract_pdf(
        self,
        pdf_path: str,
        paper_code: Optional[str] = None,
        save_to: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        从单个 PDF 提取与 test_result 参数相关的图表

        Args:
            pdf_path: PDF 文件路径
            paper_code: 论文编号，默认从文件名自动提取
            save_to: 图片保存目录，默认使用 self.output_dir

        Returns:
            提取结果列表，每项包含:
            - file: 文件名
            - path: 相对路径
            - paper_code: 论文编号
            - source_pdf: 源 PDF 文件名
            - page: 页码 (0-based)
            - size: 文件大小 (bytes)
            - caption: 图表标题
            - fig_type: Figure/Table
            - name: 图表编号
            - is_test_data: 是否与试验数据相关
        """
        pdf_path = str(Path(pdf_path).resolve())
        if not os.path.exists(pdf_path):
            raise FileNotFoundError(f"PDF not found: {pdf_path}")

        pdf_name = os.path.basename(pdf_path)
        pdf_stem = Path(pdf_path).stem
        if not paper_code:
            paper_code = self.resolve_paper_code(pdf_path, pdf_name)
        if not paper_code:
            paper_code = self.extract_paper_code(pdf_name)

        out_dir = Path(save_to) if save_to else self.output_dir
        out_dir.mkdir(parents=True, exist_ok=True)

        temp_dir = out_dir / "_temp" / pdf_stem
        temp_dir.mkdir(parents=True, exist_ok=True)

        print(f"[PDFFigures2] Processing: {pdf_name} (paper_code={paper_code})")

        figures_data = self._run_pdffigures2(pdf_path, str(temp_dir))
        if not figures_data:
            print(f"[PDFFigures2] No figures extracted from {pdf_name}")
            self._cleanup_temp(temp_dir)
            return []

        saved_figures = []
        fig_counter = 0

        for fig in figures_data:
            caption = fig.get("caption", "") or ""
            fig_type = fig.get("figType", "Figure")
            render_url = fig.get("renderURL", "")
            name = fig.get("name", "")
            page = fig.get("page", -1)

            is_test = self.is_test_data_figure(caption, fig_type)

            if not self.save_all and not is_test:
                continue

            src_filename = os.path.basename(render_url) if render_url else None
            if not src_filename:
                continue

            src_path = os.path.join(str(temp_dir), src_filename)
            if not os.path.exists(src_path):
                continue

            fig_counter += 1
            dst_filename = f"{paper_code}_T{fig_counter}.png"
            dst_path = str(out_dir / dst_filename)
            shutil.copy2(src_path, dst_path)

            file_size = os.path.getsize(dst_path)
            saved_figures.append({
                "file": dst_filename,
                "path": f"./output/figures/{dst_filename}",
                "paper_code": paper_code,
                "source_pdf": pdf_name,
                "page": page,
                "size": file_size,
                "caption": caption[:300],
                "fig_type": fig_type,
                "name": name,
                "is_test_data": is_test,
            })
            safe_caption = caption[:80].encode("ascii", errors="replace").decode("ascii")
            print(f"  [SAVE] {dst_filename} ({fig_type} {name}, page {page}) - {safe_caption}")

        self._cleanup_temp(temp_dir)
        self._last_results.extend(saved_figures)
        return saved_figures

    def extract_directory(
        self,
        directory: str,
        recursive: bool = True,
    ) -> List[Dict[str, Any]]:
        """
        从目录中批量提取 PDF 图表

        Args:
            directory: PDF 文件目录
            recursive: 是否递归子目录，默认 True

        Returns:
            所有提取结果列表
        """
        directory = Path(directory).resolve()
        if not directory.exists():
            raise FileNotFoundError(f"Directory not found: {directory}")

        if recursive:
            pdfs = sorted(directory.rglob("*.pdf"))
        else:
            pdfs = sorted(directory.glob("*.pdf"))

        if not pdfs:
            print(f"[PDFFigures2] No PDF files found in {directory}")
            return []

        print(f"[PDFFigures2] Found {len(pdfs)} PDF files in {directory}")

        all_figures = []
        t0 = time.time()

        for pdf_path in pdfs:
            try:
                figures = self.extract_pdf(str(pdf_path))
                all_figures.extend(figures)
            except Exception as e:
                print(f"[PDFFigures2] ERROR processing {pdf_path.name}: {e}")

        elapsed = time.time() - t0
        print(f"[PDFFigures2] Batch done: {len(all_figures)} figures from {len(pdfs)} PDFs ({elapsed:.1f}s)")

        summary_path = str(self.output_dir / "extraction_summary.json")
        self._save_summary(summary_path, len(pdfs), all_figures, elapsed)

        return all_figures

    def extract_from_bytes(
        self,
        pdf_bytes: bytes,
        filename: str,
        paper_code: Optional[str] = None,
        save_to: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        从内存中的 PDF 字节流提取图表

        适用于 API 上传场景：先保存到临时文件，再调用 pdffigures2 提取。

        Args:
            pdf_bytes: PDF 文件原始字节
            filename: 原始文件名（用于生成 paper_code 和 JSON 文件名）
            paper_code: 论文编号，默认从文件名自动提取
            save_to: 图片保存目录

        Returns:
            提取结果列表
        """
        import tempfile

        out_dir = Path(save_to) if save_to else self.output_dir
        temp_pdf_dir = out_dir / "_temp" / "_uploads"
        temp_pdf_dir.mkdir(parents=True, exist_ok=True)

        safe_name = re.sub(r'[^\w\-.]', '_', filename)
        if not safe_name.lower().endswith('.pdf'):
            safe_name += '.pdf'
        temp_pdf_path = str(temp_pdf_dir / safe_name)

        if not paper_code:
            paper_code = self.extract_paper_code(filename)

        with open(temp_pdf_path, "wb") as f:
            f.write(pdf_bytes)

        try:
            if not paper_code or paper_code == "P_000":
                paper_code = self.resolve_paper_code(temp_pdf_path, filename) or paper_code
            result = self.extract_pdf(
                temp_pdf_path,
                paper_code=paper_code,
                save_to=save_to,
            )
        finally:
            try:
                os.remove(temp_pdf_path)
            except OSError:
                pass
            try:
                if temp_pdf_dir.exists() and not any(temp_pdf_dir.iterdir()):
                    temp_pdf_dir.rmdir()
            except OSError:
                pass

        return result

    def get_last_results(self) -> List[Dict[str, Any]]:
        """获取最近一次提取的结果"""
        return self._last_results

    def clear_results(self):
        """清空缓存的结果"""
        self._last_results = []

    def _save_summary(self, path: str, total_pdfs: int, figures: list, elapsed: float):
        summary = {
            "total_pdfs": total_pdfs,
            "total_test_data_figures": len(figures),
            "extraction_time_seconds": round(elapsed, 1),
            "figures": figures,
        }
        with open(path, "w", encoding="utf-8") as f:
            json.dump(summary, f, ensure_ascii=False, indent=2)

    @staticmethod
    def _cleanup_temp(temp_dir: Path):
        """清理临时文件"""
        try:
            if temp_dir.exists():
                shutil.rmtree(str(temp_dir), ignore_errors=True)
        except Exception:
            pass
