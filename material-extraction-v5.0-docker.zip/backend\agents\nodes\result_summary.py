"""
结果汇总节点

整合所有工具执行的结果，生成最终响应给用户
"""

from typing import Dict, Any
from backend.agents.state import AgentState, update_state_timestamp, get_state_summary


RESULT_SUMMARY_PROMPT = """你是一个智能助手总结专家。请根据以下处理结果，生成一个友好、清晰的中文回复给用户。

## 用户原始请求：
{user_input}

## 用户意图：
{intent}

## 处理过程与结果：

### 1. 文档解析
- 文件数量：{file_count}
- 文档类型：{doc_type}
- 内容长度：{content_length} 字符

### 2. 数据提取
- 提取记录数：{extracted_count}
- 数据预览：
{preview_summary}

### 3. Excel 导出
- Excel 文件：{excel_status}
- 写入条数：{written_count}
- 文件路径：{excel_path}

### 4. MySQL 上传
- 上传状态：{mysql_status}
- 成功条数：{success_count}
- 目标表：{table_name}

## 要求：
1. 用简洁明了的中文总结处理结果
2. 突出关键数字和成果
3. 如果有错误或警告，要明确指出
4. 提供下一步建议（如果适用）
5. 使用 emoji 增加可读性
6. 控制在 200 字以内（除非用户要求详细）

## 输出格式：
直接输出回复文本，不需要 JSON 或其他格式。"""


def result_summary_node(state: AgentState) -> AgentState:
    """
    结果汇总节点
    
    功能：
    1. 收集所有工具执行的完整结果
    2. 整理关键数据和统计信息
    3. 调用 LLM 生成友好的最终回复
    4. 更新状态为 completed/failed
    5. 返回最终的 AgentState
    
    这是工作流的最后一个节点，
    负责将技术性的执行结果转换为用户友好的消息。
    
    Args:
        state: 当前 Agent 状态（应包含所有工具执行结果）
        
    Returns:
        AgentState: 最终状态（包含 final_response 和 status）
    """
    print("\n" + "="*60)
    print("📝 [节点4] 结果汇总")
    print("="*60)
    
    try:
        # 检查是否有严重错误
        if state.get("error_info") and state.get("status") == "failed":
            response = _generate_error_response(state)
        else:
            # 正常情况：生成成功响应
            response = _generate_success_response(state)
        
        # 更新最终状态
        state["final_response"] = response
        state["status"] = "completed" if not state.get("error_info") else "failed"
        state = update_state_timestamp(state)
        
        # 打印最终结果
        _print_final_result(state)
        
        return state
        
    except Exception as e:
        error_msg = f"结果汇总失败: {str(e)}"
        print(f"❌ {error_msg}")
        
        fallback_response = (
            f"✅ 处理已完成！\n\n"
            f"• 提取数据：{len(state.get('extracted_data', []))} 条\n"
            f"• Excel 文件：{state.get('excel_path', '未生成')}\n"
            f"• MySQL 上传：{'已完成' if state.get('mysql_result') else '未上传'}\n\n"
            f"💡 详细信息请查看系统日志。"
        )
        
        state["final_response"] = fallback_response
        state["status"] = "completed"
        state = update_state_timestamp(state)
        
        return state


def _generate_success_response(state: AgentState) -> str:
    """生成成功的响应消息"""
    intent = state.get("user_intent", {})
    tool_results = state.get("tool_results", {})
    
    # 准备统计数据
    stats = _collect_statistics(state)
    
    # 构建提示词
    prompt = RESULT_SUMMARY_PROMPT.format(
        user_input=state.get("user_input", ""),
        intent=_format_intent(intent),
        file_count=state.get("file_count", 0),
        doc_type=state.get("document_type", "未知"),
        content_length=len(state.get("document_content", "")),
        extracted_count=len(state.get("extracted_data", [])),
        preview_summary=_format_preview_summary(state.get("preview_data", {})),
        excel_status="已生成 ✓" if state.get("excel_path") else "未生成",
        written_count=state.get("written_data_count", 0),
        excel_path=state.get("excel_path", "-"),
        mysql_status="已上传 ✓" if state.get("mysql_result") else "未上传",
        success_count=state.get("mysql_result", {}).get("success", 0),
        table_name=state.get("mysql_table_name", "-")
    )
    
    # 调用 LLM 生成响应
    try:
        llm_client = _get_llm_client()
        response = llm_client.generate(
            messages=[{"role": "user", "content": prompt}],
            temperature=0.7,
            max_tokens=500
        )
        
        return response.choices[0].message.content.strip()
        
    except Exception as e:
        print(f"⚠️ LLM 生成响应失败，使用模板响应: {e}")
        return _generate_template_response(stats)


def _generate_error_response(state: AgentState) -> str:
    """生成错误响应"""
    error = state.get("error_info", {})
    
    extracted_count = len(state.get("extracted_data", []))
    has_partial_data = extracted_count > 0
    
    response_parts = [
        "⚠️ 处理过程中遇到问题\n",
        f"**错误位置**: {error.get('step', '未知')}",
        f"**错误类型**: {error.get('error_type', '未知')}",
        f"**错误信息**: {error.get('message', '未知错误')}"
    ]
    
    if has_partial_data:
        response_parts.extend([
            "\n\n---\n\n",
            "✅ **部分结果仍可用**:",
            f"• 已提取数据：{extracted_count} 条"
        ])
        
        if state.get("excel_path"):
            response_parts.append(f"• Excel 文件：{state['excel_path']}")
    
    response_parts.append("\n\n💡 建议：检查文件格式是否正确，或联系管理员获取帮助。")
    
    return "\n".join(response_parts)


def _collect_statistics(state: AgentState) -> Dict[str, Any]:
    """收集统计信息"""
    return {
        "file_count": state.get("file_count", 0),
        "extracted_count": len(state.get("extracted_data", [])),
        "has_excel": bool(state.get("excel_path")),
        "written_count": state.get("written_data_count", 0),
        "mysql_uploaded": bool(state.get("mysql_result")),
        "mysql_success": state.get("mysql_result", {}).get("success", 0),
        "errors": bool(state.get("error_info"))
    }


def _format_intent(intent: Dict[str, Any]) -> str:
    """格式化意图信息"""
    if not intent:
        return "未识别到具体意图"
    
    action_map = {
        "extract_upload": "提取并上传数据",
        "extract_only": "仅提取数据",
        "query_data": "查询数据",
        "preview_data": "预览内容"
    }
    
    action_text = action_map.get(intent.get("action"), intent.get("action", "未知"))
    confidence = intent.get("confidence", 0)
    
    return f"{action_text} (置信度: {confidence:.0%})"


def _format_preview_summary(preview_data: Dict[str, Any]) -> str:
    """格式化预览数据摘要"""
    if not preview_data:
        return "无预览数据"
    
    total = preview_data.get("total", 0)
    summary = preview_data.get("summary", {})
    
    parts = [f"共 {total} 条记录"]
    
    if summary:
        for key, value in summary.items():
            parts.append(f"- {key}: {value}")
    
    return "\n".join(parts[:5]) if parts else "无详细信息"


def _generate_template_response(stats: Dict[str, Any]) -> str:
    """生成基于模板的响应（LLM 不可用时的后备方案）"""
    parts = [
        "✅ **处理完成！**\n",
        f"📄 **文档处理**: 解析了 {stats['file_count']} 个文件",
        f"📊 **数据提取**: 成功提取 {stats['extracted_count']} 条材料数据"
    ]
    
    if stats["has_excel"]:
        parts.append(f"📁 **Excel 导出**: 已生成（{stats['written_count']} 条数据）")
    
    if stats["mysql_uploaded"]:
        parts.append(f"💾 **数据库上传**: 成功上传 {stats['mysql_success']} 条记录")
    
    if stats["errors"]:
        parts.append("\n⚠️ 部分步骤遇到小问题，但主要功能已完成。")
    
    parts.append("\n\n💡 您可以随时查询数据库查看详细数据。")
    
    return "\n".join(parts)


def _print_final_result(state: AgentState):
    """打印最终结果"""
    summary = get_state_summary(state)
    
    print(f"\n{'='*60}")
    print(f"🎉 处理完成！")
    print(f"{'='*60}")
    print(f"\n📋 会话 ID: {summary['session_id']}")
    print(f"📊 最终状态: {summary['status']}")
    print(f"📈 进度: {summary['current_step']}")
    print(f"📄 文件数: {summary['file_count']}")
    print(f"🔍 提取数: {summary['extracted_count']}")
    print(f"📁 Excel: {'已生成' if summary['has_excel'] else '未生成'}")
    print(f"💾 MySQL: {summary['mysql_status']}")
    
    if state.get("error_info"):
        print(f"\n⚠️ 错误: {state['error_info'].get('message', '')}")
    
    print(f"\n{'='*60}")
    print("📝 最终响应:")
    print("-"*60)
    print(state.get("final_response", ""))
    print("-"*60)
    print(f"{'='*60}\n")


def _get_llm_client():
    """获取 LLM 客户端"""
    from backend.utils.llm_client import create_deepseek_client
    return create_deepseek_client()
