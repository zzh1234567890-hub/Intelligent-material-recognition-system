@echo off
chcp 65001 >nul
echo ========================================
echo   一键创建PostgreSQL表结构
echo ========================================
echo.

set PGPASSWORD=postgres

echo [STEP 1] 创建数据库（如果不存在）...
psql -U postgres -h localhost -p 5432 -c "CREATE DATABASE material_db;" 2>nul
if errorlevel 1 (
    echo     数据库已存在或创建失败（忽略）
)

echo.
echo [STEP 2] 创建表结构...
psql -U postgres -h localhost -p 5432 -d material_db -f sql\create_tables_v2.sql

if errorlevel 1 (
    echo.
    echo [ERROR] 建表失败！请检查：
    echo   1. PostgreSQL服务是否启动
    echo   2. 用户名密码是否正确
    echo   3. SQL文件是否存在
    pause
    exit /b 1
)

echo.
echo ========================================
echo   ✅ 表结构创建完成！
echo ========================================
echo.
echo 现在可以重新尝试上传数据到数据库了。
pause
