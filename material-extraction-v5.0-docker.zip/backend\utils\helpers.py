import os
import uuid
from datetime import datetime
from typing import Optional


def generate_session_id() -> str:
    """生成唯一的会话ID"""
    return str(uuid.uuid4())


def generate_filename(original_name: str) -> str:
    """生成安全的文件名"""
    ext = os.path.splitext(original_name)[1]
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    unique_id = uuid.uuid4().hex[:8]
    return f"{timestamp}_{unique_id}{ext}"


def validate_file_extension(filename: str, allowed_extensions: list) -> bool:
    """验证文件扩展名"""
    ext = os.path.splitext(filename)[1].lower()
    return ext in [e.lower() for e in allowed_extensions]


def format_file_size(size_bytes: int) -> str:
    """格式化文件大小显示"""
    for unit in ['B', 'KB', 'MB', 'GB']:
        if size_bytes < 1024.0:
            return f"{size_bytes:.2f} {unit}"
        size_bytes /= 1024.0
    return f"{size_bytes:.2f} TB"


def sanitize_string(text: str, max_length: int = 1000) -> str:
    """清理和截断字符串"""
    if not text:
        return ""
    
    text = text.strip()
    if len(text) > max_length:
        text = text[:max_length] + "..."
    
    return text


class Timer:
    """简单的计时器工具类"""
    
    def __init__(self):
        self.start_time = None
        self.end_time = None
    
    def start(self):
        self.start_time = datetime.now()
        return self
    
    def stop(self):
        self.end_time = datetime.now()
        return self
    
    @property
    def elapsed(self) -> float:
        if self.start_time and self.end_time:
            return (self.end_time - self.start_time).total_seconds()
        elif self.start_time:
            return (datetime.now() - self.start_time).total_seconds()
        return 0.0
    
    def __str__(self):
        return f"{self.elapsed:.2f}s"
