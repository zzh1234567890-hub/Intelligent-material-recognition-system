import httpx
import base64
import time
from typing import Optional


class QwenVLClient:

    def __init__(
        self,
        api_key: str,
        model: str = "qwen-vl-max",
        base_url: str = "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions",
        timeout: float = 180.0,
        max_retries: int = 2,
    ):
        self.api_key = api_key
        self.model = model
        self.base_url = base_url
        self.timeout = timeout
        self.max_retries = max_retries

        if not api_key:
            raise ValueError("Qwen API Key cannot be empty")

    def analyze_image(
        self,
        image_bytes: bytes,
        prompt: str = "",
        max_tokens: int = 8192,
        temperature: float = 0.0,
    ) -> str:
        if not prompt:
            prompt = (
                "You are an expert in extracting data from academic paper PDFs about concrete, "
                "high-temperature experiments, fiber composites, and mechanical testing.\n\n"
                "Extract ALL content from this PDF page.\n\n"
                "Rules:\n"
                "1. Output ALL text content, preserving original structure and order\n"
                "2. For EVERY data table, output in Markdown format:\n"
                "   [Table N: caption]\n"
                "   | Col1 | Col2 | ... |\n"
                "   |------|------|-----|\n"
                "   | val1 | val2 | ... |\n"
                "3. For horizontally-arranged tables (columns = mixtures), TRANSPOSE so each mixture is a row\n"
                "4. Preserve ALL numeric values EXACTLY — no rounding, no approximation\n"
                "5. Preserve ALL units: MPa, GPa, mm, kg/m³, %, °C, μm, g/cm³\n"
                "6. Do NOT skip any rows or columns — include empty cells as blank\n"
                "7. Pay attention to superscripts/subscripts: kg/m³ not kg/m3, °C not C\n"
            )

        b64_image = base64.b64encode(image_bytes).decode("utf-8")

        messages = [
            {
                "role": "user",
                "content": [
                    {
                        "type": "image_url",
                        "image_url": {"url": f"data:image/png;base64,{b64_image}"},
                    },
                    {
                        "type": "text",
                        "text": prompt,
                    },
                ],
            }
        ]

        payload = {
            "model": self.model,
            "messages": messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
        }

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

        last_error = None
        for attempt in range(self.max_retries + 1):
            try:
                with httpx.Client(timeout=self.timeout) as _client:
                    resp = _client.post(
                        self.base_url,
                        json=payload,
                        headers=headers,
                    )
                    resp.raise_for_status()
                    data = resp.json()

                choices = data.get("choices", [])
                if choices:
                    message = choices[0].get("message", {})
                    content = message.get("content", "")
                    if isinstance(content, list):
                        text_parts = []
                        for item in content:
                            if isinstance(item, dict) and item.get("type") == "text":
                                text_parts.append(item.get("text", ""))
                            elif isinstance(item, str):
                                text_parts.append(item)
                        return "\n".join(text_parts)
                    return str(content)
                return ""

            except httpx.HTTPStatusError as e:
                error_detail = e.response.text if e.response else str(e)
                last_error = f"HTTP {e.response.status_code}: {error_detail}"
                if e.response.status_code == 429:
                    wait = 5 * (attempt + 1)
                    print(f"[Qwen-VL] Rate limited, waiting {wait}s...")
                    time.sleep(wait)
                    continue
                raise Exception(f"Qwen-VL API {last_error}")
            except httpx.TimeoutException as e:
                last_error = f"Timeout after {self.timeout}s"
                if attempt < self.max_retries:
                    wait = 3 * (attempt + 1)
                    print(f"[Qwen-VL] Timeout, retry {attempt+1}/{self.max_retries} in {wait}s...")
                    time.sleep(wait)
                    continue
                raise Exception(f"Qwen-VL API {last_error} (all retries exhausted)")
            except httpx.RequestError as e:
                last_error = str(e)
                if attempt < self.max_retries:
                    wait = 3 * (attempt + 1)
                    print(f"[Qwen-VL] Request error, retry {attempt+1}/{self.max_retries} in {wait}s...")
                    time.sleep(wait)
                    continue
                raise Exception(f"Qwen-VL API request error: {last_error}")
            except Exception as e:
                last_error = str(e)
                raise Exception(f"Qwen-VL API call failed: {last_error}")

        raise Exception(f"Qwen-VL API failed after {self.max_retries} retries: {last_error}")

    def test_connection(self) -> bool:
        try:
            from PIL import Image
            import io as _io

            dummy_img = Image.new("RGB", (100, 100), color="white")
            buf = _io.BytesIO()
            dummy_img.save(buf, format="PNG")
            result = self.analyze_image(
                image_bytes=buf.getvalue(),
                prompt="Reply OK",
                max_tokens=10,
            )
            return len(result.strip()) > 0
        except Exception as e:
            print(f"[Qwen-VL] Connection test failed: {e}")
            return False


def create_qwen_vl_client() -> Optional[QwenVLClient]:
    from backend.config import get_settings
    settings = get_settings()

    api_key = settings.QWEN_API_KEY
    if not api_key:
        print("[Qwen-VL] QWEN_API_KEY not configured, skipping multimodal enhancement")
        return None

    return QwenVLClient(
        api_key=api_key,
        model=settings.QWEN_MODEL,
    )
