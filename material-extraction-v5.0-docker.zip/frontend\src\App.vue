<template>
  <div class="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
    <!-- 顶部导航栏 -->
    <header class="bg-white/80 backdrop-blur-md border-b border-gray-200 sticky top-0 z-50">
      <div class="max-w-6xl mx-auto px-6 py-4">
        <div class="flex items-center justify-between">
          <!-- Logo 和标题 -->
          <div class="flex items-center space-x-3">
            <div class="w-10 h-10 bg-gradient-to-br from-primary-500 to-primary-700 rounded-xl flex items-center justify-center shadow-soft">
              <el-icon :size="22" color="white"><Document /></el-icon>
            </div>
            <div>
              <h1 class="text-xl font-bold text-gray-900">智能材料识别系统</h1>
              <p class="text-xs text-gray-500">Material Extraction System</p>
            </div>
          </div>

          <!-- 右侧状态 -->
          <div class="flex items-center space-x-4">
            <!-- 状态指示器 -->
            <div class="flex items-center space-x-2 px-3 py-1.5 bg-accent-50 rounded-full">
              <span class="w-2 h-2 bg-accent-500 rounded-full animate-pulse"></span>
              <span class="text-xs font-medium text-accent-700">系统就绪</span>
            </div>

            <!-- API 文档链接 -->
            <el-button 
              type="primary" 
              plain 
              size="small"
              @click="openDocs"
              class="!rounded-lg"
            >
              <el-icon><Link /></el-icon>
              API 文档
            </el-button>
          </div>
        </div>
      </div>
    </header>

    <!-- 主内容区域 -->
    <main class="max-w-6xl mx-auto px-6 py-8">
      <router-view />
    </main>

    <!-- 页脚 -->
    <footer class="border-t border-gray-200 bg-white/50 mt-16">
      <div class="max-w-6xl mx-auto px-6 py-6 text-center text-sm text-gray-500">
        <p>© 2026 智能材料识别系统 · Powered by DeepSeek LLM</p>
      </div>
    </footer>
  </div>
</template>

<script setup>
import { Document, Link } from '@element-plus/icons-vue'

const openDocs = () => {
  window.open('http://localhost:8008/docs', '_blank')
}
</script>
