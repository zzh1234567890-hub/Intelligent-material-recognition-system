"""
MySQL 数据库初始化脚本

用于：
1. 创建数据库（如果不存在）
2. 创建用户表（可选，如果需要认证功能）
3. 创建材料数据表结构
4. 初始化基础数据
"""

import pymysql
from typing import Optional
from backend.config import get_settings


class DatabaseInitializer:
    """
    数据库初始化工具
    
    提供一键式数据库准备功能，
    确保系统运行前所有必要的表和结构都已就绪。
    
    使用示例：
        initializer = DatabaseInitializer()
        initializer.initialize_all()  # 初始化所有内容
        
        # 或单独执行：
        # initializer.create_database()
        # initializer.create_user_table()
        # initializer.create_material_table()
    """
    
    def __init__(self):
        settings = get_settings()
        
        self.host = settings.MYSQL_HOST
        self.port = settings.MYSQL_PORT
        self.user = settings.MYSQL_USER
        self.password = settings.MYSQL_PASSWORD
        self.database = settings.MYSQL_DATABASE
        self.charset = settings.MYSQL_CHARSET
    
    def get_connection(self, db_name: Optional[str] = None):
        """获取数据库连接（可选择连接到特定数据库或无数据库）"""
        return pymysql.connect(
            host=self.host,
            port=self.port,
            user=self.user,
            password=self.password,
            database=db_name,
            charset=self.charset
        )
    
    def initialize_all(self) -> dict:
        """
        一键初始化所有数据库组件
        
        Returns:
            dict: 初始化结果 {
                'success': bool,
                'steps': list of results,
                'errors': list of errors
            }
        """
        results = []
        errors = []
        
        steps = [
            ("create_database", "创建数据库", self.create_database),
            ("create_material_table", "创建材料数据表", self.create_material_table),
            ("verify_structure", "验证表结构", self.verify_tables),
        ]
        
        print("\n" + "="*60)
        print("🗄️ MySQL 数据库初始化")
        print("="*60)
        
        for step_name, description, method in steps:
            try:
                print(f"\n▶️ {description}...")
                result = method()
                results.append({
                    "step": step_name,
                    "status": "success",
                    "result": result
                })
                print(f"✅ {description}完成")
                
            except Exception as e:
                error_msg = f"{description}失败: {str(e)}"
                errors.append(error_msg)
                print(f"❌ {error_msg}")
                results.append({
                    "step": step_name,
                    "status": "failed",
                    "error": str(e)
                })
        
        summary = {
            "success": len(errors) == 0,
            "total_steps": len(steps),
            "completed_steps": len(results) - len(errors),
            "failed_steps": len(errors),
            "results": results,
            "errors": errors
        }
        
        print("\n" + "="*60)
        if summary["success"]:
            print("🎉 数据库初始化全部成功！")
        else:
            print(f"⚠️ 部分步骤失败 ({summary['failed_steps']}/{summary['total_steps']})")
            for err in errors:
                print(f"   • {err}")
        print("="*60 + "\n")
        
        return summary
    
    def create_database(self) -> dict:
        """创建数据库（如果不存在）"""
        conn = self.get_connection(db_name=None)
        
        with conn.cursor() as cursor:
            cursor.execute(
                f"CREATE DATABASE IF NOT EXISTS `{self.database}` "
                f"CHARACTER SET {self.charset} COLLATE {self.charset}_unicode_ci"
            )
            
            cursor.execute(f"USE `{self.database}`")
            
            conn.commit()
            
            return {
                "database": self.database,
                "charset": self.charset,
                "status": "created_or_exists"
            }
    
    def create_material_table(self, dict) -> dict:
        """创建材料数据主表"""
        conn = self.get_connection(db_name=self.database)
        
        create_sql = f"""
        CREATE TABLE IF NOT EXISTS `material_data` (
            `id` INT AUTO_INCREMENT PRIMARY KEY COMMENT '自增主键',
            `identifier` VARCHAR(100) NOT NULL DEFAULT '' COMMENT '唯一标识符',
            `type` VARCHAR(50) NOT NULL DEFAULT '' COMMENT '文档类型',
            `title` TEXT COMMENT '标题',
            `authors` TEXT COMMENT '作者',
            `journal` VARCHAR(200) DEFAULT '' COMMENT '期刊/来源',
            `volume` VARCHAR(20) DEFAULT '' COMMENT '卷号',
            `issue` VARCHAR(20) DEFAULT '' COMMENT '期号',
            `pages` VARCHAR(50) DEFAULT '' COMMENT '页码',
            `year` CHAR(4) DEFAULT '' COMMENT '年份',
            `publisher` VARCHAR(200) DEFAULT '' COMMENT '出版社',
            `doi` VARCHAR(200) DEFAULT '' COMMENT 'DOI',
            `abstract` TEXT COMMENT '摘要/备注',
            
            -- 系统字段
            `source_file` VARCHAR(500) DEFAULT '' COMMENT '来源文件名',
            `uploaded_by` VARCHAR(100) DEFAULT NULL COMMENT '上传用户',
            `session_id` VARCHAR(100) DEFAULT NULL COMMENT '处理会话ID',
            
            -- 时间戳
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
            
            -- 索引
            UNIQUE KEY `uk_identifier` (`identifier`),
            KEY `idx_type` (`type`),
            KEY `idx_year` (`year`),
            KEY `idx_journal` (`journal`(50)),
            KEY `idx_created_at` (`created_at`)
            
        ) ENGINE=InnoDB DEFAULT CHARSET={self.charset} COLLATE={self.charset}_unicode_ci 
        COMMENT='材料/文献数据表'
        """
        
        with conn.cursor() as cursor:
            cursor.execute(create_sql)
            conn.commit()
            
            return {
                "table": "material_data",
                "columns": 17,
                "indexes": 5,
                "engine": "InnoDB",
                "charset": self.charset
            }
    
    def verify_tables(self) -> dict:
        """验证所有必要的表是否存在且结构正确"""
        conn = self.get_connection(db_name=self.database)
        
        required_tables = ["material_data"]
        verification_results = {}
        
        with conn.cursor() as cursor:
            cursor.execute("SHOW TABLES")
            existing_tables = [row[0] for row in cursor.fetchall()]
            
            for table in required_tables:
                exists = table in existing_tables
                
                if exists:
                    cursor.execute(f"DESCRIBE `{table}`")
                    columns = len(cursor.fetchall())
                    
                    cursor.execute(f"SELECT COUNT(*) FROM `{table}`")
                    row_count = cursor.fetchone()[0]
                    
                    verification_results[table] = {
                        "exists": True,
                        "columns": columns,
                        "row_count": row_count,
                        "status": "ok"
                    }
                else:
                    verification_results[table] = {
                        "exists": False,
                        "status": "missing"
                    }
        
        return verification_results


def test_mysql_connection() -> dict:
    """
    测试 MySQL 连接是否正常
    
    Returns:
        dict: 连接测试结果 {
            'connected': bool,
            'version': str,
            'database': str,
            'error': str or None
        }
    """
    from backend.config import get_settings
    
    settings = get_settings()
    
    try:
        conn = pymysql.connect(
            host=settings.MYSQL_HOST,
            port=settings.MYSQL_PORT,
            user=settings.MYSQL_USER,
            password=settings.MYSQL_PASSWORD,
            charset=settings.MYSQL_CHARSET,
            connect_timeout=5
        )
        
        with conn.cursor() as cursor:
            cursor.execute("SELECT VERSION()")
            version = cursor.fetchone()[0]
            
            cursor.execute("SELECT DATABASE()")
            current_db = cursor.fetchone()[0] or "(none)"
        
        conn.close()
        
        return {
            "connected": True,
            "version": version,
            "host": f"{settings.MYSQL_HOST}:{settings.MYSQL_PORT}",
            "user": settings.MYSQL_USER,
            "database": current_db,
            "error": None
        }
        
    except Exception as e:
        return {
            "connected": False,
            "version": None,
            "host": f"{settings.MYSQL_HOST}:{settings.MYSQL_PORT}",
            "user": settings.MYSQL_USER,
            "database": None,
            "error": str(e)
        }


if __name__ == "__main__":
    print("\n" + "="*60)
    print("🔍 测试 MySQL 连接")
    print("="*60)
    
    connection_result = test_mysql_connection()
    
    if connection_result["connected"]:
        print("✅ MySQL 连接成功！")
        print(f"   • 版本：{connection_result['version']}")
        print(f"   • 主机：{connection_result['host']}")
        print(f"   • 用户：{connection_result['user']}")
        print(f"   • 当前库：{connection_result['database']}")
        
        print("\n是否要初始化数据库？(y/n): ", end="")
        choice = input().strip().lower()
        
        if choice == 'y':
            initializer = DatabaseInitializer()
            result = initializer.initialize_all()
            
            if result["success"]:
                print("\n✨ 现在可以启动系统了！")
            else:
                print("\n⚠️ 请检查错误信息后重试")
    else:
        print("❌ MySQL 连接失败！")
        print(f"   错误：{connection_result['error']}")
        print("\n请检查：")
        print("   1. MySQL 服务是否已启动")
        print("   2. 配置文件 .env 中的数据库设置是否正确")
        print("   3. 用户名密码是否正确")
