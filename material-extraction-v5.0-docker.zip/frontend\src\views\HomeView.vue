<template>
  <div class="min-h-screen bg-gray-50 relative overflow-hidden flex flex-col">
    <!-- 极简背景纹理 -->
    <div class="absolute inset-0 opacity-[0.03]" style="background-image: radial-gradient(circle at 1px 1px, #171717 1px, transparent 0); background-size: 40px 40px;"></div>

    <!-- 主内容区 - 紧凑布局 -->
    <div class="relative z-10 container mx-auto px-4 py-6 max-w-5xl flex-1 flex flex-col">
      <!-- 顶部标题 - 紧凑 -->
      <header class="text-center mb-6">
        <div class="flex items-center justify-center gap-4">
          <h1 class="text-2xl font-semibold text-gray-900 tracking-tight">
            智能材料识别系统
          </h1>
          <!-- 数据库状态指示器 - 内联 -->
          <span class="inline-flex items-center gap-1.5 px-3 py-1 bg-white rounded-full border border-gray-200 text-xs text-gray-600 shadow-sm">
            <span class="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></span>
            {{ dbLabel }}
          </span>
        </div>
      </header>

      <!-- 步骤指示器 - 紧凑线条式 -->
      <nav class="mb-6 bg-white rounded-xl border border-gray-200 p-4 shadow-sm" aria-label="进度步骤">
        <ol class="flex items-center justify-between max-w-4xl mx-auto">
          <li 
            v-for="(step, index) in steps" 
            :key="step.key"
            class="flex items-center flex-1"
            :class="{ 'last:flex-none': index === steps.length - 1 }"
          >
            <div class="flex flex-col items-center">
              <div 
                class="w-8 h-8 rounded-full flex items-center justify-center text-xs font-medium transition-all duration-500 border-2"
                :class="getStepClass(index)"
              >
                <span v-if="currentStep > index" class="text-white">✓</span>
                <span v-else>{{ index + 1 }}</span>
              </div>
              <span 
                class="mt-1.5 text-[11px] font-medium transition-colors duration-300"
                :class="currentStep >= index ? 'text-gray-900' : 'text-gray-400'"
              >
                {{ step.label }}
              </span>
            </div>
            
            <div 
              v-if="index < steps.length - 1" 
              class="flex-1 h-px mx-3 mt-[-16px] transition-colors duration-700"
              :class="currentStep > index ? 'bg-gray-900' : 'bg-gray-200'"
            ></div>
          </li>
        </ol>
      </nav>

      <!-- 步骤内容区 - 自适应高度 -->
      <div class="flex-1 min-h-0">
        <!-- Step 1: 文件上传 -->
        <transition name="fade-height" mode="out-in">
          <section 
            v-show="currentStep === 0" 
            key="step-upload"
            class="bg-white rounded-xl border border-gray-200 p-6 shadow-sm hover:shadow-md transition-shadow duration-300 h-full flex flex-col"
          >
            <div class="max-w-2xl mx-auto space-y-5 flex-1 flex flex-col justify-center">
              <!-- 上传区域 - 紧凑拖拽区（支持多文件） -->
              <el-upload
                ref="uploadRef"
                drag
                action="#"
                :auto-upload="false"
                :on-change="handleFileChange"
                :show-file-list="false"
                accept=".pdf,.docx,.doc,.md,.markdown"
                multiple
                class="w-full upload-minimal"
              >
                <div class="py-8">
                  <div class="w-5 h-5 mx-auto mb-3 bg-gray-100 rounded-lg flex items-center justify-center group-hover:bg-gray-200 transition-colors duration-300">
                    <el-icon :size="10" class="text-gray-400 group-hover:text-gray-600 transition-colors"><UploadFilled /></el-icon>
                  </div>
                  <p class="text-base font-medium text-gray-700 mb-1">拖拽文件到此处，或点击上传</p>
                  <p class="text-xs text-gray-400">支持 PDF、Word、Markdown · 最大 50MB · 可多选</p>
                </div>
              </el-upload>

              <!-- 已选文件列表 -->
              <div v-if="selectedFiles.length > 0" class="space-y-2">
                <div class="flex items-center justify-between">
                  <span class="text-xs text-gray-500">已选择 {{ selectedFiles.length }} 个文件</span>
                  <button @click="clearFiles" class="text-xs text-red-500 hover:text-red-600">清空</button>
                </div>
                <div class="max-h-32 overflow-y-auto space-y-1">
                  <div
                    v-for="(file, index) in selectedFiles"
                    :key="index"
                    class="flex items-center justify-between bg-gray-50 rounded-md px-3 py-1.5 border border-gray-100"
                  >
                    <div class="flex items-center gap-2 min-w-0">
                      <el-icon :size="10" class="text-gray-400 shrink-0"><Document /></el-icon>
                      <span class="text-sm text-gray-700 truncate">{{ file.name }}</span>
                      <span class="text-xs text-gray-400 shrink-0">{{ formatFileSize(file.size) }}</span>
                    </div>
                    <button @click="removeFile(index)" class="p-0.5 text-gray-400 hover:text-red-500 transition-colors" :disabled="uploading">
                      <el-icon :size="10"><Close /></el-icon>
                    </button>
                  </div>
                </div>
              </div>

              <!-- 操作按钮 -->
              <div class="flex justify-center pt-2">
                <button
                  @click="handleUpload"
                  :disabled="selectedFiles.length === 0 || uploading"
                  class="group inline-flex items-center gap-2 px-8 py-2.5 bg-gray-900 text-white text-sm font-medium rounded-lg hover:bg-gray-800 active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-gray-400 focus:ring-offset-2"
                >
                  <svg v-if="uploading" class="animate-spin h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  <MagicStick v-else class="w-4 h-4" />
                  {{ uploading ? `处理中 (${batchDone}/${batchTotal})...` : `开始智能识别 (${selectedFiles.length} 个文件)` }}
                </button>
              </div>
            </div>
          </section>
        </transition>

        <!-- Step 2: 数据提取中 - 紧凑加载态 -->
        <transition name="fade-height" mode="out-in">
          <section 
            v-show="currentStep === 1" 
            key="step-extract"
            class="bg-white rounded-xl border border-gray-200 p-6 shadow-sm h-full flex flex-col"
          >
            <div class="max-w-xl mx-auto text-center space-y-5 flex-1 flex flex-col justify-center">
              <!-- 简约加载动画 - 缩小 -->
              <div class="relative w-20 h-20 mx-auto">
                <div class="absolute inset-0 border-2 border-gray-200 rounded-full animate-ping opacity-30"></div>
                <div class="absolute inset-1.5 bg-gray-50 rounded-full flex items-center justify-center">
                  <Loading :size="36" class="text-gray-400 animate-pulse" />
                </div>
              </div>

              <div class="space-y-1">
                <h3 class="text-lg font-semibold text-gray-900">{{ batchTotal > 1 ? `正在智能提取数据 (${batchDone}/${batchTotal})` : '正在智能提取数据...' }}</h3>
                <p class="text-sm text-gray-500">DeepSeek AI 正在分析文档内容</p>
              </div>

              <!-- 批量进度条 -->
              <div v-if="batchTotal > 1" class="w-full bg-gray-100 rounded-full h-1.5 overflow-hidden">
                <div class="h-full bg-gray-900 rounded-full transition-all duration-500" :style="{ width: batchPercent + '%' }"></div>
              </div>

              <!-- 进度信息 - 紧凑卡片 -->
              <div class="bg-gray-50 rounded-lg p-4 space-y-2 text-left border border-gray-100">
                <div class="flex items-center justify-between text-sm">
                  <span class="text-gray-500">当前文件</span>
                  <span class="font-mono text-gray-900 font-medium truncate ml-4">{{ currentFileName }}</span>
                </div>
                <div class="h-px bg-gray-200"></div>
                <div class="flex items-center justify-between text-sm">
                  <span class="text-gray-500">文件大小</span>
                  <span class="text-gray-900">{{ currentFileSize }}</span>
                </div>
                <div class="h-px bg-gray-200"></div>
                <div class="flex items-center justify-between text-sm">
                  <span class="text-gray-500">Session ID</span>
                  <code class="font-mono text-xs bg-white px-2 py-0.5 rounded text-gray-700 border border-gray-200">{{ sessionId }}</code>
                </div>
                <div v-if="batchTotal > 1" class="h-px bg-gray-200"></div>
                <div v-if="batchTotal > 1" class="flex items-center justify-between text-sm">
                  <span class="text-gray-500">进度</span>
                  <span class="text-gray-900">{{ batchDone }} / {{ batchTotal }}</span>
                </div>
              </div>

              <!-- 取消按钮 -->
              <button
                @click="cancelExtract"
                class="px-4 py-1.5 text-sm text-gray-500 hover:text-gray-700 border border-gray-300 hover:border-gray-400 hover:bg-gray-50 rounded-md transition-all duration-200"
              >
                取消操作
              </button>
            </div>
          </section>
        </transition>

        <!-- Step 3: 数据预览 - 紧凑表格展示 -->
        <transition name="fade-height" mode="out-in">
          <section 
            v-show="currentStep === 2" 
            key="step-preview"
            class="bg-white rounded-xl border border-gray-200 p-6 shadow-sm h-full flex flex-col overflow-hidden"
          >
            <!-- 🔴 DEBUG PANEL - 临时调试信息（正式版本可删除） -->
            <div v-if="false" class="mb-4 p-4 bg-yellow-50 border-2 border-yellow-400 rounded-lg">
              <div class="font-bold text-yellow-800 mb-2">🔍 [DEBUG] 数据状态检查</div>
              <div class="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span class="font-semibold">extractedData.length:</span> 
                  <span class="text-red-600 font-mono">{{ extractedData.length }}</span>
                </div>
                <div>
                  <span class="font-semibold">summary 类型:</span> 
                  <span class="font-mono">{{ typeof summary }}</span>
                </div>
                <div>
                  <span class="font-semibold">is_multi_table:</span> 
                  <span class="font-mono">{{ summary['is_multi_table'] }}</span>
                </div>
                <div>
                  <span class="font-semibold">总记录数:</span> 
                  <span class="font-mono">{{ summary['总记录数'] }}</span>
                </div>
              </div>
              <!-- 显示前3条数据的keys -->
              <div v-if="extractedData.length > 0" class="mt-2">
                <span class="font-semibold">前3条数据字段:</span>
                <pre class="mt-1 p-2 bg-white rounded text-xs overflow-x-auto max-h-32">{{ JSON.stringify(extractedData.slice(0, 3), null, 2) }}</pre>
              </div>
              <div v-else class="mt-2 text-red-600 font-bold">
                ⚠️ extractedData 为空！数据未正确接收
              </div>
            </div>

            <div class="space-y-4 flex-1 flex flex-col min-h-0">
              <!-- 批量处理结果摘要 -->
              <div v-if="batchTotal > 1" class="bg-blue-50 rounded-lg p-3 border border-blue-100 shrink-0">
                <div class="flex items-center gap-2 mb-2">
                  <el-icon :size="10" class="text-blue-600"><Collection /></el-icon>
                  <span class="text-sm font-semibold text-blue-800">批量提取结果 ({{ batchResults.filter(r => r.status === 'extracted').length }}/{{ batchTotal }})</span>
                </div>
                <div class="space-y-1 max-h-24 overflow-y-auto">
                  <div v-for="(r, idx) in batchResults" :key="idx"
                    class="flex items-center justify-between text-xs py-0.5"
                    :class="r.status === 'failed' ? 'text-red-600' : 'text-gray-700'"
                  >
                    <span class="truncate mr-2">{{ r.fileName }}</span>
                    <span class="shrink-0" :class="r.status === 'extracted' ? 'text-green-600' : ''">
                      {{ r.status === 'extracted' ? r.recordCount + ' records' : 'FAILED' }}
                    </span>
                  </div>
                </div>
              </div>

              <!-- 预览头部 - 紧凑 -->
              <div class="flex items-center justify-between shrink-0">
                <div class="flex items-center gap-2.5">
                  <div class="w-5 h-5 bg-emerald-50 rounded-lg flex items-center justify-center">
                    <el-icon :size="10" class="text-emerald-600"><SuccessFilled /></el-icon>
                  </div>
                  <div>
                    <h3 class="text-base font-semibold text-gray-900">数据提取完成</h3>
                    <p class="text-xs text-gray-500 mt-0.5">
                      共提取到 <span class="font-medium text-emerald-600">{{ extractedData.length }}</span> 条记录
                      <span v-if="summary['is_multi_table']" class="text-gray-400 ml-1">({{ summary['数据表数'] || 0 }} 张数据表)</span>
                    </p>
                  </div>
                </div>
                
                <button
                  @click="reExtract"
                  class="group inline-flex items-center gap-1.5 px-3 py-1.5 text-xs text-gray-600 hover:text-gray-900 border border-gray-300 hover:border-gray-400 hover:bg-gray-50 rounded-md transition-all duration-200"
                >
                  <Refresh class="w-3.5 h-3.5 group-hover:rotate-180 transition-transform duration-500" />
                  重新提取
                </button>
              </div>

              <!-- 数据统计卡片 - 紧凑网格 -->
              <div class="grid grid-cols-4 gap-3 shrink-0" v-if="summary">
                <div class="bg-gray-50 rounded-lg p-3 border border-gray-100 hover:border-gray-200 transition-colors duration-200">
                  <div class="text-xl font-semibold text-gray-900">{{ summary['总记录数'] || 0 }}</div>
                  <div class="text-[10px] text-gray-500 uppercase tracking-wider font-medium mt-0.5">总记录数</div>
                </div>
                <div v-if="summary['is_multi_table']" class="bg-blue-50 rounded-lg p-3 border border-blue-100 hover:border-blue-200 transition-colors duration-200">
                  <div class="text-xl font-semibold text-blue-700">{{ summary['数据表数'] || 0 }}</div>
                  <div class="text-[10px] text-blue-500 uppercase tracking-wider font-medium mt-0.5">数据表</div>
                </div>
                <div v-else class="bg-gray-50 rounded-lg p-3 border border-gray-100 hover:border-gray-200 transition-colors duration-200">
                  <div class="text-xl font-semibold text-gray-900">{{ summary['正常记录'] || extractedData.length }}</div>
                  <div class="text-[10px] text-gray-500 uppercase tracking-wider font-medium mt-0.5">正常记录</div>
                </div>
                <div class="bg-gray-50 rounded-lg p-3 border border-gray-100 hover:border-gray-200 transition-colors duration-200">
                  <div class="text-xl font-semibold text-gray-900">{{ summary['异常记录'] || 0 }}</div>
                  <div class="text-[10px] text-gray-500 uppercase tracking-wider font-medium mt-0.5">异常记录</div>
                </div>
              </div>

              <!-- 多表统计详情 (v2) -->
              <div v-if="summary['is_multi_table']" class="grid grid-cols-4 gap-2 shrink-0 mb-2">
                <div v-for="(cnt, key) in tableCounts" :key="key"
                     class="bg-white rounded px-2 py-1.5 border border-gray-100 text-center">
                  <div class="text-sm font-semibold text-gray-700">{{ cnt }}</div>
                  <div class="text-[9px] text-gray-400 truncate">{{ key.replace('表_', '') }}</div>
                </div>
              </div>

              <!-- 数据预览表格 - 自适应高度 -->
              <div class="overflow-hidden rounded-lg border border-gray-200 flex-1 min-h-0">
                <el-table 
                  :data="extractedData" 
                  stripe
                  style="width: 100%"
                  height="100%"
                  :header-cell-style="{ background: '#F9FAFB', color: '#374151', fontWeight: 600, fontSize: '12px', borderBottom: '1px solid #E5E7EB', padding: '8px 0' }"
                  :row-style="{ borderBottom: '1px solid #F3F4F6' }"
                  :cell-style="{ padding: '6px 0', fontSize: '13px' }"
                >
                  <!-- v2多表模式：显示表名列 -->
                  <el-table-column v-if="summary['is_multi_table']" prop="_table" label="数据表" width="140" fixed>
                    <template #default="{ row }">
                      <span class="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-700">
                        {{ row._table }}
                      </span>
                    </template>
                  </el-table-column>

                  <!-- v1单表模式：原有列 -->
                  <template v-if="!summary['is_multi_table']">
                    <el-table-column prop="id" label="ID" width="70" />
                    <el-table-column prop="identifier" label="标识符" width="130" />
                    <el-table-column prop="type" label="类型" width="80" />
                    <el-table-column prop="title" label="标题" show-overflow-tooltip />
                    <el-table-column prop="authors" label="作者" width="150" show-overflow-tooltip />
                    <el-table-column prop="year" label="年份" width="60" />
                    <el-table-column prop="journal" label="期刊/来源" width="140" show-overflow-tooltip />
                  </template>

                  <!-- v2多表模式：通用字段 -->
                  <template v-else>
                    <el-table-column v-for="col in previewColumns" :key="col.key"
                      :prop="col.key" :label="col.label" :width="col.width"
                      :show-overflow-tooltip="true" />
                  </template>
                </el-table>
              </div>

              <!-- 操作按钮组 - 紧凑 -->
              <div class="flex justify-end gap-2.5 pt-3 border-t border-gray-100 shrink-0">
                <button
                  @click="resetAll"
                  class="px-5 py-2 text-sm text-gray-600 hover:text-gray-900 border border-gray-300 hover:border-gray-400 hover:bg-gray-50 rounded-md transition-all duration-200"
                >
                  重新开始
                </button>
                <button
                  @click="handleConfirmWrite"
                  :disabled="confirming"
                  class="inline-flex items-center gap-2 px-6 py-2 bg-gray-900 text-white text-sm font-medium rounded-md hover:bg-gray-800 active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-gray-400 focus:ring-offset-2"
                >
                  <Check class="w-4 h-4" />
                  {{ confirming ? '生成中...' : '确认并生成 Excel' }}
                </button>
              </div>
            </div>
          </section>
        </transition>

        <!-- Step 4: Excel 已生成 - 可编辑后上传 -->
        <transition name="fade-height" mode="out-in">
          <section 
            v-show="currentStep === 3" 
            key="step-excel"
            class="bg-white rounded-xl border border-gray-200 p-6 shadow-sm h-full flex flex-col"
          >
            <div class="max-w-2xl mx-auto text-center space-y-5 flex-1 flex flex-col justify-center">
              <!-- 成功图标 -->
              <div class="w-6 h-6 mx-auto bg-emerald-50 rounded-lg flex items-center justify-center">
                <CircleCheckFilled :size="12" class="text-emerald-600" />
              </div>

              <div class="space-y-1">
                <h3 class="text-xl font-semibold text-gray-900">Excel 文件已生成</h3>
                <p class="text-sm text-gray-500">数据已成功写入 Excel 表格</p>
              </div>

              <!-- ⭐ 核心提示：可以编辑 Excel -->
              <div class="bg-blue-50 rounded-lg p-4 border border-blue-200 max-w-lg mx-auto w-full">
                <div class="flex items-start gap-3">
                  <span class="text-blue-500 mt-0.5">💡</span>
                  <div class="text-left">
                    <p class="text-sm font-medium text-blue-900 mb-1">您可以先编辑 Excel，再上传到数据库</p>
                    <p class="text-xs text-blue-700 leading-relaxed">
                      系统会读取 Excel 文件中的<strong>实际内容</strong>（包括您的修改）上传到 {{ dbLabel }}
                    </p>
                  </div>
                </div>
              </div>

              <!-- 文件路径 + 操作按钮 -->
              <div class="bg-gray-50 rounded-lg p-4 border border-gray-100 max-w-lg mx-auto w-full space-y-3">
                <!-- 路径显示 -->
                <div class="flex items-center gap-2">
                  <span class="text-xs text-gray-500 shrink-0">📄 文件位置:</span>
                  <code class="font-mono text-xs text-gray-700 bg-white px-3 py-1.5 rounded border border-gray-200 flex-1 truncate">{{ excelPath }}</code>
                  <button
                    @click="copyFilePath"
                    class="shrink-0 p-1.5 text-gray-400 hover:text-gray-600 hover:bg-gray-200 rounded transition-colors"
                    title="复制路径"
                  >
                    <el-icon :size="10"><Document /></el-icon>
                  </button>
                </div>
              </div>

              <!-- 统计信息 - 横向网格 -->
              <div class="grid grid-cols-3 gap-3 max-w-lg mx-auto w-full">
                <div class="bg-gray-50 rounded-lg p-3 border border-gray-100 text-left">
                  <div class="text-[10px] text-gray-500 uppercase tracking-wider font-medium mb-1">本次新增</div>
                  <div class="text-lg font-semibold text-emerald-600">{{ addedCount }} 条</div>
                </div>
                <div v-if="skippedDuplicates > 0" class="bg-gray-50 rounded-lg p-3 border border-gray-100 text-left">
                  <div class="text-[10px] text-gray-500 uppercase tracking-wider font-medium mb-1">跳过重复</div>
                  <div class="text-lg font-semibold text-amber-600">{{ skippedDuplicates }} 条</div>
                </div>
                <div class="bg-gray-50 rounded-lg p-3 border border-gray-100 text-left">
                  <div class="text-[10px] text-gray-500 uppercase tracking-wider font-medium mb-1">总记录数</div>
                  <div class="text-lg font-semibold text-gray-900">{{ writtenCount + skippedDuplicates }} 条</div>
                </div>
              </div>

              <!-- ⚡ 强制导入选项（跨电脑迁移专用） -->
              <div class="bg-amber-50 rounded-lg p-3 border border-amber-200 max-w-lg mx-auto w-full">
                <label class="flex items-center gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    v-model="forceMode"
                    class="w-4 h-4 text-amber-600 border-amber-300 rounded focus:ring-amber-500"
                  />
                  <div class="text-left flex-1">
                    <p class="text-sm font-medium text-amber-900">🔄 强制导入模式（忽略去重）</p>
                    <p class="text-xs text-amber-700 leading-relaxed mt-0.5">
                      适用于：跨电脑迁移、数据恢复、重新导入场景。将更新已有记录而非跳过。
                    </p>
                  </div>
                </label>
              </div>

              <!-- 主要操作按钮组 -->
              <div class="flex justify-center gap-3 pt-1">
                <button
                  @click="handleUploadToDB"
                  :disabled="uploadingToDB"
                  class="inline-flex items-center gap-2 px-7 py-2.5 bg-gray-900 text-white text-sm font-medium rounded-lg hover:bg-gray-800 active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-gray-400 focus:ring-offset-2"
                >
                  <el-icon :size="10"><Upload /></el-icon>
                  {{ uploadingToDB ? '上传中...' : `上传到 ${dbLabel}` }}
                </button>
                <button
                  @click="resetAll"
                  class="px-7 py-2.5 text-sm text-gray-600 hover:text-gray-900 border border-gray-300 hover:border-gray-400 hover:bg-gray-50 rounded-lg transition-all duration-200 font-medium"
                >
                  处理新文件
                </button>
              </div>
            </div>
          </section>
        </transition>

        <!-- Step 5: 全部完成 - 紧凑布局 -->
        <transition name="fade-height" mode="out-in">
          <section 
            v-show="currentStep === 4" 
            key="step-complete"
            class="bg-white rounded-xl border border-gray-200 p-6 shadow-sm h-full flex flex-col"
          >
            <div class="max-w-2xl mx-auto text-center space-y-5 flex-1 flex flex-col justify-center">
              <!-- 完成图标 -->
              <div class="w-7 h-7 mx-auto bg-gray-100 rounded-full flex items-center justify-center relative" style="width:28px;height:28px;">
                <Select :size="12" class="text-gray-700" />
                <div class="absolute inset-0 bg-emerald-500 rounded-full animate-ping opacity-20"></div>
              </div>

              <div class="space-y-1">
                <h3 class="text-xl font-semibold text-gray-900">全部完成</h3>
                <p class="text-sm text-gray-500">数据已成功上传到 <span class="font-medium text-gray-700">{{ dbLabel }}</span> 数据库</p>
              </div>

              <!-- 完成统计 - 紧凑网格 -->
              <div class="grid grid-cols-4 gap-3">
                <div class="bg-gray-50 rounded-lg p-3 border border-gray-100">
                  <div class="text-xl font-semibold text-gray-900">{{ dbResult.success_count || 0 }}</div>
                  <div class="text-[10px] text-gray-500 mt-1 uppercase tracking-wider font-medium">成功上传</div>
                </div>
                <div class="bg-gray-50 rounded-lg p-3 border border-gray-100">
                  <div class="text-xl font-semibold text-gray-900">{{ dbResult.failed_count || 0 }}</div>
                  <div class="text-[10px] text-gray-500 mt-1 uppercase tracking-wider font-medium">失败记录</div>
                </div>
                <div v-if="dbResult.skipped_duplicates > 0" class="bg-gray-50 rounded-lg p-3 border border-gray-100">
                  <div class="text-xl font-semibold text-gray-900">{{ dbResult.skipped_duplicates || 0 }}</div>
                  <div class="text-[10px] text-gray-500 mt-1 uppercase tracking-wider font-medium">跳过重复</div>
                </div>
                <div class="bg-gray-50 rounded-lg p-3 border border-gray-100">
                  <div class="text-base font-semibold text-gray-900 leading-tight">{{ dbResult.table_name || '-' }}</div>
                  <div class="text-[10px] text-gray-500 mt-1 uppercase tracking-wider font-medium">目标表名</div>
                </div>
              </div>

              <!-- 最终操作按钮 -->
              <div class="pt-1">
                <button
                  @click="resetAll"
                  class="group inline-flex items-center gap-2 px-10 py-2.5 bg-gray-900 text-white text-sm font-medium rounded-lg hover:bg-gray-800 active:scale-[0.98] transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-gray-400 focus:ring-offset-2"
                >
                  <el-icon :size="10" class="group-hover:rotate-180 transition-transform duration-500"><RefreshRight /></el-icon>
                  继续处理下一个文件
                </button>
              </div>
            </div>
          </section>
        </transition>
      </div>
    </div>

    <!-- Footer - 极简紧凑 -->
    <footer class="relative z-10 text-center py-4 mt-4 border-t border-gray-200">
      <p class="text-[11px] text-gray-400">
        Powered by DeepSeek AI & PostgreSQL
      </p>
    </footer>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import axios from 'axios'
import {
  UploadFilled,
  MagicStick,
  Loading,
  SuccessFilled,
  Refresh,
  Check,
  CircleCheckFilled,
  Upload,
  Select,
  RefreshRight,
  Document,
  Close,
  Collection,
} from '@element-plus/icons-vue'

// API 基础地址
const API_BASE = '/api/document'

// 数据库类型（动态获取）
const dbType = ref('postgresql')
const dbLabel = computed(() => dbType.value === 'postgresql' ? 'PostgreSQL' : 'MySQL')

// 状态管理
const currentStep = ref(0)
const selectedFiles = ref([])
const uploading = ref(false)
const confirming = ref(false)
const uploadingToDB = ref(false)

// 批量处理状态
const batchDone = ref(0)
const batchTotal = ref(0)
const batchPercent = computed(() => batchTotal.value > 0 ? Math.round(batchDone.value / batchTotal.value * 100) : 0)
const batchResults = ref([])

// Session 和数据
const sessionId = ref('')
const currentFileName = computed(() => {
  if (batchResults.value.length > 0) {
    const cur = batchResults.value[batchResults.value.length - 1]
    return cur?.fileName || selectedFiles.value[0]?.name || ''
  }
  return selectedFiles.value[0]?.name || ''
})
const currentFileSize = computed(() => {
  const file = selectedFiles.value[0]
  if (!file?.size) return '-'
  return formatFileSize(file.size)
})

// 提取的数据
const extractedData = ref([])
const summary = ref({})
const excelPath = ref('./output/material_data.xlsx')
const writtenCount = ref(0)
const addedCount = ref(0)
const skippedDuplicates = ref(0)
const dbResult = ref({})

// v2多表模式：计算各表行数统计
const tableCounts = computed(() => {
  const counts = {}
  if (summary.value && summary.value['is_multi_table']) {
    for (const [key, val] of Object.entries(summary.value)) {
      if (key.startsWith('表_') && typeof val === 'number') {
        counts[key] = val
      }
    }
  }
  return counts
})

// v2多表模式：动态预览列（排除内部字段）
const previewColumns = computed(() => {
  const cols = []
  if (!extractedData.value.length) return cols
  
  // 收集所有非内部字段的key
  const internalKeys = new Set(['_table', '_desc', '_more'])
  const keyCount = {}
  
  for (const row of extractedData.value.slice(0, 20)) {
    for (const k of Object.keys(row)) {
      if (!internalKeys.has(k)) {
        keyCount[k] = (keyCount[k] || 0) + 1
      }
    }
  }
  
  // 取出现频率最高的前6个字段
  const sortedKeys = Object.entries(keyCount)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 6)
  
  const labelMap = {
    'paper_code': '论文编号',
    'mix_code': '配合比编号',
    'mix_label': '配合比标签',
    'title': '标题',
    'authors': '作者',
    'year': '年份',
    'target_temperature': '温度(℃)',
    'compressive_strength': '抗压强度(MPa)',
    'fiber_type': '纤维类型',
    'volume_fraction_pct': '体积掺量(%)',
    'water_binder_ratio': '水胶比',
    'specimen_shape': '试件形状',
    'result_group_code': '结果编号',
    'heating_protocol_id': '加热协议',
  }
  
  for (const [key, count] of sortedKeys) {
    cols.push({
      key,
      label: labelMap[key] || key,
      width: count > extractedData.value.length * 0.7 ? 120 : undefined,
    })
  }
  
  return cols
})

// 强制导入模式（用于跨电脑迁移、数据恢复等场景）
const forceMode = ref(false)

// 步骤定义
const steps = [
  { key: 'upload', label: '上传文件' },
  { key: 'extract', label: '智能提取' },
  { key: 'preview', label: '预览确认' },
  { key: 'excel', label: '生成 Excel' },
  { key: 'database', label: '入库完成' }
]

// 获取步骤样式 - 极简灰白风格
const getStepClass = (index) => {
  if (currentStep.value > index) {
    return 'bg-gray-900 text-white border-gray-900'
  } else if (currentStep.value === index) {
    return 'bg-gray-900 text-white border-gray-900 ring-4 ring-gray-200 scale-105'
  }
  return 'bg-white text-gray-400 border-gray-300'
}

// 初始化：检测数据库类型
onMounted(async () => {
  try {
    const res = await axios.get('/health')
    if (res.data.database_type) {
      dbType.value = res.data.database_type
    } else if (res.data.mysql_status && res.data.mysql_status !== 'error') {
      dbType.value = 'mysql'
    }
    console.log(`🗄️ 当前数据库类型: ${dbType.value} (${dbLabel.value})`)
  } catch (e) {
    console.warn('无法获取数据库类型，使用默认值:', e.message)
  }
})

// 工具函数：格式化文件大小
const formatFileSize = (size) => {
  if (!size) return '-'
  if (size < 1024) return `${size} B`
  if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} KB`
  return `${(size / (1024 * 1024)).toFixed(1)} MB`
}

// 文件选择处理
const handleFileChange = (file) => {
  selectedFiles.value.push(file.raw)
}

// 移除单个文件
const removeFile = (index) => {
  selectedFiles.value.splice(index, 1)
}

// 清空所有文件
const clearFiles = () => {
  selectedFiles.value = []
}

// 批量上传处理（顺序执行）
const handleUpload = async () => {
  if (selectedFiles.value.length === 0) return

  uploading.value = true
  batchTotal.value = selectedFiles.value.length
  batchDone.value = 0
  batchResults.value = []

  currentStep.value = 1

  for (let i = 0; i < selectedFiles.value.length; i++) {
    const file = selectedFiles.value[i]
    batchDone.value = i

    console.log(`📤 [BATCH] 处理第 ${i + 1}/${selectedFiles.value.length} 个文件: ${file.name}`)

    try {
      const formData = new FormData()
      formData.append('file', file)

      const uploadRes = await axios.post(`${API_BASE}/upload`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
        timeout: 600000
      })

      if (uploadRes.data.status !== 'success') {
        throw new Error(uploadRes.data.message || '上传失败')
      }

      sessionId.value = uploadRes.data.session_id

      const extractRes = await axios.post(`${API_BASE}/extract`, null, {
        params: { session_id: sessionId.value },
        timeout: 600000
      })

      if (extractRes.data.status !== 'success') {
        throw new Error(extractRes.data.message || '提取失败')
      }

      extractedData.value = extractRes.data.preview_items || []
      summary.value = extractRes.data.summary || {}

      if (!summary.value['is_multi_table']) {
        summary.value['is_multi_table'] = true
      }

      batchResults.value.push({
        fileName: file.name,
        fileSize: formatFileSize(file.size),
        sessionId: sessionId.value,
        recordCount: extractedData.value.length,
        status: 'extracted'
      })

      console.log(`✅ [BATCH] ${file.name}: 提取成功, ${extractedData.value.length} 条记录`)

    } catch (error) {
      console.error(`❌ [BATCH] ${file.name}: 失败 -`, error.message)
      batchResults.value.push({
        fileName: file.name,
        fileSize: formatFileSize(file.size),
        status: 'failed',
        error: error.response?.data?.detail || error.message
      })
    }
  }

  batchDone.value = selectedFiles.value.length
  uploading.value = false

  const successCount = batchResults.value.filter(r => r.status === 'extracted').length
  const failCount = batchResults.value.filter(r => r.status === 'failed').length

  if (successCount > 0) {
    // 使用最后一个成功的提取结果来展示预览
    const lastSuccess = batchResults.value.filter(r => r.status === 'extracted').pop()
    if (lastSuccess) {
      sessionId.value = lastSuccess.sessionId
    }
    currentStep.value = 2
    ElMessage.success(`批量提取完成: ${successCount} 成功, ${failCount} 失败`)
  } else {
    currentStep.value = 0
    ElMessage.error('所有文件提取均失败，请重试')
  }
}

// 确认写入 Excel（支持批量）
const handleConfirmWrite = async () => {
  confirming.value = true

  const successful = batchResults.value.filter(r => r.status === 'extracted')
  if (batchResults.value.length > 1 && successful.length > 1) {
    // 批量模式：依次写入所有成功提取的文件
    let totalWritten = 0
    let totalSkipped = 0
    
    for (let i = 0; i < successful.length; i++) {
      const result = successful[i]
      console.log(`📝 [BATCH] 写入Excel ${i + 1}/${successful.length}: ${result.fileName}`)

      try {
        const response = await axios.post(`${API_BASE}/confirm-write`, null, {
          params: { session_id: result.sessionId },
          timeout: 60000
        })

        if (response.data.status === 'success') {
          totalWritten += response.data.written_count || 0
          totalSkipped += response.data.skipped_duplicates || 0
          result.writtenCount = response.data.written_count
          result.status = 'written'
        }
      } catch (error) {
        console.error(`❌ [BATCH] ${result.fileName} 写入失败:`, error.message)
        result.writeError = error.response?.data?.detail || error.message
      }
    }

    // 使用最后一个 session 的数据展示结果
    const lastSession = successful[successful.length - 1]
    sessionId.value = lastSession.sessionId
    excelPath.value = './output/material_data.xlsx'
    writtenCount.value = totalWritten
    addedCount.value = totalWritten
    skippedDuplicates.value = totalSkipped
    currentStep.value = 3

    ElMessage.success(`批量写入完成: ${totalWritten} 条记录, 跳过 ${totalSkipped} 条`)
  } else {
    // 单文件模式
    try {
      const response = await axios.post(`${API_BASE}/confirm-write`, null, {
        params: { session_id: sessionId.value },
        timeout: 60000
      })

      if (response.data.status === 'success') {
        excelPath.value = response.data.excel_path
        writtenCount.value = response.data.written_count
        addedCount.value = response.data.written_count
        skippedDuplicates.value = response.data.skipped_duplicates || 0
        currentStep.value = 3
        
        ElMessage.success(response.data.message || 'Excel 文件已生成')
      } else {
        throw new Error(response.data.message)
      }
    } catch (error) {
      ElMessage.error('生成失败：' + (error.response?.data?.detail || error.message))
    }
  }

  confirming.value = false
}

// 上传到数据库（支持批量）
const handleUploadToDB = async () => {
  uploadingToDB.value = true

  const successful = batchResults.value.filter(r => r.status === 'written' || r.status === 'extracted')
  if (batchResults.value.length > 1 && successful.length > 1) {
    let totalSuccess = 0
    let totalSkip = 0
    let totalFail = 0

    for (let i = 0; i < successful.length; i++) {
      const result = successful[i]
      console.log(`📤 [BATCH] 上传DB ${i + 1}/${successful.length}: ${result.fileName}`)

      try {
        const response = await axios.post(`${API_BASE}/upload-mysql`, null, {
          params: {
            session_id: result.sessionId,
            force: forceMode.value
          },
          timeout: 60000
        })

        if (response.data.status === 'success') {
          totalSuccess += response.data.success_count || 0
          totalSkip += response.data.skipped_count || 0
          totalFail += response.data.fail_count || 0
          result.dbStatus = 'uploaded'
        }
      } catch (error) {
        console.error(`❌ [BATCH] ${result.fileName} 上传DB失败:`, error.message)
        result.dbStatus = 'failed'
        totalFail += 1
      }
    }

    dbResult.value = {
      status: 'success',
      success_count: totalSuccess,
      skipped_count: totalSkip,
      fail_count: totalFail,
    }
    currentStep.value = 4

    ElMessage.success(`批量上传完成: ${totalSuccess} 条成功, ${totalSkip} 条跳过`)
  } else {
    // 单文件模式
    try {
      const response = await axios.post(`${API_BASE}/upload-mysql`, null, {
        params: { 
          session_id: sessionId.value,
          force: forceMode.value
        },
        timeout: 60000
      })

      if (response.data.status === 'success') {
        dbResult.value = response.data
        currentStep.value = 4
        
        if (forceMode.value) {
          ElMessage.success(`强制导入完成！成功 ${response.data.success_count} 条`)
        } else {
          ElMessage.success(`数据已成功上传到 ${dbLabel.value}`)
        }
      } else {
        throw new Error(response.data.message)
      }
    } catch (error) {
      ElMessage.error(`上传失败：` + (error.response?.data?.detail || error.message))
    }
  }

  uploadingToDB.value = false
}

// 重新提取
const reExtract = async () => {
  currentStep.value = 1
  uploading.value = true

  try {
    const extractRes = await axios.post(`${API_BASE}/extract`, null, {
      params: { session_id: sessionId.value },
      timeout: 600000
    })

    if (extractRes.data.status === 'success') {
      extractedData.value = extractRes.data.preview_items || []
      summary.value = extractRes.data.summary || {}
      if (!summary.value['is_multi_table']) {
        summary.value['is_multi_table'] = true
      }
      currentStep.value = 2
      ElMessage.success(`成功提取 ${extractedData.value.length} 条记录`)
    } else {
      throw new Error(extractRes.data.message || '提取失败')
    }
  } catch (error) {
    console.error('提取失败:', error.message)
    ElMessage.error('提取失败：' + (error.response?.data?.detail || error.message))
    currentStep.value = 0
  } finally {
    uploading.value = false
  }
}

// 取消提取
const cancelExtract = () => {
  currentStep.value = 0
  sessionId.value = ''
}

// 完全重置
const resetAll = () => {
  currentStep.value = 0
  selectedFiles.value = []
  sessionId.value = ''
  extractedData.value = []
  summary.value = {}
  batchResults.value = []
  batchDone.value = 0
  batchTotal.value = 0
  excelPath.value = './output/material_data.xlsx'
  writtenCount.value = 0
  addedCount.value = 0
  skippedDuplicates.value = 0
  dbResult.value = {}
}

// ========== Excel 文件操作方法 ==========

// 复制文件路径到剪贴板
const copyFilePath = async () => {
  try {
    await navigator.clipboard.writeText(excelPath.value)
    ElMessage.success('路径已复制到剪贴板')
  } catch (err) {
    // 降级方案：使用传统复制方式
    const textArea = document.createElement('textarea')
    textArea.value = excelPath.value
    document.body.appendChild(textArea)
    textArea.select()
    document.execCommand('copy')
    document.body.removeChild(textArea)
    ElMessage.success('路径已复制到剪贴板')
  }
}

// ===========================================
</script>

<style scoped>
/* 过渡动画 - 更快更流畅 */
.fade-height-enter-active,
.fade-height-leave-active {
  transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
}

.fade-height-enter-from {
  opacity: 0;
  transform: translateY(12px);
}

.fade-height-leave-to {
  opacity: 0;
  transform: translateY(-12px);
}

/* 上传区域样式 - 紧凑 */
.upload-minimal :deep(.el-upload-dragger) {
  width: 100% !important;
  height: auto !important;
  padding: 24px 20px !important;
  border: 2px dashed #E5E7EB !important;
  border-radius: 12px !important;
  background: #FAFAFA !important;
  transition: all 0.25s ease !important;
}

.upload-minimal :deep(.el-upload-dragger:hover) {
  border-color: #9CA3AF !important;
  background: #F9FAFB !important;
}

/* 表格样式优化 - 紧凑 */
:deep(.el-table) {
  --el-table-border-color: #E5E7EB;
  --el-table-header-bg-color: #F9FAFB;
  --el-table-row-hover-bg-color: #F9FAFB;
  --el-table-tr-bg-color: transparent;
  color: #374151;
  font-size: 13px;
}

:deep(.el-table th) {
  background: #F9FAFB !important;
  color: #374151 !important;
  font-weight: 600 !important;
  border-bottom: 1px solid #E5E7EB !important;
}

:deep(.el-table tr) {
  background: transparent !important;
}

:deep(.el-table--striped .el-table__body tr.el-table__row--striped td.el-table__cell) {
  background: #FAFAFA !important;
}

:deep(.el-table .cell) {
  color: #374151;
}
</style>
