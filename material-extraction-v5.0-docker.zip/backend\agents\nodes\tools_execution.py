"""
工具执行节点（耦合版v3 - 纯多表流程）

统一使用多表提取+多Sheet Excel写入+多表PostgreSQL上传
material_data 为主表(目录)，所有子表外键指向 material_data.paper_code
"""

import os
from typing import Dict, Any
from backend.agents.state import AgentState, update_state_timestamp


def tools_execution_node(state: AgentState) -> AgentState:
    """
    工具执行节点 - 纯多表模式
    
    流程：
    1. parse_documents   → everything_read 解析PDF为文本
    2. extract_data      → get_data_v2 LLM提取多表结构数据
    3. preview_data      → 预览提取结果
    4. write_excel       → format_data_v2 多Sheet写入Excel
    5. upload_to_database → PostgresUploaderV2 多表上传到PostgreSQL
    """
    print("\n" + "="*60)
    print(" [节点3] 工具执行 (纯多表模式)")
    print("="*60)
    
    task_plan = state.get("task_plan", [])
    
    if not task_plan:
        print(" 任务计划为空，跳过执行")
        return state
    
    tool_results = {}
    
    try:
        tools = _initialize_tools(state)
        
        for task in task_plan:
            step_num = task["step"]
            action = task["action"]
            
            print(f"\n▶️ Step {step_num}: {task['description']}")
            
            try:
                result = _execute_single_task(task, tools, state)
                
                task["status"] = "completed"
                tool_results[action] = {
                    "status": "success",
                    "result": result,
                    "error": None
                }
                
                _update_state_from_result(state, action, result)
                state["current_step"] = step_num
                
                print(f" Step {step_num} 完成")
                
            except Exception as e:
                error_msg = f"Step {step_num} 执行失败: {str(e)}"
                print(f" {error_msg}")
                
                task["status"] = "failed"
                tool_results[action] = {
                    "status": "failed",
                    "result": None,
                    "error": str(e),
                    "details": str(e)[:200]
                }
                
                if task.get("required"):
                    state["error_info"] = {
                        "step": f"Step_{step_num}_{action}",
                        "error_type": "TOOL_ERROR",
                        "message": error_msg,
                        "details": str(e)
                    }
                    
                    if action in ["parse_documents", "extract_data"]:
                        raise
        
        state["tool_results"] = tool_results
        state = update_state_timestamp(state)
        
        _print_execution_summary(tool_results)
        
        return state
        
    except Exception as e:
        final_error = f"工具执行流程中断: {str(e)}"
        print(f"\n {final_error}")
        
        state["tool_results"] = tool_results
        state["status"] = "failed"
        if not state.get("error_info"):
            state["error_info"] = {
                "step": "tools_execution",
                "error_type": "EXECUTION_ERROR",
                "message": final_error,
                "details": str(e)
            }
        state = update_state_timestamp(state)
        
        return state


def _initialize_tools(state: AgentState) -> Dict[str, Any]:
    """初始化所有工具实例（纯多表模式）"""
    from backend.config import get_settings
    from backend.tools.everything_read import everything_read
    from backend.tools.format_data_v2 import format_data_v2
    from backend.tools.upload_data_v2 import PostgresUploaderV2

    settings = get_settings()

    return {
        "reader": everything_read(),
        "excel": format_data_v2(settings.OUTPUT_DIR),
        "uploader": PostgresUploaderV2(
            host=settings.POSTGRES_HOST,
            port=settings.POSTGRES_PORT,
            user=settings.POSTGRES_USER,
            password=settings.POSTGRES_PASSWORD,
            database=settings.POSTGRES_DATABASE
        ),
        "extractor": None,
    }


def _execute_single_task(
    task: Dict[str, Any],
    tools: Dict[str, Any],
    state: AgentState
) -> Any:
    """执行单个任务步骤"""
    action = task["action"]
    
    dispatch = {
        "parse_documents": _execute_parse_documents,
        "extract_data": _execute_extract_data,
        "preview_data": _execute_preview_data,
        "write_excel": _execute_write_excel,
        "upload_to_database": _execute_upload_database,
    }
    
    handler = dispatch.get(action)
    if not handler:
        raise ValueError(f"未知的任务类型: {action}")
    
    return handler(tools, state)


def _execute_parse_documents(tools: Dict[str, Any], state: AgentState) -> str:
    """文档解析 → 纯文本"""
    files = state.get("uploaded_files", [])
    
    if not files:
        raise ValueError("没有可解析的文件")
    
    reader = tools["reader"]
    
    all_content = []
    for file_info in files:
        file_path = file_info.get("path")
        if file_path and os.path.exists(file_path):
            with open(file_path, 'rb') as f:
                content = reader.read(f)
                all_content.append(content)
    
    return "\n\n---\n\n".join(all_content) if all_content else ""


def _execute_extract_data(tools: Dict[str, Any], state: AgentState) -> dict:
    """LLM 多表数据提取 → {table_name: [rows...]}"""
    content = state.get("document_content", "")

    if not content:
        raise ValueError("文档内容为空，无法提取数据")

    if tools["extractor"] is None:
        from backend.utils.llm_client import create_deepseek_client
        from backend.tools.get_data_v2 import get_data_v2

        llm_client = create_deepseek_client()
        tools["extractor"] = get_data_v2(llm_client=llm_client)

    data = tools["extractor"].extract(content)

    return data


def _execute_preview_data(tools: Dict[str, Any], state: AgentState) -> dict:
    """预览提取的多表数据"""
    extractor = tools["extractor"]
    
    if not extractor or not extractor.data:
        raise ValueError("没有可预览的数据，请先提取数据")
    
    return extractor.preview()


def _execute_write_excel(tools: Dict[str, Any], state: AgentState) -> tuple:
    """多表数据 → 多Sheet Excel文件"""
    excel = tools["excel"]
    extractor = tools["extractor"]

    if not extractor or not extractor.data:
        raise ValueError("没有可写入的数据")

    excel.create_or_open()
    data_to_write = extractor.get_all_data()
    result = excel.write_all(data_to_write)
    filepath = excel.save()

    return (result, filepath)


def _execute_upload_database(tools: Dict[str, Any], state: AgentState) -> dict:
    """多表数据 → PostgreSQL (每张表独立导入)"""
    uploader = tools["uploader"]
    extractor = tools["extractor"]

    if not extractor or not extractor.data:
        raise ValueError("没有可上传的数据")

    data = extractor.get_all_data()
    result = uploader.upload_from_dict(data)

    return result


def _update_state_from_result(state: AgentState, action: str, result: Any):
    """根据执行结果更新状态"""
    if action == "parse_documents":
        state["document_content"] = result
        
    elif action == "extract_data":
        state["extracted_data"] = result
        
    elif action == "preview_data":
        state["preview_data"] = result
        
    elif action == "write_excel":
        if isinstance(result, tuple):
            _, filepath = result
            state["excel_path"] = filepath
            
    elif action == "upload_to_database":
        state["pg_result"] = result


def _print_execution_summary(results: Dict[str, Any]):
    """打印执行摘要"""
    total = len(results)
    success = sum(1 for r in results.values() if r["status"] == "success")
    failed = total - success
    
    print("\n" + "="*60)
    print(f" 执行摘要:")
    print(f"   总步骤: {total}")
    print(f"   成功: {success}")
    if failed > 0:
        print(f"   失败: {failed}")
    print("="*60)
